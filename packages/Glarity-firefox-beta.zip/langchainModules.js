"use strict";
(() => {
  var Af = Object.create;
  var ba = Object.defineProperty;
  var Ef = Object.getOwnPropertyDescriptor;
  var Tf = Object.getOwnPropertyNames;
  var If = Object.getPrototypeOf;
  var Cf = Object.prototype.hasOwnProperty;
  var bn = /* @__PURE__ */ ((r) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(r, {
    get: (e, t) => (typeof require !== "undefined" ? require : e)[t]
  }) : r)(function(r) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw new Error('Dynamic require of "' + r + '" is not supported');
  });
  var j = (r, e) => () => (r && (e = r(r = 0)), e);
  var N = (r, e) => () => (e || r((e = { exports: {} }).exports, e), e.exports);
  var tt = (r, e) => {
    for (var t in e)
      ba(r, t, { get: e[t], enumerable: true });
  };
  var Sf = (r, e, t, n) => {
    if (e && typeof e === "object" || typeof e === "function") {
      for (let i of Tf(e))
        if (!Cf.call(r, i) && i !== t)
          ba(r, i, { get: () => e[i], enumerable: !(n = Ef(e, i)) || n.enumerable });
    }
    return r;
  };
  var be = (r, e, t) => (t = r != null ? Af(If(r)) : {}, Sf(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    e || !r || !r.__esModule ? ba(t, "default", { value: r, enumerable: true }) : t,
    r
  ));

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/helpers/bind.js
  var ga = N((pv, Bu) => {
    "use strict";
    Bu.exports = function r(e, t) {
      return function n() {
        var i = new Array(arguments.length);
        for (var s = 0; s < i.length; s++) {
          i[s] = arguments[s];
        }
        return e.apply(t, i);
      };
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/utils.js
  var Se = N((hv, Qu) => {
    "use strict";
    var jf = ga();
    var Lt = Object.prototype.toString;
    function va(r) {
      return Array.isArray(r);
    }
    function wa(r) {
      return typeof r === "undefined";
    }
    function kf(r) {
      return r !== null && !wa(r) && r.constructor !== null && !wa(r.constructor) && typeof r.constructor.isBuffer === "function" && r.constructor.isBuffer(r);
    }
    function $u(r) {
      return Lt.call(r) === "[object ArrayBuffer]";
    }
    function Rf(r) {
      return Lt.call(r) === "[object FormData]";
    }
    function Nf(r) {
      var e;
      if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) {
        e = ArrayBuffer.isView(r);
      } else {
        e = r && r.buffer && $u(r.buffer);
      }
      return e;
    }
    function Mf(r) {
      return typeof r === "string";
    }
    function Lf(r) {
      return typeof r === "number";
    }
    function Zu(r) {
      return r !== null && typeof r === "object";
    }
    function ii(r) {
      if (Lt.call(r) !== "[object Object]") {
        return false;
      }
      var e = Object.getPrototypeOf(r);
      return e === null || e === Object.prototype;
    }
    function Df(r) {
      return Lt.call(r) === "[object Date]";
    }
    function qf(r) {
      return Lt.call(r) === "[object File]";
    }
    function Uf(r) {
      return Lt.call(r) === "[object Blob]";
    }
    function Hu(r) {
      return Lt.call(r) === "[object Function]";
    }
    function Vf(r) {
      return Zu(r) && Hu(r.pipe);
    }
    function zf(r) {
      return Lt.call(r) === "[object URLSearchParams]";
    }
    function Ff(r) {
      return r.trim ? r.trim() : r.replace(/^\s+|\s+$/g, "");
    }
    function Kf() {
      if (typeof navigator !== "undefined" && (navigator.product === "ReactNative" || navigator.product === "NativeScript" || navigator.product === "NS")) {
        return false;
      }
      return typeof window !== "undefined" && typeof document !== "undefined";
    }
    function xa(r, e) {
      if (r === null || typeof r === "undefined") {
        return;
      }
      if (typeof r !== "object") {
        r = [r];
      }
      if (va(r)) {
        for (var t = 0, n = r.length; t < n; t++) {
          e.call(null, r[t], t, r);
        }
      } else {
        for (var i in r) {
          if (Object.prototype.hasOwnProperty.call(r, i)) {
            e.call(null, r[i], i, r);
          }
        }
      }
    }
    function _a() {
      var r = {};
      function e(i, s) {
        if (ii(r[s]) && ii(i)) {
          r[s] = _a(r[s], i);
        } else if (ii(i)) {
          r[s] = _a({}, i);
        } else if (va(i)) {
          r[s] = i.slice();
        } else {
          r[s] = i;
        }
      }
      for (var t = 0, n = arguments.length; t < n; t++) {
        xa(arguments[t], e);
      }
      return r;
    }
    function Bf(r, e, t) {
      xa(e, function n(i, s) {
        if (t && typeof i === "function") {
          r[s] = jf(i, t);
        } else {
          r[s] = i;
        }
      });
      return r;
    }
    function $f(r) {
      if (r.charCodeAt(0) === 65279) {
        r = r.slice(1);
      }
      return r;
    }
    Qu.exports = {
      isArray: va,
      isArrayBuffer: $u,
      isBuffer: kf,
      isFormData: Rf,
      isArrayBufferView: Nf,
      isString: Mf,
      isNumber: Lf,
      isObject: Zu,
      isPlainObject: ii,
      isUndefined: wa,
      isDate: Df,
      isFile: qf,
      isBlob: Uf,
      isFunction: Hu,
      isStream: Vf,
      isURLSearchParams: zf,
      isStandardBrowserEnv: Kf,
      forEach: xa,
      merge: _a,
      extend: Bf,
      trim: Ff,
      stripBOM: $f
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/helpers/buildURL.js
  var Oa = N((fv, Yu) => {
    "use strict";
    var Pr = Se();
    function Ju(r) {
      return encodeURIComponent(r).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
    }
    Yu.exports = function r(e, t, n) {
      if (!t) {
        return e;
      }
      var i;
      if (n) {
        i = n(t);
      } else if (Pr.isURLSearchParams(t)) {
        i = t.toString();
      } else {
        var s = [];
        Pr.forEach(t, function o(u, l) {
          if (u === null || typeof u === "undefined") {
            return;
          }
          if (Pr.isArray(u)) {
            l = l + "[]";
          } else {
            u = [u];
          }
          Pr.forEach(u, function c(b) {
            if (Pr.isDate(b)) {
              b = b.toISOString();
            } else if (Pr.isObject(b)) {
              b = JSON.stringify(b);
            }
            s.push(Ju(l) + "=" + Ju(b));
          });
        });
        i = s.join("&");
      }
      if (i) {
        var a = e.indexOf("#");
        if (a !== -1) {
          e = e.slice(0, a);
        }
        e += (e.indexOf("?") === -1 ? "?" : "&") + i;
      }
      return e;
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/core/InterceptorManager.js
  var Gu = N((mv, Wu) => {
    "use strict";
    var Zf = Se();
    function si() {
      this.handlers = [];
    }
    si.prototype.use = function r(e, t, n) {
      this.handlers.push({
        fulfilled: e,
        rejected: t,
        synchronous: n ? n.synchronous : false,
        runWhen: n ? n.runWhen : null
      });
      return this.handlers.length - 1;
    };
    si.prototype.eject = function r(e) {
      if (this.handlers[e]) {
        this.handlers[e] = null;
      }
    };
    si.prototype.forEach = function r(e) {
      Zf.forEach(this.handlers, function t(n) {
        if (n !== null) {
          e(n);
        }
      });
    };
    Wu.exports = si;
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/helpers/normalizeHeaderName.js
  var el = N((yv, Xu) => {
    "use strict";
    var Hf = Se();
    Xu.exports = function r(e, t) {
      Hf.forEach(e, function n(i, s) {
        if (s !== t && s.toUpperCase() === t.toUpperCase()) {
          e[t] = i;
          delete e[s];
        }
      });
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/core/enhanceError.js
  var Pa = N((bv, tl) => {
    "use strict";
    tl.exports = function r(e, t, n, i, s) {
      e.config = t;
      if (n) {
        e.code = n;
      }
      e.request = i;
      e.response = s;
      e.isAxiosError = true;
      e.toJSON = function a() {
        return {
          // Standard
          message: this.message,
          name: this.name,
          // Microsoft
          description: this.description,
          number: this.number,
          // Mozilla
          fileName: this.fileName,
          lineNumber: this.lineNumber,
          columnNumber: this.columnNumber,
          stack: this.stack,
          // Axios
          config: this.config,
          code: this.code,
          status: this.response && this.response.status ? this.response.status : null
        };
      };
      return e;
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/defaults/transitional.js
  var Aa = N((gv, rl) => {
    "use strict";
    rl.exports = {
      silentJSONParsing: true,
      forcedJSONParsing: true,
      clarifyTimeoutError: false
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/core/createError.js
  var Ea = N((wv, nl) => {
    "use strict";
    var Qf = Pa();
    nl.exports = function r(e, t, n, i, s) {
      var a = new Error(e);
      return Qf(a, t, n, i, s);
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/core/settle.js
  var sl = N((_v, il) => {
    "use strict";
    var Jf = Ea();
    il.exports = function r(e, t, n) {
      var i = n.config.validateStatus;
      if (!n.status || !i || i(n.status)) {
        e(n);
      } else {
        t(Jf(
          "Request failed with status code " + n.status,
          n.config,
          null,
          n.request,
          n
        ));
      }
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/helpers/cookies.js
  var ol = N((vv, al) => {
    "use strict";
    var ai = Se();
    al.exports = ai.isStandardBrowserEnv() ? (
      // Standard browser envs support document.cookie
      function r() {
        return {
          write: function e(t, n, i, s, a, o) {
            var u = [];
            u.push(t + "=" + encodeURIComponent(n));
            if (ai.isNumber(i)) {
              u.push("expires=" + new Date(i).toGMTString());
            }
            if (ai.isString(s)) {
              u.push("path=" + s);
            }
            if (ai.isString(a)) {
              u.push("domain=" + a);
            }
            if (o === true) {
              u.push("secure");
            }
            document.cookie = u.join("; ");
          },
          read: function e(t) {
            var n = document.cookie.match(new RegExp("(^|;\\s*)(" + t + ")=([^;]*)"));
            return n ? decodeURIComponent(n[3]) : null;
          },
          remove: function e(t) {
            this.write(t, "", Date.now() - 864e5);
          }
        };
      }()
    ) : (
      // Non standard browser env (web workers, react-native) lack needed support.
      function r() {
        return {
          write: function e() {
          },
          read: function e() {
            return null;
          },
          remove: function e() {
          }
        };
      }()
    );
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/helpers/isAbsoluteURL.js
  var ll = N((xv, ul) => {
    "use strict";
    ul.exports = function r(e) {
      return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(e);
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/helpers/combineURLs.js
  var dl = N((Ov, cl) => {
    "use strict";
    cl.exports = function r(e, t) {
      return t ? e.replace(/\/+$/, "") + "/" + t.replace(/^\/+/, "") : e;
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/core/buildFullPath.js
  var hl = N((Pv, pl) => {
    "use strict";
    var Yf = ll();
    var Wf = dl();
    pl.exports = function r(e, t) {
      if (e && !Yf(t)) {
        return Wf(e, t);
      }
      return t;
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/helpers/parseHeaders.js
  var ml = N((Av, fl) => {
    "use strict";
    var Ta = Se();
    var Gf = [
      "age",
      "authorization",
      "content-length",
      "content-type",
      "etag",
      "expires",
      "from",
      "host",
      "if-modified-since",
      "if-unmodified-since",
      "last-modified",
      "location",
      "max-forwards",
      "proxy-authorization",
      "referer",
      "retry-after",
      "user-agent"
    ];
    fl.exports = function r(e) {
      var t = {};
      var n;
      var i;
      var s;
      if (!e) {
        return t;
      }
      Ta.forEach(e.split("\n"), function a(o) {
        s = o.indexOf(":");
        n = Ta.trim(o.substr(0, s)).toLowerCase();
        i = Ta.trim(o.substr(s + 1));
        if (n) {
          if (t[n] && Gf.indexOf(n) >= 0) {
            return;
          }
          if (n === "set-cookie") {
            t[n] = (t[n] ? t[n] : []).concat([i]);
          } else {
            t[n] = t[n] ? t[n] + ", " + i : i;
          }
        }
      });
      return t;
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/helpers/isURLSameOrigin.js
  var gl = N((Ev, bl) => {
    "use strict";
    var yl = Se();
    bl.exports = yl.isStandardBrowserEnv() ? (
      // Standard browser envs have full support of the APIs needed to test
      // whether the request URL is of the same origin as current location.
      function r() {
        var e = /(msie|trident)/i.test(navigator.userAgent);
        var t = document.createElement("a");
        var n;
        function i(s) {
          var a = s;
          if (e) {
            t.setAttribute("href", a);
            a = t.href;
          }
          t.setAttribute("href", a);
          return {
            href: t.href,
            protocol: t.protocol ? t.protocol.replace(/:$/, "") : "",
            host: t.host,
            search: t.search ? t.search.replace(/^\?/, "") : "",
            hash: t.hash ? t.hash.replace(/^#/, "") : "",
            hostname: t.hostname,
            port: t.port,
            pathname: t.pathname.charAt(0) === "/" ? t.pathname : "/" + t.pathname
          };
        }
        n = i(window.location.href);
        return function s(a) {
          var o = yl.isString(a) ? i(a) : a;
          return o.protocol === n.protocol && o.host === n.host;
        };
      }()
    ) : (
      // Non standard browser envs (web workers, react-native) lack needed support.
      function r() {
        return function e() {
          return true;
        };
      }()
    );
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/cancel/Cancel.js
  var gn = N((Tv, wl) => {
    "use strict";
    function Ia(r) {
      this.message = r;
    }
    Ia.prototype.toString = function r() {
      return "Cancel" + (this.message ? ": " + this.message : "");
    };
    Ia.prototype.__CANCEL__ = true;
    wl.exports = Ia;
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/adapters/xhr.js
  var Sa = N((Iv, _l) => {
    "use strict";
    var oi = Se();
    var Xf = sl();
    var em = ol();
    var tm = Oa();
    var rm = hl();
    var nm = ml();
    var im = gl();
    var Ca = Ea();
    var sm = Aa();
    var am = gn();
    _l.exports = function r(e) {
      return new Promise(function t(n, i) {
        var s = e.data;
        var a = e.headers;
        var o = e.responseType;
        var u;
        function l() {
          if (e.cancelToken) {
            e.cancelToken.unsubscribe(u);
          }
          if (e.signal) {
            e.signal.removeEventListener("abort", u);
          }
        }
        if (oi.isFormData(s)) {
          delete a["Content-Type"];
        }
        var c = new XMLHttpRequest();
        if (e.auth) {
          var b = e.auth.username || "";
          var _ = e.auth.password ? unescape(encodeURIComponent(e.auth.password)) : "";
          a.Authorization = "Basic " + btoa(b + ":" + _);
        }
        var x = rm(e.baseURL, e.url);
        c.open(e.method.toUpperCase(), tm(x, e.params, e.paramsSerializer), true);
        c.timeout = e.timeout;
        function f() {
          if (!c) {
            return;
          }
          var S = "getAllResponseHeaders" in c ? nm(c.getAllResponseHeaders()) : null;
          var k = !o || o === "text" || o === "json" ? c.responseText : c.response;
          var R = {
            data: k,
            status: c.status,
            statusText: c.statusText,
            headers: S,
            config: e,
            request: c
          };
          Xf(function U(g) {
            n(g);
            l();
          }, function U(g) {
            i(g);
            l();
          }, R);
          c = null;
        }
        if ("onloadend" in c) {
          c.onloadend = f;
        } else {
          c.onreadystatechange = function S() {
            if (!c || c.readyState !== 4) {
              return;
            }
            if (c.status === 0 && !(c.responseURL && c.responseURL.indexOf("file:") === 0)) {
              return;
            }
            setTimeout(f);
          };
        }
        c.onabort = function S() {
          if (!c) {
            return;
          }
          i(Ca("Request aborted", e, "ECONNABORTED", c));
          c = null;
        };
        c.onerror = function S() {
          i(Ca("Network Error", e, null, c));
          c = null;
        };
        c.ontimeout = function S() {
          var k = e.timeout ? "timeout of " + e.timeout + "ms exceeded" : "timeout exceeded";
          var R = e.transitional || sm;
          if (e.timeoutErrorMessage) {
            k = e.timeoutErrorMessage;
          }
          i(Ca(
            k,
            e,
            R.clarifyTimeoutError ? "ETIMEDOUT" : "ECONNABORTED",
            c
          ));
          c = null;
        };
        if (oi.isStandardBrowserEnv()) {
          var P = (e.withCredentials || im(x)) && e.xsrfCookieName ? em.read(e.xsrfCookieName) : void 0;
          if (P) {
            a[e.xsrfHeaderName] = P;
          }
        }
        if ("setRequestHeader" in c) {
          oi.forEach(a, function S(k, R) {
            if (typeof s === "undefined" && R.toLowerCase() === "content-type") {
              delete a[R];
            } else {
              c.setRequestHeader(R, k);
            }
          });
        }
        if (!oi.isUndefined(e.withCredentials)) {
          c.withCredentials = !!e.withCredentials;
        }
        if (o && o !== "json") {
          c.responseType = e.responseType;
        }
        if (typeof e.onDownloadProgress === "function") {
          c.addEventListener("progress", e.onDownloadProgress);
        }
        if (typeof e.onUploadProgress === "function" && c.upload) {
          c.upload.addEventListener("progress", e.onUploadProgress);
        }
        if (e.cancelToken || e.signal) {
          u = function(S) {
            if (!c) {
              return;
            }
            i(!S || S && S.type ? new am("canceled") : S);
            c.abort();
            c = null;
          };
          e.cancelToken && e.cancelToken.subscribe(u);
          if (e.signal) {
            e.signal.aborted ? u() : e.signal.addEventListener("abort", u);
          }
        }
        if (!s) {
          s = null;
        }
        c.send(s);
      });
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/defaults/index.js
  var li = N((Cv, Ol) => {
    "use strict";
    var Oe = Se();
    var vl = el();
    var om = Pa();
    var um = Aa();
    var lm = {
      "Content-Type": "application/x-www-form-urlencoded"
    };
    function xl(r, e) {
      if (!Oe.isUndefined(r) && Oe.isUndefined(r["Content-Type"])) {
        r["Content-Type"] = e;
      }
    }
    function cm() {
      var r;
      if (typeof XMLHttpRequest !== "undefined") {
        r = Sa();
      } else if (typeof process !== "undefined" && Object.prototype.toString.call(process) === "[object process]") {
        r = Sa();
      }
      return r;
    }
    function dm(r, e, t) {
      if (Oe.isString(r)) {
        try {
          (e || JSON.parse)(r);
          return Oe.trim(r);
        } catch (n) {
          if (n.name !== "SyntaxError") {
            throw n;
          }
        }
      }
      return (t || JSON.stringify)(r);
    }
    var ui = {
      transitional: um,
      adapter: cm(),
      transformRequest: [function r(e, t) {
        vl(t, "Accept");
        vl(t, "Content-Type");
        if (Oe.isFormData(e) || Oe.isArrayBuffer(e) || Oe.isBuffer(e) || Oe.isStream(e) || Oe.isFile(e) || Oe.isBlob(e)) {
          return e;
        }
        if (Oe.isArrayBufferView(e)) {
          return e.buffer;
        }
        if (Oe.isURLSearchParams(e)) {
          xl(t, "application/x-www-form-urlencoded;charset=utf-8");
          return e.toString();
        }
        if (Oe.isObject(e) || t && t["Content-Type"] === "application/json") {
          xl(t, "application/json");
          return dm(e);
        }
        return e;
      }],
      transformResponse: [function r(e) {
        var t = this.transitional || ui.transitional;
        var n = t && t.silentJSONParsing;
        var i = t && t.forcedJSONParsing;
        var s = !n && this.responseType === "json";
        if (s || i && Oe.isString(e) && e.length) {
          try {
            return JSON.parse(e);
          } catch (a) {
            if (s) {
              if (a.name === "SyntaxError") {
                throw om(a, this, "E_JSON_PARSE");
              }
              throw a;
            }
          }
        }
        return e;
      }],
      /**
       * A timeout in milliseconds to abort a request. If set to 0 (default) a
       * timeout is not created.
       */
      timeout: 0,
      xsrfCookieName: "XSRF-TOKEN",
      xsrfHeaderName: "X-XSRF-TOKEN",
      maxContentLength: -1,
      maxBodyLength: -1,
      validateStatus: function r(e) {
        return e >= 200 && e < 300;
      },
      headers: {
        common: {
          "Accept": "application/json, text/plain, */*"
        }
      }
    };
    Oe.forEach(["delete", "get", "head"], function r(e) {
      ui.headers[e] = {};
    });
    Oe.forEach(["post", "put", "patch"], function r(e) {
      ui.headers[e] = Oe.merge(lm);
    });
    Ol.exports = ui;
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/core/transformData.js
  var Al = N((Sv, Pl) => {
    "use strict";
    var pm = Se();
    var hm = li();
    Pl.exports = function r(e, t, n) {
      var i = this || hm;
      pm.forEach(n, function s(a) {
        e = a.call(i, e, t);
      });
      return e;
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/cancel/isCancel.js
  var ja = N((jv, El) => {
    "use strict";
    El.exports = function r(e) {
      return !!(e && e.__CANCEL__);
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/core/dispatchRequest.js
  var Cl = N((kv, Il) => {
    "use strict";
    var Tl = Se();
    var ka = Al();
    var fm = ja();
    var mm = li();
    var ym = gn();
    function Ra(r) {
      if (r.cancelToken) {
        r.cancelToken.throwIfRequested();
      }
      if (r.signal && r.signal.aborted) {
        throw new ym("canceled");
      }
    }
    Il.exports = function r(e) {
      Ra(e);
      e.headers = e.headers || {};
      e.data = ka.call(
        e,
        e.data,
        e.headers,
        e.transformRequest
      );
      e.headers = Tl.merge(
        e.headers.common || {},
        e.headers[e.method] || {},
        e.headers
      );
      Tl.forEach(
        ["delete", "get", "head", "post", "put", "patch", "common"],
        function n(i) {
          delete e.headers[i];
        }
      );
      var t = e.adapter || mm.adapter;
      return t(e).then(function n(i) {
        Ra(e);
        i.data = ka.call(
          e,
          i.data,
          i.headers,
          e.transformResponse
        );
        return i;
      }, function n(i) {
        if (!fm(i)) {
          Ra(e);
          if (i && i.response) {
            i.response.data = ka.call(
              e,
              i.response.data,
              i.response.headers,
              e.transformResponse
            );
          }
        }
        return Promise.reject(i);
      });
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/core/mergeConfig.js
  var Na = N((Rv, Sl) => {
    "use strict";
    var ze = Se();
    Sl.exports = function r(e, t) {
      t = t || {};
      var n = {};
      function i(c, b) {
        if (ze.isPlainObject(c) && ze.isPlainObject(b)) {
          return ze.merge(c, b);
        } else if (ze.isPlainObject(b)) {
          return ze.merge({}, b);
        } else if (ze.isArray(b)) {
          return b.slice();
        }
        return b;
      }
      function s(c) {
        if (!ze.isUndefined(t[c])) {
          return i(e[c], t[c]);
        } else if (!ze.isUndefined(e[c])) {
          return i(void 0, e[c]);
        }
      }
      function a(c) {
        if (!ze.isUndefined(t[c])) {
          return i(void 0, t[c]);
        }
      }
      function o(c) {
        if (!ze.isUndefined(t[c])) {
          return i(void 0, t[c]);
        } else if (!ze.isUndefined(e[c])) {
          return i(void 0, e[c]);
        }
      }
      function u(c) {
        if (c in t) {
          return i(e[c], t[c]);
        } else if (c in e) {
          return i(void 0, e[c]);
        }
      }
      var l = {
        "url": a,
        "method": a,
        "data": a,
        "baseURL": o,
        "transformRequest": o,
        "transformResponse": o,
        "paramsSerializer": o,
        "timeout": o,
        "timeoutMessage": o,
        "withCredentials": o,
        "adapter": o,
        "responseType": o,
        "xsrfCookieName": o,
        "xsrfHeaderName": o,
        "onUploadProgress": o,
        "onDownloadProgress": o,
        "decompress": o,
        "maxContentLength": o,
        "maxBodyLength": o,
        "transport": o,
        "httpAgent": o,
        "httpsAgent": o,
        "cancelToken": o,
        "socketPath": o,
        "responseEncoding": o,
        "validateStatus": u
      };
      ze.forEach(Object.keys(e).concat(Object.keys(t)), function c(b) {
        var _ = l[b] || s;
        var x = _(b);
        ze.isUndefined(x) && _ !== u || (n[b] = x);
      });
      return n;
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/env/data.js
  var Ma = N((Nv, jl) => {
    jl.exports = {
      "version": "0.26.1"
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/helpers/validator.js
  var Nl = N((Mv, Rl) => {
    "use strict";
    var bm = Ma().version;
    var La = {};
    ["object", "boolean", "number", "function", "string", "symbol"].forEach(function(r, e) {
      La[r] = function t(n) {
        return typeof n === r || "a" + (e < 1 ? "n " : " ") + r;
      };
    });
    var kl = {};
    La.transitional = function r(e, t, n) {
      function i(s, a) {
        return "[Axios v" + bm + "] Transitional option '" + s + "'" + a + (n ? ". " + n : "");
      }
      return function(s, a, o) {
        if (e === false) {
          throw new Error(i(a, " has been removed" + (t ? " in " + t : "")));
        }
        if (t && !kl[a]) {
          kl[a] = true;
          console.warn(
            i(
              a,
              " has been deprecated since v" + t + " and will be removed in the near future"
            )
          );
        }
        return e ? e(s, a, o) : true;
      };
    };
    function gm(r, e, t) {
      if (typeof r !== "object") {
        throw new TypeError("options must be an object");
      }
      var n = Object.keys(r);
      var i = n.length;
      while (i-- > 0) {
        var s = n[i];
        var a = e[s];
        if (a) {
          var o = r[s];
          var u = o === void 0 || a(o, s, r);
          if (u !== true) {
            throw new TypeError("option " + s + " must be " + u);
          }
          continue;
        }
        if (t !== true) {
          throw Error("Unknown option " + s);
        }
      }
    }
    Rl.exports = {
      assertOptions: gm,
      validators: La
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/core/Axios.js
  var Vl = N((Lv, Ul) => {
    "use strict";
    var Dl = Se();
    var wm = Oa();
    var Ml = Gu();
    var Ll = Cl();
    var ci = Na();
    var ql = Nl();
    var Ar = ql.validators;
    function wn(r) {
      this.defaults = r;
      this.interceptors = {
        request: new Ml(),
        response: new Ml()
      };
    }
    wn.prototype.request = function r(e, t) {
      if (typeof e === "string") {
        t = t || {};
        t.url = e;
      } else {
        t = e || {};
      }
      t = ci(this.defaults, t);
      if (t.method) {
        t.method = t.method.toLowerCase();
      } else if (this.defaults.method) {
        t.method = this.defaults.method.toLowerCase();
      } else {
        t.method = "get";
      }
      var n = t.transitional;
      if (n !== void 0) {
        ql.assertOptions(n, {
          silentJSONParsing: Ar.transitional(Ar.boolean),
          forcedJSONParsing: Ar.transitional(Ar.boolean),
          clarifyTimeoutError: Ar.transitional(Ar.boolean)
        }, false);
      }
      var i = [];
      var s = true;
      this.interceptors.request.forEach(function _(x) {
        if (typeof x.runWhen === "function" && x.runWhen(t) === false) {
          return;
        }
        s = s && x.synchronous;
        i.unshift(x.fulfilled, x.rejected);
      });
      var a = [];
      this.interceptors.response.forEach(function _(x) {
        a.push(x.fulfilled, x.rejected);
      });
      var o;
      if (!s) {
        var u = [Ll, void 0];
        Array.prototype.unshift.apply(u, i);
        u = u.concat(a);
        o = Promise.resolve(t);
        while (u.length) {
          o = o.then(u.shift(), u.shift());
        }
        return o;
      }
      var l = t;
      while (i.length) {
        var c = i.shift();
        var b = i.shift();
        try {
          l = c(l);
        } catch (_) {
          b(_);
          break;
        }
      }
      try {
        o = Ll(l);
      } catch (_) {
        return Promise.reject(_);
      }
      while (a.length) {
        o = o.then(a.shift(), a.shift());
      }
      return o;
    };
    wn.prototype.getUri = function r(e) {
      e = ci(this.defaults, e);
      return wm(e.url, e.params, e.paramsSerializer).replace(/^\?/, "");
    };
    Dl.forEach(["delete", "get", "head", "options"], function r(e) {
      wn.prototype[e] = function(t, n) {
        return this.request(ci(n || {}, {
          method: e,
          url: t,
          data: (n || {}).data
        }));
      };
    });
    Dl.forEach(["post", "put", "patch"], function r(e) {
      wn.prototype[e] = function(t, n, i) {
        return this.request(ci(i || {}, {
          method: e,
          url: t,
          data: n
        }));
      };
    });
    Ul.exports = wn;
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/cancel/CancelToken.js
  var Fl = N((Dv, zl) => {
    "use strict";
    var _m = gn();
    function Er(r) {
      if (typeof r !== "function") {
        throw new TypeError("executor must be a function.");
      }
      var e;
      this.promise = new Promise(function n(i) {
        e = i;
      });
      var t = this;
      this.promise.then(function(n) {
        if (!t._listeners)
          return;
        var i;
        var s = t._listeners.length;
        for (i = 0; i < s; i++) {
          t._listeners[i](n);
        }
        t._listeners = null;
      });
      this.promise.then = function(n) {
        var i;
        var s = new Promise(function(a) {
          t.subscribe(a);
          i = a;
        }).then(n);
        s.cancel = function a() {
          t.unsubscribe(i);
        };
        return s;
      };
      r(function n(i) {
        if (t.reason) {
          return;
        }
        t.reason = new _m(i);
        e(t.reason);
      });
    }
    Er.prototype.throwIfRequested = function r() {
      if (this.reason) {
        throw this.reason;
      }
    };
    Er.prototype.subscribe = function r(e) {
      if (this.reason) {
        e(this.reason);
        return;
      }
      if (this._listeners) {
        this._listeners.push(e);
      } else {
        this._listeners = [e];
      }
    };
    Er.prototype.unsubscribe = function r(e) {
      if (!this._listeners) {
        return;
      }
      var t = this._listeners.indexOf(e);
      if (t !== -1) {
        this._listeners.splice(t, 1);
      }
    };
    Er.source = function r() {
      var e;
      var t = new Er(function n(i) {
        e = i;
      });
      return {
        token: t,
        cancel: e
      };
    };
    zl.exports = Er;
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/helpers/spread.js
  var Bl = N((qv, Kl) => {
    "use strict";
    Kl.exports = function r(e) {
      return function t(n) {
        return e.apply(null, n);
      };
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/helpers/isAxiosError.js
  var Zl = N((Uv, $l) => {
    "use strict";
    var vm = Se();
    $l.exports = function r(e) {
      return vm.isObject(e) && e.isAxiosError === true;
    };
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/lib/axios.js
  var Jl = N((Vv, Da) => {
    "use strict";
    var Hl = Se();
    var xm = ga();
    var di = Vl();
    var Om = Na();
    var Pm = li();
    function Ql(r) {
      var e = new di(r);
      var t = xm(di.prototype.request, e);
      Hl.extend(t, di.prototype, e);
      Hl.extend(t, e);
      t.create = function n(i) {
        return Ql(Om(r, i));
      };
      return t;
    }
    var ot = Ql(Pm);
    ot.Axios = di;
    ot.Cancel = gn();
    ot.CancelToken = Fl();
    ot.isCancel = ja();
    ot.VERSION = Ma().version;
    ot.all = function r(e) {
      return Promise.all(e);
    };
    ot.spread = Bl();
    ot.isAxiosError = Zl();
    Da.exports = ot;
    Da.exports.default = ot;
  });

  // node_modules/.pnpm/axios@0.26.1/node_modules/axios/index.js
  var qa = N((zv, Yl) => {
    Yl.exports = Jl();
  });

  // node_modules/.pnpm/openai@3.3.0/node_modules/openai/dist/base.js
  var za = N((rt) => {
    "use strict";
    Object.defineProperty(rt, "__esModule", { value: true });
    rt.RequiredError = rt.BaseAPI = rt.COLLECTION_FORMATS = rt.BASE_PATH = void 0;
    var Am = qa();
    rt.BASE_PATH = "https://api.openai.com/v1".replace(/\/+$/, "");
    rt.COLLECTION_FORMATS = {
      csv: ",",
      ssv: " ",
      tsv: "	",
      pipes: "|"
    };
    var Ua = class {
      constructor(e, t = rt.BASE_PATH, n = Am.default) {
        this.basePath = t;
        this.axios = n;
        if (e) {
          this.configuration = e;
          this.basePath = e.basePath || this.basePath;
        }
      }
    };
    rt.BaseAPI = Ua;
    var Va = class extends Error {
      constructor(e, t) {
        super(t);
        this.field = e;
        this.name = "RequiredError";
      }
    };
    rt.RequiredError = Va;
  });

  // node_modules/.pnpm/openai@3.3.0/node_modules/openai/dist/common.js
  var Wl = N((pe) => {
    "use strict";
    var Ka = pe && pe.__awaiter || function(r, e, t, n) {
      function i(s) {
        return s instanceof t ? s : new t(function(a) {
          a(s);
        });
      }
      return new (t || (t = Promise))(function(s, a) {
        function o(c) {
          try {
            l(n.next(c));
          } catch (b) {
            a(b);
          }
        }
        function u(c) {
          try {
            l(n["throw"](c));
          } catch (b) {
            a(b);
          }
        }
        function l(c) {
          c.done ? s(c.value) : i(c.value).then(o, u);
        }
        l((n = n.apply(r, e || [])).next());
      });
    };
    Object.defineProperty(pe, "__esModule", { value: true });
    pe.createRequestFunction = pe.toPathString = pe.serializeDataIfNeeded = pe.setSearchParams = pe.setOAuthToObject = pe.setBearerAuthToObject = pe.setBasicAuthToObject = pe.setApiKeyToObject = pe.assertParamExists = pe.DUMMY_BASE_URL = void 0;
    var Em = za();
    pe.DUMMY_BASE_URL = "https://example.com";
    pe.assertParamExists = function(r, e, t) {
      if (t === null || t === void 0) {
        throw new Em.RequiredError(e, `Required parameter ${e} was null or undefined when calling ${r}.`);
      }
    };
    pe.setApiKeyToObject = function(r, e, t) {
      return Ka(this, void 0, void 0, function* () {
        if (t && t.apiKey) {
          const n = typeof t.apiKey === "function" ? yield t.apiKey(e) : yield t.apiKey;
          r[e] = n;
        }
      });
    };
    pe.setBasicAuthToObject = function(r, e) {
      if (e && (e.username || e.password)) {
        r["auth"] = { username: e.username, password: e.password };
      }
    };
    pe.setBearerAuthToObject = function(r, e) {
      return Ka(this, void 0, void 0, function* () {
        if (e && e.accessToken) {
          const t = typeof e.accessToken === "function" ? yield e.accessToken() : yield e.accessToken;
          r["Authorization"] = "Bearer " + t;
        }
      });
    };
    pe.setOAuthToObject = function(r, e, t, n) {
      return Ka(this, void 0, void 0, function* () {
        if (n && n.accessToken) {
          const i = typeof n.accessToken === "function" ? yield n.accessToken(e, t) : yield n.accessToken;
          r["Authorization"] = "Bearer " + i;
        }
      });
    };
    function Fa(r, e, t = "") {
      if (e == null)
        return;
      if (typeof e === "object") {
        if (Array.isArray(e)) {
          e.forEach((n) => Fa(r, n, t));
        } else {
          Object.keys(e).forEach((n) => Fa(r, e[n], `${t}${t !== "" ? "." : ""}${n}`));
        }
      } else {
        if (r.has(t)) {
          r.append(t, e);
        } else {
          r.set(t, e);
        }
      }
    }
    pe.setSearchParams = function(r, ...e) {
      const t = new URLSearchParams(r.search);
      Fa(t, e);
      r.search = t.toString();
    };
    pe.serializeDataIfNeeded = function(r, e, t) {
      const n = typeof r !== "string";
      const i = n && t && t.isJsonMime ? t.isJsonMime(e.headers["Content-Type"]) : n;
      return i ? JSON.stringify(r !== void 0 ? r : {}) : r || "";
    };
    pe.toPathString = function(r) {
      return r.pathname + r.search + r.hash;
    };
    pe.createRequestFunction = function(r, e, t, n) {
      return (i = e, s = t) => {
        const a = Object.assign(Object.assign({}, r.options), { url: ((n === null || n === void 0 ? void 0 : n.basePath) || s) + r.url });
        return i.request(a);
      };
    };
  });

  // node_modules/.pnpm/openai@3.3.0/node_modules/openai/dist/api.js
  var Gl = N(($) => {
    "use strict";
    var K = $ && $.__awaiter || function(r, e, t, n) {
      function i(s) {
        return s instanceof t ? s : new t(function(a) {
          a(s);
        });
      }
      return new (t || (t = Promise))(function(s, a) {
        function o(c) {
          try {
            l(n.next(c));
          } catch (b) {
            a(b);
          }
        }
        function u(c) {
          try {
            l(n["throw"](c));
          } catch (b) {
            a(b);
          }
        }
        function l(c) {
          c.done ? s(c.value) : i(c.value).then(o, u);
        }
        l((n = n.apply(r, e || [])).next());
      });
    };
    Object.defineProperty($, "__esModule", { value: true });
    $.OpenAIApi = $.OpenAIApiFactory = $.OpenAIApiFp = $.OpenAIApiAxiosParamCreator = $.CreateImageRequestResponseFormatEnum = $.CreateImageRequestSizeEnum = $.ChatCompletionResponseMessageRoleEnum = $.ChatCompletionRequestMessageRoleEnum = void 0;
    var ae = qa();
    var O = Wl();
    var se = za();
    $.ChatCompletionRequestMessageRoleEnum = {
      System: "system",
      User: "user",
      Assistant: "assistant",
      Function: "function"
    };
    $.ChatCompletionResponseMessageRoleEnum = {
      System: "system",
      User: "user",
      Assistant: "assistant",
      Function: "function"
    };
    $.CreateImageRequestSizeEnum = {
      _256x256: "256x256",
      _512x512: "512x512",
      _1024x1024: "1024x1024"
    };
    $.CreateImageRequestResponseFormatEnum = {
      Url: "url",
      B64Json: "b64_json"
    };
    $.OpenAIApiAxiosParamCreator = function(r) {
      return {
        /**
         *
         * @summary Immediately cancel a fine-tune job.
         * @param {string} fineTuneId The ID of the fine-tune job to cancel
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        cancelFineTune: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("cancelFineTune", "fineTuneId", e);
          const n = `/fine-tunes/{fine_tune_id}/cancel`.replace(`{${"fine_tune_id"}}`, encodeURIComponent(String(e)));
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "POST" }, s), t);
          const o = {};
          const u = {};
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Answers the specified question using the provided documents and examples.  The endpoint first [searches](/docs/api-reference/searches) over provided documents or files to find relevant context. The relevant context is combined with the provided examples and question to create the prompt for [completion](/docs/api-reference/completions).
         * @param {CreateAnswerRequest} createAnswerRequest
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        createAnswer: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createAnswer", "createAnswerRequest", e);
          const n = `/answers`;
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "POST" }, s), t);
          const o = {};
          const u = {};
          o["Content-Type"] = "application/json";
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          a.data = O.serializeDataIfNeeded(e, a, r);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Creates a model response for the given chat conversation.
         * @param {CreateChatCompletionRequest} createChatCompletionRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createChatCompletion: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createChatCompletion", "createChatCompletionRequest", e);
          const n = `/chat/completions`;
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "POST" }, s), t);
          const o = {};
          const u = {};
          o["Content-Type"] = "application/json";
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          a.data = O.serializeDataIfNeeded(e, a, r);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Classifies the specified `query` using provided examples.  The endpoint first [searches](/docs/api-reference/searches) over the labeled examples to select the ones most relevant for the particular query. Then, the relevant examples are combined with the query to construct a prompt to produce the final label via the [completions](/docs/api-reference/completions) endpoint.  Labeled examples can be provided via an uploaded `file`, or explicitly listed in the request using the `examples` parameter for quick tests and small scale use cases.
         * @param {CreateClassificationRequest} createClassificationRequest
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        createClassification: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createClassification", "createClassificationRequest", e);
          const n = `/classifications`;
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "POST" }, s), t);
          const o = {};
          const u = {};
          o["Content-Type"] = "application/json";
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          a.data = O.serializeDataIfNeeded(e, a, r);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Creates a completion for the provided prompt and parameters.
         * @param {CreateCompletionRequest} createCompletionRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createCompletion: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createCompletion", "createCompletionRequest", e);
          const n = `/completions`;
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "POST" }, s), t);
          const o = {};
          const u = {};
          o["Content-Type"] = "application/json";
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          a.data = O.serializeDataIfNeeded(e, a, r);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Creates a new edit for the provided input, instruction, and parameters.
         * @param {CreateEditRequest} createEditRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createEdit: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createEdit", "createEditRequest", e);
          const n = `/edits`;
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "POST" }, s), t);
          const o = {};
          const u = {};
          o["Content-Type"] = "application/json";
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          a.data = O.serializeDataIfNeeded(e, a, r);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Creates an embedding vector representing the input text.
         * @param {CreateEmbeddingRequest} createEmbeddingRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createEmbedding: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createEmbedding", "createEmbeddingRequest", e);
          const n = `/embeddings`;
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "POST" }, s), t);
          const o = {};
          const u = {};
          o["Content-Type"] = "application/json";
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          a.data = O.serializeDataIfNeeded(e, a, r);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Upload a file that contains document(s) to be used across various endpoints/features. Currently, the size of all the files uploaded by one organization can be up to 1 GB. Please contact us if you need to increase the storage limit.
         * @param {File} file Name of the [JSON Lines](https://jsonlines.readthedocs.io/en/latest/) file to be uploaded.  If the &#x60;purpose&#x60; is set to \\\&quot;fine-tune\\\&quot;, each line is a JSON record with \\\&quot;prompt\\\&quot; and \\\&quot;completion\\\&quot; fields representing your [training examples](/docs/guides/fine-tuning/prepare-training-data).
         * @param {string} purpose The intended purpose of the uploaded documents.  Use \\\&quot;fine-tune\\\&quot; for [Fine-tuning](/docs/api-reference/fine-tunes). This allows us to validate the format of the uploaded file.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createFile: (e, t, n = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createFile", "file", e);
          O.assertParamExists("createFile", "purpose", t);
          const i = `/files`;
          const s = new URL(i, O.DUMMY_BASE_URL);
          let a;
          if (r) {
            a = r.baseOptions;
          }
          const o = Object.assign(Object.assign({ method: "POST" }, a), n);
          const u = {};
          const l = {};
          const c = new (r && r.formDataCtor || FormData)();
          if (e !== void 0) {
            c.append("file", e);
          }
          if (t !== void 0) {
            c.append("purpose", t);
          }
          u["Content-Type"] = "multipart/form-data";
          O.setSearchParams(s, l);
          let b = a && a.headers ? a.headers : {};
          o.headers = Object.assign(Object.assign(Object.assign(Object.assign({}, u), c.getHeaders()), b), n.headers);
          o.data = c;
          return {
            url: O.toPathString(s),
            options: o
          };
        }),
        /**
         *
         * @summary Creates a job that fine-tunes a specified model from a given dataset.  Response includes details of the enqueued job including job status and the name of the fine-tuned models once complete.  [Learn more about Fine-tuning](/docs/guides/fine-tuning)
         * @param {CreateFineTuneRequest} createFineTuneRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createFineTune: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createFineTune", "createFineTuneRequest", e);
          const n = `/fine-tunes`;
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "POST" }, s), t);
          const o = {};
          const u = {};
          o["Content-Type"] = "application/json";
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          a.data = O.serializeDataIfNeeded(e, a, r);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Creates an image given a prompt.
         * @param {CreateImageRequest} createImageRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createImage: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createImage", "createImageRequest", e);
          const n = `/images/generations`;
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "POST" }, s), t);
          const o = {};
          const u = {};
          o["Content-Type"] = "application/json";
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          a.data = O.serializeDataIfNeeded(e, a, r);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Creates an edited or extended image given an original image and a prompt.
         * @param {File} image The image to edit. Must be a valid PNG file, less than 4MB, and square. If mask is not provided, image must have transparency, which will be used as the mask.
         * @param {string} prompt A text description of the desired image(s). The maximum length is 1000 characters.
         * @param {File} [mask] An additional image whose fully transparent areas (e.g. where alpha is zero) indicate where &#x60;image&#x60; should be edited. Must be a valid PNG file, less than 4MB, and have the same dimensions as &#x60;image&#x60;.
         * @param {number} [n] The number of images to generate. Must be between 1 and 10.
         * @param {string} [size] The size of the generated images. Must be one of &#x60;256x256&#x60;, &#x60;512x512&#x60;, or &#x60;1024x1024&#x60;.
         * @param {string} [responseFormat] The format in which the generated images are returned. Must be one of &#x60;url&#x60; or &#x60;b64_json&#x60;.
         * @param {string} [user] A unique identifier representing your end-user, which can help OpenAI to monitor and detect abuse. [Learn more](/docs/guides/safety-best-practices/end-user-ids).
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createImageEdit: (e, t, n, i, s, a, o, u = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createImageEdit", "image", e);
          O.assertParamExists("createImageEdit", "prompt", t);
          const l = `/images/edits`;
          const c = new URL(l, O.DUMMY_BASE_URL);
          let b;
          if (r) {
            b = r.baseOptions;
          }
          const _ = Object.assign(Object.assign({ method: "POST" }, b), u);
          const x = {};
          const f = {};
          const P = new (r && r.formDataCtor || FormData)();
          if (e !== void 0) {
            P.append("image", e);
          }
          if (n !== void 0) {
            P.append("mask", n);
          }
          if (t !== void 0) {
            P.append("prompt", t);
          }
          if (i !== void 0) {
            P.append("n", i);
          }
          if (s !== void 0) {
            P.append("size", s);
          }
          if (a !== void 0) {
            P.append("response_format", a);
          }
          if (o !== void 0) {
            P.append("user", o);
          }
          x["Content-Type"] = "multipart/form-data";
          O.setSearchParams(c, f);
          let S = b && b.headers ? b.headers : {};
          _.headers = Object.assign(Object.assign(Object.assign(Object.assign({}, x), P.getHeaders()), S), u.headers);
          _.data = P;
          return {
            url: O.toPathString(c),
            options: _
          };
        }),
        /**
         *
         * @summary Creates a variation of a given image.
         * @param {File} image The image to use as the basis for the variation(s). Must be a valid PNG file, less than 4MB, and square.
         * @param {number} [n] The number of images to generate. Must be between 1 and 10.
         * @param {string} [size] The size of the generated images. Must be one of &#x60;256x256&#x60;, &#x60;512x512&#x60;, or &#x60;1024x1024&#x60;.
         * @param {string} [responseFormat] The format in which the generated images are returned. Must be one of &#x60;url&#x60; or &#x60;b64_json&#x60;.
         * @param {string} [user] A unique identifier representing your end-user, which can help OpenAI to monitor and detect abuse. [Learn more](/docs/guides/safety-best-practices/end-user-ids).
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createImageVariation: (e, t, n, i, s, a = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createImageVariation", "image", e);
          const o = `/images/variations`;
          const u = new URL(o, O.DUMMY_BASE_URL);
          let l;
          if (r) {
            l = r.baseOptions;
          }
          const c = Object.assign(Object.assign({ method: "POST" }, l), a);
          const b = {};
          const _ = {};
          const x = new (r && r.formDataCtor || FormData)();
          if (e !== void 0) {
            x.append("image", e);
          }
          if (t !== void 0) {
            x.append("n", t);
          }
          if (n !== void 0) {
            x.append("size", n);
          }
          if (i !== void 0) {
            x.append("response_format", i);
          }
          if (s !== void 0) {
            x.append("user", s);
          }
          b["Content-Type"] = "multipart/form-data";
          O.setSearchParams(u, _);
          let f = l && l.headers ? l.headers : {};
          c.headers = Object.assign(Object.assign(Object.assign(Object.assign({}, b), x.getHeaders()), f), a.headers);
          c.data = x;
          return {
            url: O.toPathString(u),
            options: c
          };
        }),
        /**
         *
         * @summary Classifies if text violates OpenAI\'s Content Policy
         * @param {CreateModerationRequest} createModerationRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createModeration: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createModeration", "createModerationRequest", e);
          const n = `/moderations`;
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "POST" }, s), t);
          const o = {};
          const u = {};
          o["Content-Type"] = "application/json";
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          a.data = O.serializeDataIfNeeded(e, a, r);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary The search endpoint computes similarity scores between provided query and documents. Documents can be passed directly to the API if there are no more than 200 of them.  To go beyond the 200 document limit, documents can be processed offline and then used for efficient retrieval at query time. When `file` is set, the search endpoint searches over all the documents in the given file and returns up to the `max_rerank` number of documents. These documents will be returned along with their search scores.  The similarity score is a positive score that usually ranges from 0 to 300 (but can sometimes go higher), where a score above 200 usually means the document is semantically similar to the query.
         * @param {string} engineId The ID of the engine to use for this request.  You can select one of &#x60;ada&#x60;, &#x60;babbage&#x60;, &#x60;curie&#x60;, or &#x60;davinci&#x60;.
         * @param {CreateSearchRequest} createSearchRequest
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        createSearch: (e, t, n = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createSearch", "engineId", e);
          O.assertParamExists("createSearch", "createSearchRequest", t);
          const i = `/engines/{engine_id}/search`.replace(`{${"engine_id"}}`, encodeURIComponent(String(e)));
          const s = new URL(i, O.DUMMY_BASE_URL);
          let a;
          if (r) {
            a = r.baseOptions;
          }
          const o = Object.assign(Object.assign({ method: "POST" }, a), n);
          const u = {};
          const l = {};
          u["Content-Type"] = "application/json";
          O.setSearchParams(s, l);
          let c = a && a.headers ? a.headers : {};
          o.headers = Object.assign(Object.assign(Object.assign({}, u), c), n.headers);
          o.data = O.serializeDataIfNeeded(t, o, r);
          return {
            url: O.toPathString(s),
            options: o
          };
        }),
        /**
         *
         * @summary Transcribes audio into the input language.
         * @param {File} file The audio file object (not file name) to transcribe, in one of these formats: mp3, mp4, mpeg, mpga, m4a, wav, or webm.
         * @param {string} model ID of the model to use. Only &#x60;whisper-1&#x60; is currently available.
         * @param {string} [prompt] An optional text to guide the model\\\&#39;s style or continue a previous audio segment. The [prompt](/docs/guides/speech-to-text/prompting) should match the audio language.
         * @param {string} [responseFormat] The format of the transcript output, in one of these options: json, text, srt, verbose_json, or vtt.
         * @param {number} [temperature] The sampling temperature, between 0 and 1. Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic. If set to 0, the model will use [log probability](https://en.wikipedia.org/wiki/Log_probability) to automatically increase the temperature until certain thresholds are hit.
         * @param {string} [language] The language of the input audio. Supplying the input language in [ISO-639-1](https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes) format will improve accuracy and latency.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createTranscription: (e, t, n, i, s, a, o = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createTranscription", "file", e);
          O.assertParamExists("createTranscription", "model", t);
          const u = `/audio/transcriptions`;
          const l = new URL(u, O.DUMMY_BASE_URL);
          let c;
          if (r) {
            c = r.baseOptions;
          }
          const b = Object.assign(Object.assign({ method: "POST" }, c), o);
          const _ = {};
          const x = {};
          const f = new (r && r.formDataCtor || FormData)();
          if (e !== void 0) {
            f.append("file", e);
          }
          if (t !== void 0) {
            f.append("model", t);
          }
          if (n !== void 0) {
            f.append("prompt", n);
          }
          if (i !== void 0) {
            f.append("response_format", i);
          }
          if (s !== void 0) {
            f.append("temperature", s);
          }
          if (a !== void 0) {
            f.append("language", a);
          }
          _["Content-Type"] = "multipart/form-data";
          O.setSearchParams(l, x);
          let P = c && c.headers ? c.headers : {};
          b.headers = Object.assign(Object.assign(Object.assign(Object.assign({}, _), f.getHeaders()), P), o.headers);
          b.data = f;
          return {
            url: O.toPathString(l),
            options: b
          };
        }),
        /**
         *
         * @summary Translates audio into into English.
         * @param {File} file The audio file object (not file name) translate, in one of these formats: mp3, mp4, mpeg, mpga, m4a, wav, or webm.
         * @param {string} model ID of the model to use. Only &#x60;whisper-1&#x60; is currently available.
         * @param {string} [prompt] An optional text to guide the model\\\&#39;s style or continue a previous audio segment. The [prompt](/docs/guides/speech-to-text/prompting) should be in English.
         * @param {string} [responseFormat] The format of the transcript output, in one of these options: json, text, srt, verbose_json, or vtt.
         * @param {number} [temperature] The sampling temperature, between 0 and 1. Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic. If set to 0, the model will use [log probability](https://en.wikipedia.org/wiki/Log_probability) to automatically increase the temperature until certain thresholds are hit.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createTranslation: (e, t, n, i, s, a = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("createTranslation", "file", e);
          O.assertParamExists("createTranslation", "model", t);
          const o = `/audio/translations`;
          const u = new URL(o, O.DUMMY_BASE_URL);
          let l;
          if (r) {
            l = r.baseOptions;
          }
          const c = Object.assign(Object.assign({ method: "POST" }, l), a);
          const b = {};
          const _ = {};
          const x = new (r && r.formDataCtor || FormData)();
          if (e !== void 0) {
            x.append("file", e);
          }
          if (t !== void 0) {
            x.append("model", t);
          }
          if (n !== void 0) {
            x.append("prompt", n);
          }
          if (i !== void 0) {
            x.append("response_format", i);
          }
          if (s !== void 0) {
            x.append("temperature", s);
          }
          b["Content-Type"] = "multipart/form-data";
          O.setSearchParams(u, _);
          let f = l && l.headers ? l.headers : {};
          c.headers = Object.assign(Object.assign(Object.assign(Object.assign({}, b), x.getHeaders()), f), a.headers);
          c.data = x;
          return {
            url: O.toPathString(u),
            options: c
          };
        }),
        /**
         *
         * @summary Delete a file.
         * @param {string} fileId The ID of the file to use for this request
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteFile: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("deleteFile", "fileId", e);
          const n = `/files/{file_id}`.replace(`{${"file_id"}}`, encodeURIComponent(String(e)));
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "DELETE" }, s), t);
          const o = {};
          const u = {};
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Delete a fine-tuned model. You must have the Owner role in your organization.
         * @param {string} model The model to delete
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteModel: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("deleteModel", "model", e);
          const n = `/models/{model}`.replace(`{${"model"}}`, encodeURIComponent(String(e)));
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "DELETE" }, s), t);
          const o = {};
          const u = {};
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Returns the contents of the specified file
         * @param {string} fileId The ID of the file to use for this request
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        downloadFile: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("downloadFile", "fileId", e);
          const n = `/files/{file_id}/content`.replace(`{${"file_id"}}`, encodeURIComponent(String(e)));
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "GET" }, s), t);
          const o = {};
          const u = {};
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Lists the currently available (non-finetuned) models, and provides basic information about each one such as the owner and availability.
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        listEngines: (e = {}) => K(this, void 0, void 0, function* () {
          const t = `/engines`;
          const n = new URL(t, O.DUMMY_BASE_URL);
          let i;
          if (r) {
            i = r.baseOptions;
          }
          const s = Object.assign(Object.assign({ method: "GET" }, i), e);
          const a = {};
          const o = {};
          O.setSearchParams(n, o);
          let u = i && i.headers ? i.headers : {};
          s.headers = Object.assign(Object.assign(Object.assign({}, a), u), e.headers);
          return {
            url: O.toPathString(n),
            options: s
          };
        }),
        /**
         *
         * @summary Returns a list of files that belong to the user\'s organization.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        listFiles: (e = {}) => K(this, void 0, void 0, function* () {
          const t = `/files`;
          const n = new URL(t, O.DUMMY_BASE_URL);
          let i;
          if (r) {
            i = r.baseOptions;
          }
          const s = Object.assign(Object.assign({ method: "GET" }, i), e);
          const a = {};
          const o = {};
          O.setSearchParams(n, o);
          let u = i && i.headers ? i.headers : {};
          s.headers = Object.assign(Object.assign(Object.assign({}, a), u), e.headers);
          return {
            url: O.toPathString(n),
            options: s
          };
        }),
        /**
         *
         * @summary Get fine-grained status updates for a fine-tune job.
         * @param {string} fineTuneId The ID of the fine-tune job to get events for.
         * @param {boolean} [stream] Whether to stream events for the fine-tune job. If set to true, events will be sent as data-only [server-sent events](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events#Event_stream_format) as they become available. The stream will terminate with a &#x60;data: [DONE]&#x60; message when the job is finished (succeeded, cancelled, or failed).  If set to false, only events generated so far will be returned.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        listFineTuneEvents: (e, t, n = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("listFineTuneEvents", "fineTuneId", e);
          const i = `/fine-tunes/{fine_tune_id}/events`.replace(`{${"fine_tune_id"}}`, encodeURIComponent(String(e)));
          const s = new URL(i, O.DUMMY_BASE_URL);
          let a;
          if (r) {
            a = r.baseOptions;
          }
          const o = Object.assign(Object.assign({ method: "GET" }, a), n);
          const u = {};
          const l = {};
          if (t !== void 0) {
            l["stream"] = t;
          }
          O.setSearchParams(s, l);
          let c = a && a.headers ? a.headers : {};
          o.headers = Object.assign(Object.assign(Object.assign({}, u), c), n.headers);
          return {
            url: O.toPathString(s),
            options: o
          };
        }),
        /**
         *
         * @summary List your organization\'s fine-tuning jobs
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        listFineTunes: (e = {}) => K(this, void 0, void 0, function* () {
          const t = `/fine-tunes`;
          const n = new URL(t, O.DUMMY_BASE_URL);
          let i;
          if (r) {
            i = r.baseOptions;
          }
          const s = Object.assign(Object.assign({ method: "GET" }, i), e);
          const a = {};
          const o = {};
          O.setSearchParams(n, o);
          let u = i && i.headers ? i.headers : {};
          s.headers = Object.assign(Object.assign(Object.assign({}, a), u), e.headers);
          return {
            url: O.toPathString(n),
            options: s
          };
        }),
        /**
         *
         * @summary Lists the currently available models, and provides basic information about each one such as the owner and availability.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        listModels: (e = {}) => K(this, void 0, void 0, function* () {
          const t = `/models`;
          const n = new URL(t, O.DUMMY_BASE_URL);
          let i;
          if (r) {
            i = r.baseOptions;
          }
          const s = Object.assign(Object.assign({ method: "GET" }, i), e);
          const a = {};
          const o = {};
          O.setSearchParams(n, o);
          let u = i && i.headers ? i.headers : {};
          s.headers = Object.assign(Object.assign(Object.assign({}, a), u), e.headers);
          return {
            url: O.toPathString(n),
            options: s
          };
        }),
        /**
         *
         * @summary Retrieves a model instance, providing basic information about it such as the owner and availability.
         * @param {string} engineId The ID of the engine to use for this request
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        retrieveEngine: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("retrieveEngine", "engineId", e);
          const n = `/engines/{engine_id}`.replace(`{${"engine_id"}}`, encodeURIComponent(String(e)));
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "GET" }, s), t);
          const o = {};
          const u = {};
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Returns information about a specific file.
         * @param {string} fileId The ID of the file to use for this request
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        retrieveFile: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("retrieveFile", "fileId", e);
          const n = `/files/{file_id}`.replace(`{${"file_id"}}`, encodeURIComponent(String(e)));
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "GET" }, s), t);
          const o = {};
          const u = {};
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Gets info about the fine-tune job.  [Learn more about Fine-tuning](/docs/guides/fine-tuning)
         * @param {string} fineTuneId The ID of the fine-tune job
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        retrieveFineTune: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("retrieveFineTune", "fineTuneId", e);
          const n = `/fine-tunes/{fine_tune_id}`.replace(`{${"fine_tune_id"}}`, encodeURIComponent(String(e)));
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "GET" }, s), t);
          const o = {};
          const u = {};
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          return {
            url: O.toPathString(i),
            options: a
          };
        }),
        /**
         *
         * @summary Retrieves a model instance, providing basic information about the model such as the owner and permissioning.
         * @param {string} model The ID of the model to use for this request
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        retrieveModel: (e, t = {}) => K(this, void 0, void 0, function* () {
          O.assertParamExists("retrieveModel", "model", e);
          const n = `/models/{model}`.replace(`{${"model"}}`, encodeURIComponent(String(e)));
          const i = new URL(n, O.DUMMY_BASE_URL);
          let s;
          if (r) {
            s = r.baseOptions;
          }
          const a = Object.assign(Object.assign({ method: "GET" }, s), t);
          const o = {};
          const u = {};
          O.setSearchParams(i, u);
          let l = s && s.headers ? s.headers : {};
          a.headers = Object.assign(Object.assign(Object.assign({}, o), l), t.headers);
          return {
            url: O.toPathString(i),
            options: a
          };
        })
      };
    };
    $.OpenAIApiFp = function(r) {
      const e = $.OpenAIApiAxiosParamCreator(r);
      return {
        /**
         *
         * @summary Immediately cancel a fine-tune job.
         * @param {string} fineTuneId The ID of the fine-tune job to cancel
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        cancelFineTune(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.cancelFineTune(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Answers the specified question using the provided documents and examples.  The endpoint first [searches](/docs/api-reference/searches) over provided documents or files to find relevant context. The relevant context is combined with the provided examples and question to create the prompt for [completion](/docs/api-reference/completions).
         * @param {CreateAnswerRequest} createAnswerRequest
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        createAnswer(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.createAnswer(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Creates a model response for the given chat conversation.
         * @param {CreateChatCompletionRequest} createChatCompletionRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createChatCompletion(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.createChatCompletion(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Classifies the specified `query` using provided examples.  The endpoint first [searches](/docs/api-reference/searches) over the labeled examples to select the ones most relevant for the particular query. Then, the relevant examples are combined with the query to construct a prompt to produce the final label via the [completions](/docs/api-reference/completions) endpoint.  Labeled examples can be provided via an uploaded `file`, or explicitly listed in the request using the `examples` parameter for quick tests and small scale use cases.
         * @param {CreateClassificationRequest} createClassificationRequest
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        createClassification(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.createClassification(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Creates a completion for the provided prompt and parameters.
         * @param {CreateCompletionRequest} createCompletionRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createCompletion(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.createCompletion(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Creates a new edit for the provided input, instruction, and parameters.
         * @param {CreateEditRequest} createEditRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createEdit(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.createEdit(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Creates an embedding vector representing the input text.
         * @param {CreateEmbeddingRequest} createEmbeddingRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createEmbedding(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.createEmbedding(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Upload a file that contains document(s) to be used across various endpoints/features. Currently, the size of all the files uploaded by one organization can be up to 1 GB. Please contact us if you need to increase the storage limit.
         * @param {File} file Name of the [JSON Lines](https://jsonlines.readthedocs.io/en/latest/) file to be uploaded.  If the &#x60;purpose&#x60; is set to \\\&quot;fine-tune\\\&quot;, each line is a JSON record with \\\&quot;prompt\\\&quot; and \\\&quot;completion\\\&quot; fields representing your [training examples](/docs/guides/fine-tuning/prepare-training-data).
         * @param {string} purpose The intended purpose of the uploaded documents.  Use \\\&quot;fine-tune\\\&quot; for [Fine-tuning](/docs/api-reference/fine-tunes). This allows us to validate the format of the uploaded file.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createFile(t, n, i) {
          return K(this, void 0, void 0, function* () {
            const s = yield e.createFile(t, n, i);
            return O.createRequestFunction(s, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Creates a job that fine-tunes a specified model from a given dataset.  Response includes details of the enqueued job including job status and the name of the fine-tuned models once complete.  [Learn more about Fine-tuning](/docs/guides/fine-tuning)
         * @param {CreateFineTuneRequest} createFineTuneRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createFineTune(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.createFineTune(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Creates an image given a prompt.
         * @param {CreateImageRequest} createImageRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createImage(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.createImage(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Creates an edited or extended image given an original image and a prompt.
         * @param {File} image The image to edit. Must be a valid PNG file, less than 4MB, and square. If mask is not provided, image must have transparency, which will be used as the mask.
         * @param {string} prompt A text description of the desired image(s). The maximum length is 1000 characters.
         * @param {File} [mask] An additional image whose fully transparent areas (e.g. where alpha is zero) indicate where &#x60;image&#x60; should be edited. Must be a valid PNG file, less than 4MB, and have the same dimensions as &#x60;image&#x60;.
         * @param {number} [n] The number of images to generate. Must be between 1 and 10.
         * @param {string} [size] The size of the generated images. Must be one of &#x60;256x256&#x60;, &#x60;512x512&#x60;, or &#x60;1024x1024&#x60;.
         * @param {string} [responseFormat] The format in which the generated images are returned. Must be one of &#x60;url&#x60; or &#x60;b64_json&#x60;.
         * @param {string} [user] A unique identifier representing your end-user, which can help OpenAI to monitor and detect abuse. [Learn more](/docs/guides/safety-best-practices/end-user-ids).
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createImageEdit(t, n, i, s, a, o, u, l) {
          return K(this, void 0, void 0, function* () {
            const c = yield e.createImageEdit(t, n, i, s, a, o, u, l);
            return O.createRequestFunction(c, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Creates a variation of a given image.
         * @param {File} image The image to use as the basis for the variation(s). Must be a valid PNG file, less than 4MB, and square.
         * @param {number} [n] The number of images to generate. Must be between 1 and 10.
         * @param {string} [size] The size of the generated images. Must be one of &#x60;256x256&#x60;, &#x60;512x512&#x60;, or &#x60;1024x1024&#x60;.
         * @param {string} [responseFormat] The format in which the generated images are returned. Must be one of &#x60;url&#x60; or &#x60;b64_json&#x60;.
         * @param {string} [user] A unique identifier representing your end-user, which can help OpenAI to monitor and detect abuse. [Learn more](/docs/guides/safety-best-practices/end-user-ids).
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createImageVariation(t, n, i, s, a, o) {
          return K(this, void 0, void 0, function* () {
            const u = yield e.createImageVariation(t, n, i, s, a, o);
            return O.createRequestFunction(u, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Classifies if text violates OpenAI\'s Content Policy
         * @param {CreateModerationRequest} createModerationRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createModeration(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.createModeration(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary The search endpoint computes similarity scores between provided query and documents. Documents can be passed directly to the API if there are no more than 200 of them.  To go beyond the 200 document limit, documents can be processed offline and then used for efficient retrieval at query time. When `file` is set, the search endpoint searches over all the documents in the given file and returns up to the `max_rerank` number of documents. These documents will be returned along with their search scores.  The similarity score is a positive score that usually ranges from 0 to 300 (but can sometimes go higher), where a score above 200 usually means the document is semantically similar to the query.
         * @param {string} engineId The ID of the engine to use for this request.  You can select one of &#x60;ada&#x60;, &#x60;babbage&#x60;, &#x60;curie&#x60;, or &#x60;davinci&#x60;.
         * @param {CreateSearchRequest} createSearchRequest
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        createSearch(t, n, i) {
          return K(this, void 0, void 0, function* () {
            const s = yield e.createSearch(t, n, i);
            return O.createRequestFunction(s, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Transcribes audio into the input language.
         * @param {File} file The audio file object (not file name) to transcribe, in one of these formats: mp3, mp4, mpeg, mpga, m4a, wav, or webm.
         * @param {string} model ID of the model to use. Only &#x60;whisper-1&#x60; is currently available.
         * @param {string} [prompt] An optional text to guide the model\\\&#39;s style or continue a previous audio segment. The [prompt](/docs/guides/speech-to-text/prompting) should match the audio language.
         * @param {string} [responseFormat] The format of the transcript output, in one of these options: json, text, srt, verbose_json, or vtt.
         * @param {number} [temperature] The sampling temperature, between 0 and 1. Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic. If set to 0, the model will use [log probability](https://en.wikipedia.org/wiki/Log_probability) to automatically increase the temperature until certain thresholds are hit.
         * @param {string} [language] The language of the input audio. Supplying the input language in [ISO-639-1](https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes) format will improve accuracy and latency.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createTranscription(t, n, i, s, a, o, u) {
          return K(this, void 0, void 0, function* () {
            const l = yield e.createTranscription(t, n, i, s, a, o, u);
            return O.createRequestFunction(l, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Translates audio into into English.
         * @param {File} file The audio file object (not file name) translate, in one of these formats: mp3, mp4, mpeg, mpga, m4a, wav, or webm.
         * @param {string} model ID of the model to use. Only &#x60;whisper-1&#x60; is currently available.
         * @param {string} [prompt] An optional text to guide the model\\\&#39;s style or continue a previous audio segment. The [prompt](/docs/guides/speech-to-text/prompting) should be in English.
         * @param {string} [responseFormat] The format of the transcript output, in one of these options: json, text, srt, verbose_json, or vtt.
         * @param {number} [temperature] The sampling temperature, between 0 and 1. Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic. If set to 0, the model will use [log probability](https://en.wikipedia.org/wiki/Log_probability) to automatically increase the temperature until certain thresholds are hit.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createTranslation(t, n, i, s, a, o) {
          return K(this, void 0, void 0, function* () {
            const u = yield e.createTranslation(t, n, i, s, a, o);
            return O.createRequestFunction(u, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Delete a file.
         * @param {string} fileId The ID of the file to use for this request
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteFile(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.deleteFile(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Delete a fine-tuned model. You must have the Owner role in your organization.
         * @param {string} model The model to delete
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteModel(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.deleteModel(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Returns the contents of the specified file
         * @param {string} fileId The ID of the file to use for this request
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        downloadFile(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.downloadFile(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Lists the currently available (non-finetuned) models, and provides basic information about each one such as the owner and availability.
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        listEngines(t) {
          return K(this, void 0, void 0, function* () {
            const n = yield e.listEngines(t);
            return O.createRequestFunction(n, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Returns a list of files that belong to the user\'s organization.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        listFiles(t) {
          return K(this, void 0, void 0, function* () {
            const n = yield e.listFiles(t);
            return O.createRequestFunction(n, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Get fine-grained status updates for a fine-tune job.
         * @param {string} fineTuneId The ID of the fine-tune job to get events for.
         * @param {boolean} [stream] Whether to stream events for the fine-tune job. If set to true, events will be sent as data-only [server-sent events](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events#Event_stream_format) as they become available. The stream will terminate with a &#x60;data: [DONE]&#x60; message when the job is finished (succeeded, cancelled, or failed).  If set to false, only events generated so far will be returned.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        listFineTuneEvents(t, n, i) {
          return K(this, void 0, void 0, function* () {
            const s = yield e.listFineTuneEvents(t, n, i);
            return O.createRequestFunction(s, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary List your organization\'s fine-tuning jobs
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        listFineTunes(t) {
          return K(this, void 0, void 0, function* () {
            const n = yield e.listFineTunes(t);
            return O.createRequestFunction(n, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Lists the currently available models, and provides basic information about each one such as the owner and availability.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        listModels(t) {
          return K(this, void 0, void 0, function* () {
            const n = yield e.listModels(t);
            return O.createRequestFunction(n, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Retrieves a model instance, providing basic information about it such as the owner and availability.
         * @param {string} engineId The ID of the engine to use for this request
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        retrieveEngine(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.retrieveEngine(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Returns information about a specific file.
         * @param {string} fileId The ID of the file to use for this request
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        retrieveFile(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.retrieveFile(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Gets info about the fine-tune job.  [Learn more about Fine-tuning](/docs/guides/fine-tuning)
         * @param {string} fineTuneId The ID of the fine-tune job
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        retrieveFineTune(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.retrieveFineTune(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        },
        /**
         *
         * @summary Retrieves a model instance, providing basic information about the model such as the owner and permissioning.
         * @param {string} model The ID of the model to use for this request
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        retrieveModel(t, n) {
          return K(this, void 0, void 0, function* () {
            const i = yield e.retrieveModel(t, n);
            return O.createRequestFunction(i, ae.default, se.BASE_PATH, r);
          });
        }
      };
    };
    $.OpenAIApiFactory = function(r, e, t) {
      const n = $.OpenAIApiFp(r);
      return {
        /**
         *
         * @summary Immediately cancel a fine-tune job.
         * @param {string} fineTuneId The ID of the fine-tune job to cancel
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        cancelFineTune(i, s) {
          return n.cancelFineTune(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Answers the specified question using the provided documents and examples.  The endpoint first [searches](/docs/api-reference/searches) over provided documents or files to find relevant context. The relevant context is combined with the provided examples and question to create the prompt for [completion](/docs/api-reference/completions).
         * @param {CreateAnswerRequest} createAnswerRequest
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        createAnswer(i, s) {
          return n.createAnswer(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Creates a model response for the given chat conversation.
         * @param {CreateChatCompletionRequest} createChatCompletionRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createChatCompletion(i, s) {
          return n.createChatCompletion(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Classifies the specified `query` using provided examples.  The endpoint first [searches](/docs/api-reference/searches) over the labeled examples to select the ones most relevant for the particular query. Then, the relevant examples are combined with the query to construct a prompt to produce the final label via the [completions](/docs/api-reference/completions) endpoint.  Labeled examples can be provided via an uploaded `file`, or explicitly listed in the request using the `examples` parameter for quick tests and small scale use cases.
         * @param {CreateClassificationRequest} createClassificationRequest
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        createClassification(i, s) {
          return n.createClassification(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Creates a completion for the provided prompt and parameters.
         * @param {CreateCompletionRequest} createCompletionRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createCompletion(i, s) {
          return n.createCompletion(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Creates a new edit for the provided input, instruction, and parameters.
         * @param {CreateEditRequest} createEditRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createEdit(i, s) {
          return n.createEdit(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Creates an embedding vector representing the input text.
         * @param {CreateEmbeddingRequest} createEmbeddingRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createEmbedding(i, s) {
          return n.createEmbedding(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Upload a file that contains document(s) to be used across various endpoints/features. Currently, the size of all the files uploaded by one organization can be up to 1 GB. Please contact us if you need to increase the storage limit.
         * @param {File} file Name of the [JSON Lines](https://jsonlines.readthedocs.io/en/latest/) file to be uploaded.  If the &#x60;purpose&#x60; is set to \\\&quot;fine-tune\\\&quot;, each line is a JSON record with \\\&quot;prompt\\\&quot; and \\\&quot;completion\\\&quot; fields representing your [training examples](/docs/guides/fine-tuning/prepare-training-data).
         * @param {string} purpose The intended purpose of the uploaded documents.  Use \\\&quot;fine-tune\\\&quot; for [Fine-tuning](/docs/api-reference/fine-tunes). This allows us to validate the format of the uploaded file.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createFile(i, s, a) {
          return n.createFile(i, s, a).then((o) => o(t, e));
        },
        /**
         *
         * @summary Creates a job that fine-tunes a specified model from a given dataset.  Response includes details of the enqueued job including job status and the name of the fine-tuned models once complete.  [Learn more about Fine-tuning](/docs/guides/fine-tuning)
         * @param {CreateFineTuneRequest} createFineTuneRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createFineTune(i, s) {
          return n.createFineTune(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Creates an image given a prompt.
         * @param {CreateImageRequest} createImageRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createImage(i, s) {
          return n.createImage(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Creates an edited or extended image given an original image and a prompt.
         * @param {File} image The image to edit. Must be a valid PNG file, less than 4MB, and square. If mask is not provided, image must have transparency, which will be used as the mask.
         * @param {string} prompt A text description of the desired image(s). The maximum length is 1000 characters.
         * @param {File} [mask] An additional image whose fully transparent areas (e.g. where alpha is zero) indicate where &#x60;image&#x60; should be edited. Must be a valid PNG file, less than 4MB, and have the same dimensions as &#x60;image&#x60;.
         * @param {number} [n] The number of images to generate. Must be between 1 and 10.
         * @param {string} [size] The size of the generated images. Must be one of &#x60;256x256&#x60;, &#x60;512x512&#x60;, or &#x60;1024x1024&#x60;.
         * @param {string} [responseFormat] The format in which the generated images are returned. Must be one of &#x60;url&#x60; or &#x60;b64_json&#x60;.
         * @param {string} [user] A unique identifier representing your end-user, which can help OpenAI to monitor and detect abuse. [Learn more](/docs/guides/safety-best-practices/end-user-ids).
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createImageEdit(i, s, a, o, u, l, c, b) {
          return n.createImageEdit(i, s, a, o, u, l, c, b).then((_) => _(t, e));
        },
        /**
         *
         * @summary Creates a variation of a given image.
         * @param {File} image The image to use as the basis for the variation(s). Must be a valid PNG file, less than 4MB, and square.
         * @param {number} [n] The number of images to generate. Must be between 1 and 10.
         * @param {string} [size] The size of the generated images. Must be one of &#x60;256x256&#x60;, &#x60;512x512&#x60;, or &#x60;1024x1024&#x60;.
         * @param {string} [responseFormat] The format in which the generated images are returned. Must be one of &#x60;url&#x60; or &#x60;b64_json&#x60;.
         * @param {string} [user] A unique identifier representing your end-user, which can help OpenAI to monitor and detect abuse. [Learn more](/docs/guides/safety-best-practices/end-user-ids).
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createImageVariation(i, s, a, o, u, l) {
          return n.createImageVariation(i, s, a, o, u, l).then((c) => c(t, e));
        },
        /**
         *
         * @summary Classifies if text violates OpenAI\'s Content Policy
         * @param {CreateModerationRequest} createModerationRequest
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createModeration(i, s) {
          return n.createModeration(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary The search endpoint computes similarity scores between provided query and documents. Documents can be passed directly to the API if there are no more than 200 of them.  To go beyond the 200 document limit, documents can be processed offline and then used for efficient retrieval at query time. When `file` is set, the search endpoint searches over all the documents in the given file and returns up to the `max_rerank` number of documents. These documents will be returned along with their search scores.  The similarity score is a positive score that usually ranges from 0 to 300 (but can sometimes go higher), where a score above 200 usually means the document is semantically similar to the query.
         * @param {string} engineId The ID of the engine to use for this request.  You can select one of &#x60;ada&#x60;, &#x60;babbage&#x60;, &#x60;curie&#x60;, or &#x60;davinci&#x60;.
         * @param {CreateSearchRequest} createSearchRequest
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        createSearch(i, s, a) {
          return n.createSearch(i, s, a).then((o) => o(t, e));
        },
        /**
         *
         * @summary Transcribes audio into the input language.
         * @param {File} file The audio file object (not file name) to transcribe, in one of these formats: mp3, mp4, mpeg, mpga, m4a, wav, or webm.
         * @param {string} model ID of the model to use. Only &#x60;whisper-1&#x60; is currently available.
         * @param {string} [prompt] An optional text to guide the model\\\&#39;s style or continue a previous audio segment. The [prompt](/docs/guides/speech-to-text/prompting) should match the audio language.
         * @param {string} [responseFormat] The format of the transcript output, in one of these options: json, text, srt, verbose_json, or vtt.
         * @param {number} [temperature] The sampling temperature, between 0 and 1. Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic. If set to 0, the model will use [log probability](https://en.wikipedia.org/wiki/Log_probability) to automatically increase the temperature until certain thresholds are hit.
         * @param {string} [language] The language of the input audio. Supplying the input language in [ISO-639-1](https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes) format will improve accuracy and latency.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createTranscription(i, s, a, o, u, l, c) {
          return n.createTranscription(i, s, a, o, u, l, c).then((b) => b(t, e));
        },
        /**
         *
         * @summary Translates audio into into English.
         * @param {File} file The audio file object (not file name) translate, in one of these formats: mp3, mp4, mpeg, mpga, m4a, wav, or webm.
         * @param {string} model ID of the model to use. Only &#x60;whisper-1&#x60; is currently available.
         * @param {string} [prompt] An optional text to guide the model\\\&#39;s style or continue a previous audio segment. The [prompt](/docs/guides/speech-to-text/prompting) should be in English.
         * @param {string} [responseFormat] The format of the transcript output, in one of these options: json, text, srt, verbose_json, or vtt.
         * @param {number} [temperature] The sampling temperature, between 0 and 1. Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic. If set to 0, the model will use [log probability](https://en.wikipedia.org/wiki/Log_probability) to automatically increase the temperature until certain thresholds are hit.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createTranslation(i, s, a, o, u, l) {
          return n.createTranslation(i, s, a, o, u, l).then((c) => c(t, e));
        },
        /**
         *
         * @summary Delete a file.
         * @param {string} fileId The ID of the file to use for this request
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteFile(i, s) {
          return n.deleteFile(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Delete a fine-tuned model. You must have the Owner role in your organization.
         * @param {string} model The model to delete
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteModel(i, s) {
          return n.deleteModel(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Returns the contents of the specified file
         * @param {string} fileId The ID of the file to use for this request
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        downloadFile(i, s) {
          return n.downloadFile(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Lists the currently available (non-finetuned) models, and provides basic information about each one such as the owner and availability.
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        listEngines(i) {
          return n.listEngines(i).then((s) => s(t, e));
        },
        /**
         *
         * @summary Returns a list of files that belong to the user\'s organization.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        listFiles(i) {
          return n.listFiles(i).then((s) => s(t, e));
        },
        /**
         *
         * @summary Get fine-grained status updates for a fine-tune job.
         * @param {string} fineTuneId The ID of the fine-tune job to get events for.
         * @param {boolean} [stream] Whether to stream events for the fine-tune job. If set to true, events will be sent as data-only [server-sent events](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events#Event_stream_format) as they become available. The stream will terminate with a &#x60;data: [DONE]&#x60; message when the job is finished (succeeded, cancelled, or failed).  If set to false, only events generated so far will be returned.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        listFineTuneEvents(i, s, a) {
          return n.listFineTuneEvents(i, s, a).then((o) => o(t, e));
        },
        /**
         *
         * @summary List your organization\'s fine-tuning jobs
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        listFineTunes(i) {
          return n.listFineTunes(i).then((s) => s(t, e));
        },
        /**
         *
         * @summary Lists the currently available models, and provides basic information about each one such as the owner and availability.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        listModels(i) {
          return n.listModels(i).then((s) => s(t, e));
        },
        /**
         *
         * @summary Retrieves a model instance, providing basic information about it such as the owner and availability.
         * @param {string} engineId The ID of the engine to use for this request
         * @param {*} [options] Override http request option.
         * @deprecated
         * @throws {RequiredError}
         */
        retrieveEngine(i, s) {
          return n.retrieveEngine(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Returns information about a specific file.
         * @param {string} fileId The ID of the file to use for this request
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        retrieveFile(i, s) {
          return n.retrieveFile(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Gets info about the fine-tune job.  [Learn more about Fine-tuning](/docs/guides/fine-tuning)
         * @param {string} fineTuneId The ID of the fine-tune job
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        retrieveFineTune(i, s) {
          return n.retrieveFineTune(i, s).then((a) => a(t, e));
        },
        /**
         *
         * @summary Retrieves a model instance, providing basic information about the model such as the owner and permissioning.
         * @param {string} model The ID of the model to use for this request
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        retrieveModel(i, s) {
          return n.retrieveModel(i, s).then((a) => a(t, e));
        }
      };
    };
    var Ba = class extends se.BaseAPI {
      /**
       *
       * @summary Immediately cancel a fine-tune job.
       * @param {string} fineTuneId The ID of the fine-tune job to cancel
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      cancelFineTune(e, t) {
        return $.OpenAIApiFp(this.configuration).cancelFineTune(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Answers the specified question using the provided documents and examples.  The endpoint first [searches](/docs/api-reference/searches) over provided documents or files to find relevant context. The relevant context is combined with the provided examples and question to create the prompt for [completion](/docs/api-reference/completions).
       * @param {CreateAnswerRequest} createAnswerRequest
       * @param {*} [options] Override http request option.
       * @deprecated
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createAnswer(e, t) {
        return $.OpenAIApiFp(this.configuration).createAnswer(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Creates a model response for the given chat conversation.
       * @param {CreateChatCompletionRequest} createChatCompletionRequest
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createChatCompletion(e, t) {
        return $.OpenAIApiFp(this.configuration).createChatCompletion(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Classifies the specified `query` using provided examples.  The endpoint first [searches](/docs/api-reference/searches) over the labeled examples to select the ones most relevant for the particular query. Then, the relevant examples are combined with the query to construct a prompt to produce the final label via the [completions](/docs/api-reference/completions) endpoint.  Labeled examples can be provided via an uploaded `file`, or explicitly listed in the request using the `examples` parameter for quick tests and small scale use cases.
       * @param {CreateClassificationRequest} createClassificationRequest
       * @param {*} [options] Override http request option.
       * @deprecated
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createClassification(e, t) {
        return $.OpenAIApiFp(this.configuration).createClassification(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Creates a completion for the provided prompt and parameters.
       * @param {CreateCompletionRequest} createCompletionRequest
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createCompletion(e, t) {
        return $.OpenAIApiFp(this.configuration).createCompletion(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Creates a new edit for the provided input, instruction, and parameters.
       * @param {CreateEditRequest} createEditRequest
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createEdit(e, t) {
        return $.OpenAIApiFp(this.configuration).createEdit(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Creates an embedding vector representing the input text.
       * @param {CreateEmbeddingRequest} createEmbeddingRequest
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createEmbedding(e, t) {
        return $.OpenAIApiFp(this.configuration).createEmbedding(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Upload a file that contains document(s) to be used across various endpoints/features. Currently, the size of all the files uploaded by one organization can be up to 1 GB. Please contact us if you need to increase the storage limit.
       * @param {File} file Name of the [JSON Lines](https://jsonlines.readthedocs.io/en/latest/) file to be uploaded.  If the &#x60;purpose&#x60; is set to \\\&quot;fine-tune\\\&quot;, each line is a JSON record with \\\&quot;prompt\\\&quot; and \\\&quot;completion\\\&quot; fields representing your [training examples](/docs/guides/fine-tuning/prepare-training-data).
       * @param {string} purpose The intended purpose of the uploaded documents.  Use \\\&quot;fine-tune\\\&quot; for [Fine-tuning](/docs/api-reference/fine-tunes). This allows us to validate the format of the uploaded file.
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createFile(e, t, n) {
        return $.OpenAIApiFp(this.configuration).createFile(e, t, n).then((i) => i(this.axios, this.basePath));
      }
      /**
       *
       * @summary Creates a job that fine-tunes a specified model from a given dataset.  Response includes details of the enqueued job including job status and the name of the fine-tuned models once complete.  [Learn more about Fine-tuning](/docs/guides/fine-tuning)
       * @param {CreateFineTuneRequest} createFineTuneRequest
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createFineTune(e, t) {
        return $.OpenAIApiFp(this.configuration).createFineTune(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Creates an image given a prompt.
       * @param {CreateImageRequest} createImageRequest
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createImage(e, t) {
        return $.OpenAIApiFp(this.configuration).createImage(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Creates an edited or extended image given an original image and a prompt.
       * @param {File} image The image to edit. Must be a valid PNG file, less than 4MB, and square. If mask is not provided, image must have transparency, which will be used as the mask.
       * @param {string} prompt A text description of the desired image(s). The maximum length is 1000 characters.
       * @param {File} [mask] An additional image whose fully transparent areas (e.g. where alpha is zero) indicate where &#x60;image&#x60; should be edited. Must be a valid PNG file, less than 4MB, and have the same dimensions as &#x60;image&#x60;.
       * @param {number} [n] The number of images to generate. Must be between 1 and 10.
       * @param {string} [size] The size of the generated images. Must be one of &#x60;256x256&#x60;, &#x60;512x512&#x60;, or &#x60;1024x1024&#x60;.
       * @param {string} [responseFormat] The format in which the generated images are returned. Must be one of &#x60;url&#x60; or &#x60;b64_json&#x60;.
       * @param {string} [user] A unique identifier representing your end-user, which can help OpenAI to monitor and detect abuse. [Learn more](/docs/guides/safety-best-practices/end-user-ids).
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createImageEdit(e, t, n, i, s, a, o, u) {
        return $.OpenAIApiFp(this.configuration).createImageEdit(e, t, n, i, s, a, o, u).then((l) => l(this.axios, this.basePath));
      }
      /**
       *
       * @summary Creates a variation of a given image.
       * @param {File} image The image to use as the basis for the variation(s). Must be a valid PNG file, less than 4MB, and square.
       * @param {number} [n] The number of images to generate. Must be between 1 and 10.
       * @param {string} [size] The size of the generated images. Must be one of &#x60;256x256&#x60;, &#x60;512x512&#x60;, or &#x60;1024x1024&#x60;.
       * @param {string} [responseFormat] The format in which the generated images are returned. Must be one of &#x60;url&#x60; or &#x60;b64_json&#x60;.
       * @param {string} [user] A unique identifier representing your end-user, which can help OpenAI to monitor and detect abuse. [Learn more](/docs/guides/safety-best-practices/end-user-ids).
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createImageVariation(e, t, n, i, s, a) {
        return $.OpenAIApiFp(this.configuration).createImageVariation(e, t, n, i, s, a).then((o) => o(this.axios, this.basePath));
      }
      /**
       *
       * @summary Classifies if text violates OpenAI\'s Content Policy
       * @param {CreateModerationRequest} createModerationRequest
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createModeration(e, t) {
        return $.OpenAIApiFp(this.configuration).createModeration(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary The search endpoint computes similarity scores between provided query and documents. Documents can be passed directly to the API if there are no more than 200 of them.  To go beyond the 200 document limit, documents can be processed offline and then used for efficient retrieval at query time. When `file` is set, the search endpoint searches over all the documents in the given file and returns up to the `max_rerank` number of documents. These documents will be returned along with their search scores.  The similarity score is a positive score that usually ranges from 0 to 300 (but can sometimes go higher), where a score above 200 usually means the document is semantically similar to the query.
       * @param {string} engineId The ID of the engine to use for this request.  You can select one of &#x60;ada&#x60;, &#x60;babbage&#x60;, &#x60;curie&#x60;, or &#x60;davinci&#x60;.
       * @param {CreateSearchRequest} createSearchRequest
       * @param {*} [options] Override http request option.
       * @deprecated
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createSearch(e, t, n) {
        return $.OpenAIApiFp(this.configuration).createSearch(e, t, n).then((i) => i(this.axios, this.basePath));
      }
      /**
       *
       * @summary Transcribes audio into the input language.
       * @param {File} file The audio file object (not file name) to transcribe, in one of these formats: mp3, mp4, mpeg, mpga, m4a, wav, or webm.
       * @param {string} model ID of the model to use. Only &#x60;whisper-1&#x60; is currently available.
       * @param {string} [prompt] An optional text to guide the model\\\&#39;s style or continue a previous audio segment. The [prompt](/docs/guides/speech-to-text/prompting) should match the audio language.
       * @param {string} [responseFormat] The format of the transcript output, in one of these options: json, text, srt, verbose_json, or vtt.
       * @param {number} [temperature] The sampling temperature, between 0 and 1. Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic. If set to 0, the model will use [log probability](https://en.wikipedia.org/wiki/Log_probability) to automatically increase the temperature until certain thresholds are hit.
       * @param {string} [language] The language of the input audio. Supplying the input language in [ISO-639-1](https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes) format will improve accuracy and latency.
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createTranscription(e, t, n, i, s, a, o) {
        return $.OpenAIApiFp(this.configuration).createTranscription(e, t, n, i, s, a, o).then((u) => u(this.axios, this.basePath));
      }
      /**
       *
       * @summary Translates audio into into English.
       * @param {File} file The audio file object (not file name) translate, in one of these formats: mp3, mp4, mpeg, mpga, m4a, wav, or webm.
       * @param {string} model ID of the model to use. Only &#x60;whisper-1&#x60; is currently available.
       * @param {string} [prompt] An optional text to guide the model\\\&#39;s style or continue a previous audio segment. The [prompt](/docs/guides/speech-to-text/prompting) should be in English.
       * @param {string} [responseFormat] The format of the transcript output, in one of these options: json, text, srt, verbose_json, or vtt.
       * @param {number} [temperature] The sampling temperature, between 0 and 1. Higher values like 0.8 will make the output more random, while lower values like 0.2 will make it more focused and deterministic. If set to 0, the model will use [log probability](https://en.wikipedia.org/wiki/Log_probability) to automatically increase the temperature until certain thresholds are hit.
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      createTranslation(e, t, n, i, s, a) {
        return $.OpenAIApiFp(this.configuration).createTranslation(e, t, n, i, s, a).then((o) => o(this.axios, this.basePath));
      }
      /**
       *
       * @summary Delete a file.
       * @param {string} fileId The ID of the file to use for this request
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      deleteFile(e, t) {
        return $.OpenAIApiFp(this.configuration).deleteFile(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Delete a fine-tuned model. You must have the Owner role in your organization.
       * @param {string} model The model to delete
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      deleteModel(e, t) {
        return $.OpenAIApiFp(this.configuration).deleteModel(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Returns the contents of the specified file
       * @param {string} fileId The ID of the file to use for this request
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      downloadFile(e, t) {
        return $.OpenAIApiFp(this.configuration).downloadFile(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Lists the currently available (non-finetuned) models, and provides basic information about each one such as the owner and availability.
       * @param {*} [options] Override http request option.
       * @deprecated
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      listEngines(e) {
        return $.OpenAIApiFp(this.configuration).listEngines(e).then((t) => t(this.axios, this.basePath));
      }
      /**
       *
       * @summary Returns a list of files that belong to the user\'s organization.
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      listFiles(e) {
        return $.OpenAIApiFp(this.configuration).listFiles(e).then((t) => t(this.axios, this.basePath));
      }
      /**
       *
       * @summary Get fine-grained status updates for a fine-tune job.
       * @param {string} fineTuneId The ID of the fine-tune job to get events for.
       * @param {boolean} [stream] Whether to stream events for the fine-tune job. If set to true, events will be sent as data-only [server-sent events](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events#Event_stream_format) as they become available. The stream will terminate with a &#x60;data: [DONE]&#x60; message when the job is finished (succeeded, cancelled, or failed).  If set to false, only events generated so far will be returned.
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      listFineTuneEvents(e, t, n) {
        return $.OpenAIApiFp(this.configuration).listFineTuneEvents(e, t, n).then((i) => i(this.axios, this.basePath));
      }
      /**
       *
       * @summary List your organization\'s fine-tuning jobs
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      listFineTunes(e) {
        return $.OpenAIApiFp(this.configuration).listFineTunes(e).then((t) => t(this.axios, this.basePath));
      }
      /**
       *
       * @summary Lists the currently available models, and provides basic information about each one such as the owner and availability.
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      listModels(e) {
        return $.OpenAIApiFp(this.configuration).listModels(e).then((t) => t(this.axios, this.basePath));
      }
      /**
       *
       * @summary Retrieves a model instance, providing basic information about it such as the owner and availability.
       * @param {string} engineId The ID of the engine to use for this request
       * @param {*} [options] Override http request option.
       * @deprecated
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      retrieveEngine(e, t) {
        return $.OpenAIApiFp(this.configuration).retrieveEngine(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Returns information about a specific file.
       * @param {string} fileId The ID of the file to use for this request
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      retrieveFile(e, t) {
        return $.OpenAIApiFp(this.configuration).retrieveFile(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Gets info about the fine-tune job.  [Learn more about Fine-tuning](/docs/guides/fine-tuning)
       * @param {string} fineTuneId The ID of the fine-tune job
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      retrieveFineTune(e, t) {
        return $.OpenAIApiFp(this.configuration).retrieveFineTune(e, t).then((n) => n(this.axios, this.basePath));
      }
      /**
       *
       * @summary Retrieves a model instance, providing basic information about the model such as the owner and permissioning.
       * @param {string} model The ID of the model to use for this request
       * @param {*} [options] Override http request option.
       * @throws {RequiredError}
       * @memberof OpenAIApi
       */
      retrieveModel(e, t) {
        return $.OpenAIApiFp(this.configuration).retrieveModel(e, t).then((n) => n(this.axios, this.basePath));
      }
    };
    $.OpenAIApi = Ba;
  });

  // node_modules/.pnpm/openai@3.3.0/node_modules/openai/package.json
  var Xl = N(($v, Tm) => {
    Tm.exports = {
      name: "openai",
      version: "3.3.0",
      description: "Node.js library for the OpenAI API",
      repository: {
        type: "git",
        url: "git@github.com:openai/openai-node.git"
      },
      keywords: [
        "openai",
        "open",
        "ai",
        "gpt-3",
        "gpt3"
      ],
      author: "OpenAI",
      license: "MIT",
      main: "./dist/index.js",
      types: "./dist/index.d.ts",
      scripts: {
        build: "tsc --outDir dist/"
      },
      dependencies: {
        axios: "^0.26.0",
        "form-data": "^4.0.0"
      },
      devDependencies: {
        "@types/node": "^12.11.5",
        typescript: "^3.6.4"
      }
    };
  });

  // node_modules/.pnpm/form-data@4.0.0/node_modules/form-data/lib/browser.js
  var tc = N((Zv, ec) => {
    ec.exports = typeof self == "object" ? self.FormData : window.FormData;
  });

  // node_modules/.pnpm/openai@3.3.0/node_modules/openai/dist/configuration.js
  var rc = N((pi) => {
    "use strict";
    Object.defineProperty(pi, "__esModule", { value: true });
    pi.Configuration = void 0;
    var Im = Xl();
    var $a = class {
      constructor(e = {}) {
        this.apiKey = e.apiKey;
        this.organization = e.organization;
        this.username = e.username;
        this.password = e.password;
        this.accessToken = e.accessToken;
        this.basePath = e.basePath;
        this.baseOptions = e.baseOptions;
        this.formDataCtor = e.formDataCtor;
        if (!this.baseOptions) {
          this.baseOptions = {};
        }
        this.baseOptions.headers = Object.assign({ "User-Agent": `OpenAI/NodeJS/${Im.version}`, "Authorization": `Bearer ${this.apiKey}` }, this.baseOptions.headers);
        if (this.organization) {
          this.baseOptions.headers["OpenAI-Organization"] = this.organization;
        }
        if (!this.formDataCtor) {
          this.formDataCtor = tc();
        }
      }
      /**
       * Check if the given MIME is a JSON MIME.
       * JSON MIME examples:
       *   application/json
       *   application/json; charset=UTF8
       *   APPLICATION/JSON
       *   application/vnd.company+json
       * @param mime - MIME (Multipurpose Internet Mail Extensions)
       * @return True if the given MIME is JSON, false otherwise.
       */
      isJsonMime(e) {
        const t = new RegExp("^(application/json|[^;/ 	]+/[^;/ 	]+[+]json)[ 	]*(;.*)?$", "i");
        return e !== null && (t.test(e) || e.toLowerCase() === "application/json-patch+json");
      }
    };
    pi.Configuration = $a;
  });

  // node_modules/.pnpm/openai@3.3.0/node_modules/openai/dist/index.js
  var Tr = N((Dt) => {
    "use strict";
    var Cm = Dt && Dt.__createBinding || (Object.create ? function(r, e, t, n) {
      if (n === void 0)
        n = t;
      Object.defineProperty(r, n, { enumerable: true, get: function() {
        return e[t];
      } });
    } : function(r, e, t, n) {
      if (n === void 0)
        n = t;
      r[n] = e[t];
    });
    var nc = Dt && Dt.__exportStar || function(r, e) {
      for (var t in r)
        if (t !== "default" && !e.hasOwnProperty(t))
          Cm(e, r, t);
    };
    Object.defineProperty(Dt, "__esModule", { value: true });
    nc(Gl(), Dt);
    nc(rc(), Dt);
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/util/env.js
  async function sc() {
    if (Za === void 0) {
      const r = Rm();
      Za = {
        library: "langchain-js",
        runtime: r
      };
    }
    return Za;
  }
  function G(r) {
    try {
      return typeof process !== "undefined" ? (
        // eslint-disable-next-line no-process-env
        process.env?.[r]
      ) : void 0;
    } catch (e) {
      return void 0;
    }
  }
  var Sm, jm, km, ic, wt, Rm, Za;
  var _t = j(() => {
    Sm = () => typeof window !== "undefined" && typeof window.document !== "undefined";
    jm = () => typeof globalThis === "object" && globalThis.constructor && globalThis.constructor.name === "DedicatedWorkerGlobalScope";
    km = () => typeof window !== "undefined" && window.name === "nodejs" || typeof navigator !== "undefined" && (navigator.userAgent.includes("Node.js") || navigator.userAgent.includes("jsdom"));
    ic = () => typeof Deno !== "undefined";
    wt = () => typeof process !== "undefined" && typeof process.versions !== "undefined" && typeof process.versions.node !== "undefined" && !ic();
    Rm = () => {
      let r;
      if (Sm()) {
        r = "browser";
      } else if (wt()) {
        r = "node";
      } else if (jm()) {
        r = "webworker";
      } else if (km()) {
        r = "jsdom";
      } else if (ic()) {
        r = "deno";
      } else {
        r = "other";
      }
      return r;
    };
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/bind.js
  function _n(r, e) {
    return function t() {
      return r.apply(e, arguments);
    };
  }
  var Ha = j(() => {
    "use strict";
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/utils.js
  function Mm(r) {
    return r !== null && !vn(r) && r.constructor !== null && !vn(r.constructor) && Ze(r.constructor.isBuffer) && r.constructor.isBuffer(r);
  }
  function Lm(r) {
    let e;
    if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) {
      e = ArrayBuffer.isView(r);
    } else {
      e = r && r.buffer && uc(r.buffer);
    }
    return e;
  }
  function xn(r, e, { allOwnKeys: t = false } = {}) {
    if (r === null || typeof r === "undefined") {
      return;
    }
    let n;
    let i;
    if (typeof r !== "object") {
      r = [r];
    }
    if (Ir(r)) {
      for (n = 0, i = r.length; n < i; n++) {
        e.call(null, r[n], n, r);
      }
    } else {
      const s = t ? Object.getOwnPropertyNames(r) : Object.keys(r);
      const a = s.length;
      let o;
      for (n = 0; n < a; n++) {
        o = s[n];
        e.call(null, r[o], o, r);
      }
    }
  }
  function cc(r, e) {
    e = e.toLowerCase();
    const t = Object.keys(r);
    let n = t.length;
    let i;
    while (n-- > 0) {
      i = t[n];
      if (e === i.toLowerCase()) {
        return i;
      }
    }
    return null;
  }
  function Ja() {
    const { caseless: r } = pc(this) && this || {};
    const e = {};
    const t = (n, i) => {
      const s = r && cc(e, i) || i;
      if (hi(e[s]) && hi(n)) {
        e[s] = Ja(e[s], n);
      } else if (hi(n)) {
        e[s] = Ja({}, n);
      } else if (Ir(n)) {
        e[s] = n.slice();
      } else {
        e[s] = n;
      }
    };
    for (let n = 0, i = arguments.length; n < i; n++) {
      arguments[n] && xn(arguments[n], t);
    }
    return e;
  }
  function cy(r) {
    return !!(r && Ze(r.append) && r[Symbol.toStringTag] === "FormData" && r[Symbol.iterator]);
  }
  var Nm, Ya, fi, ut, mi, Ir, vn, uc, Dm, Ze, lc, yi, qm, hi, Um, Vm, zm, Fm, Km, Bm, $m, Zm, dc, pc, Hm, Qm, Jm, Ym, Wm, Gm, Xm, ey, ty, ry, ny, ac, iy, hc, sy, ay, oy, uy, Qa, oc, fc, ly, dy, py, hy, T;
  var ye = j(() => {
    "use strict";
    Ha();
    ({ toString: Nm } = Object.prototype);
    ({ getPrototypeOf: Ya } = Object);
    fi = ((r) => (e) => {
      const t = Nm.call(e);
      return r[t] || (r[t] = t.slice(8, -1).toLowerCase());
    })(/* @__PURE__ */ Object.create(null));
    ut = (r) => {
      r = r.toLowerCase();
      return (e) => fi(e) === r;
    };
    mi = (r) => (e) => typeof e === r;
    ({ isArray: Ir } = Array);
    vn = mi("undefined");
    uc = ut("ArrayBuffer");
    Dm = mi("string");
    Ze = mi("function");
    lc = mi("number");
    yi = (r) => r !== null && typeof r === "object";
    qm = (r) => r === true || r === false;
    hi = (r) => {
      if (fi(r) !== "object") {
        return false;
      }
      const e = Ya(r);
      return (e === null || e === Object.prototype || Object.getPrototypeOf(e) === null) && !(Symbol.toStringTag in r) && !(Symbol.iterator in r);
    };
    Um = ut("Date");
    Vm = ut("File");
    zm = ut("Blob");
    Fm = ut("FileList");
    Km = (r) => yi(r) && Ze(r.pipe);
    Bm = (r) => {
      let e;
      return r && (typeof FormData === "function" && r instanceof FormData || Ze(r.append) && ((e = fi(r)) === "formdata" || // detect form-data instance
      e === "object" && Ze(r.toString) && r.toString() === "[object FormData]"));
    };
    $m = ut("URLSearchParams");
    Zm = (r) => r.trim ? r.trim() : r.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
    dc = (() => {
      if (typeof globalThis !== "undefined")
        return globalThis;
      return typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : global;
    })();
    pc = (r) => !vn(r) && r !== dc;
    Hm = (r, e, t, { allOwnKeys: n } = {}) => {
      xn(e, (i, s) => {
        if (t && Ze(i)) {
          r[s] = _n(i, t);
        } else {
          r[s] = i;
        }
      }, { allOwnKeys: n });
      return r;
    };
    Qm = (r) => {
      if (r.charCodeAt(0) === 65279) {
        r = r.slice(1);
      }
      return r;
    };
    Jm = (r, e, t, n) => {
      r.prototype = Object.create(e.prototype, n);
      r.prototype.constructor = r;
      Object.defineProperty(r, "super", {
        value: e.prototype
      });
      t && Object.assign(r.prototype, t);
    };
    Ym = (r, e, t, n) => {
      let i;
      let s;
      let a;
      const o = {};
      e = e || {};
      if (r == null)
        return e;
      do {
        i = Object.getOwnPropertyNames(r);
        s = i.length;
        while (s-- > 0) {
          a = i[s];
          if ((!n || n(a, r, e)) && !o[a]) {
            e[a] = r[a];
            o[a] = true;
          }
        }
        r = t !== false && Ya(r);
      } while (r && (!t || t(r, e)) && r !== Object.prototype);
      return e;
    };
    Wm = (r, e, t) => {
      r = String(r);
      if (t === void 0 || t > r.length) {
        t = r.length;
      }
      t -= e.length;
      const n = r.indexOf(e, t);
      return n !== -1 && n === t;
    };
    Gm = (r) => {
      if (!r)
        return null;
      if (Ir(r))
        return r;
      let e = r.length;
      if (!lc(e))
        return null;
      const t = new Array(e);
      while (e-- > 0) {
        t[e] = r[e];
      }
      return t;
    };
    Xm = ((r) => {
      return (e) => {
        return r && e instanceof r;
      };
    })(typeof Uint8Array !== "undefined" && Ya(Uint8Array));
    ey = (r, e) => {
      const t = r && r[Symbol.iterator];
      const n = t.call(r);
      let i;
      while ((i = n.next()) && !i.done) {
        const s = i.value;
        e.call(r, s[0], s[1]);
      }
    };
    ty = (r, e) => {
      let t;
      const n = [];
      while ((t = r.exec(e)) !== null) {
        n.push(t);
      }
      return n;
    };
    ry = ut("HTMLFormElement");
    ny = (r) => {
      return r.toLowerCase().replace(
        /[-_\s]([a-z\d])(\w*)/g,
        function e(t, n, i) {
          return n.toUpperCase() + i;
        }
      );
    };
    ac = (({ hasOwnProperty: r }) => (e, t) => r.call(e, t))(Object.prototype);
    iy = ut("RegExp");
    hc = (r, e) => {
      const t = Object.getOwnPropertyDescriptors(r);
      const n = {};
      xn(t, (i, s) => {
        if (e(i, s, r) !== false) {
          n[s] = i;
        }
      });
      Object.defineProperties(r, n);
    };
    sy = (r) => {
      hc(r, (e, t) => {
        if (Ze(r) && ["arguments", "caller", "callee"].indexOf(t) !== -1) {
          return false;
        }
        const n = r[t];
        if (!Ze(n))
          return;
        e.enumerable = false;
        if ("writable" in e) {
          e.writable = false;
          return;
        }
        if (!e.set) {
          e.set = () => {
            throw Error("Can not rewrite read-only method '" + t + "'");
          };
        }
      });
    };
    ay = (r, e) => {
      const t = {};
      const n = (i) => {
        i.forEach((s) => {
          t[s] = true;
        });
      };
      Ir(r) ? n(r) : n(String(r).split(e));
      return t;
    };
    oy = () => {
    };
    uy = (r, e) => {
      r = +r;
      return Number.isFinite(r) ? r : e;
    };
    Qa = "abcdefghijklmnopqrstuvwxyz";
    oc = "0123456789";
    fc = {
      DIGIT: oc,
      ALPHA: Qa,
      ALPHA_DIGIT: Qa + Qa.toUpperCase() + oc
    };
    ly = (r = 16, e = fc.ALPHA_DIGIT) => {
      let t = "";
      const { length: n } = e;
      while (r--) {
        t += e[Math.random() * n | 0];
      }
      return t;
    };
    dy = (r) => {
      const e = new Array(10);
      const t = (n, i) => {
        if (yi(n)) {
          if (e.indexOf(n) >= 0) {
            return;
          }
          if (!("toJSON" in n)) {
            e[i] = n;
            const s = Ir(n) ? [] : {};
            xn(n, (a, o) => {
              const u = t(a, i + 1);
              !vn(u) && (s[o] = u);
            });
            e[i] = void 0;
            return s;
          }
        }
        return n;
      };
      return t(r, 0);
    };
    py = ut("AsyncFunction");
    hy = (r) => r && (yi(r) || Ze(r)) && Ze(r.then) && Ze(r.catch);
    T = {
      isArray: Ir,
      isArrayBuffer: uc,
      isBuffer: Mm,
      isFormData: Bm,
      isArrayBufferView: Lm,
      isString: Dm,
      isNumber: lc,
      isBoolean: qm,
      isObject: yi,
      isPlainObject: hi,
      isUndefined: vn,
      isDate: Um,
      isFile: Vm,
      isBlob: zm,
      isRegExp: iy,
      isFunction: Ze,
      isStream: Km,
      isURLSearchParams: $m,
      isTypedArray: Xm,
      isFileList: Fm,
      forEach: xn,
      merge: Ja,
      extend: Hm,
      trim: Zm,
      stripBOM: Qm,
      inherits: Jm,
      toFlatObject: Ym,
      kindOf: fi,
      kindOfTest: ut,
      endsWith: Wm,
      toArray: Gm,
      forEachEntry: ey,
      matchAll: ty,
      isHTMLForm: ry,
      hasOwnProperty: ac,
      hasOwnProp: ac,
      // an alias to avoid ESLint no-prototype-builtins detection
      reduceDescriptors: hc,
      freezeMethods: sy,
      toObjectSet: ay,
      toCamelCase: ny,
      noop: oy,
      toFiniteNumber: uy,
      findKey: cc,
      global: dc,
      isContextDefined: pc,
      ALPHABET: fc,
      generateString: ly,
      isSpecCompliantForm: cy,
      toJSONObject: dy,
      isAsyncFn: py,
      isThenable: hy
    };
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/core/AxiosError.js
  function Cr(r, e, t, n, i) {
    Error.call(this);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, this.constructor);
    } else {
      this.stack = new Error().stack;
    }
    this.message = r;
    this.name = "AxiosError";
    e && (this.code = e);
    t && (this.config = t);
    n && (this.request = n);
    i && (this.response = i);
  }
  var mc, yc, ee;
  var vt = j(() => {
    "use strict";
    ye();
    T.inherits(Cr, Error, {
      toJSON: function r() {
        return {
          // Standard
          message: this.message,
          name: this.name,
          // Microsoft
          description: this.description,
          number: this.number,
          // Mozilla
          fileName: this.fileName,
          lineNumber: this.lineNumber,
          columnNumber: this.columnNumber,
          stack: this.stack,
          // Axios
          config: T.toJSONObject(this.config),
          code: this.code,
          status: this.response && this.response.status ? this.response.status : null
        };
      }
    });
    mc = Cr.prototype;
    yc = {};
    [
      "ERR_BAD_OPTION_VALUE",
      "ERR_BAD_OPTION",
      "ECONNABORTED",
      "ETIMEDOUT",
      "ERR_NETWORK",
      "ERR_FR_TOO_MANY_REDIRECTS",
      "ERR_DEPRECATED",
      "ERR_BAD_RESPONSE",
      "ERR_BAD_REQUEST",
      "ERR_CANCELED",
      "ERR_NOT_SUPPORT",
      "ERR_INVALID_URL"
      // eslint-disable-next-line func-names
    ].forEach((r) => {
      yc[r] = { value: r };
    });
    Object.defineProperties(Cr, yc);
    Object.defineProperty(mc, "isAxiosError", { value: true });
    Cr.from = (r, e, t, n, i, s) => {
      const a = Object.create(mc);
      T.toFlatObject(r, a, function o(u) {
        return u !== Error.prototype;
      }, (o) => {
        return o !== "isAxiosError";
      });
      Cr.call(a, r.message, e, t, n, i);
      a.cause = r;
      a.name = r.name;
      s && Object.assign(a, s);
      return a;
    };
    ee = Cr;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/null.js
  var bi;
  var Wa = j(() => {
    bi = null;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/toFormData.js
  function Ga(r) {
    return T.isPlainObject(r) || T.isArray(r);
  }
  function gc(r) {
    return T.endsWith(r, "[]") ? r.slice(0, -2) : r;
  }
  function bc(r, e, t) {
    if (!r)
      return e;
    return r.concat(e).map(function n(i, s) {
      i = gc(i);
      return !t && s ? "[" + i + "]" : i;
    }).join(t ? "." : "");
  }
  function fy(r) {
    return T.isArray(r) && !r.some(Ga);
  }
  function yy(r, e, t) {
    if (!T.isObject(r)) {
      throw new TypeError("target must be an object");
    }
    e = e || new (bi || FormData)();
    t = T.toFlatObject(t, {
      metaTokens: true,
      dots: false,
      indexes: false
    }, false, function f(P, S) {
      return !T.isUndefined(S[P]);
    });
    const n = t.metaTokens;
    const i = t.visitor || c;
    const s = t.dots;
    const a = t.indexes;
    const o = t.Blob || typeof Blob !== "undefined" && Blob;
    const u = o && T.isSpecCompliantForm(e);
    if (!T.isFunction(i)) {
      throw new TypeError("visitor must be a function");
    }
    function l(f) {
      if (f === null)
        return "";
      if (T.isDate(f)) {
        return f.toISOString();
      }
      if (!u && T.isBlob(f)) {
        throw new ee("Blob is not supported. Use a Buffer instead.");
      }
      if (T.isArrayBuffer(f) || T.isTypedArray(f)) {
        return u && typeof Blob === "function" ? new Blob([f]) : Buffer.from(f);
      }
      return f;
    }
    function c(f, P, S) {
      let k = f;
      if (f && !S && typeof f === "object") {
        if (T.endsWith(P, "{}")) {
          P = n ? P : P.slice(0, -2);
          f = JSON.stringify(f);
        } else if (T.isArray(f) && fy(f) || (T.isFileList(f) || T.endsWith(P, "[]")) && (k = T.toArray(f))) {
          P = gc(P);
          k.forEach(function R(U, g) {
            !(T.isUndefined(U) || U === null) && e.append(
              // eslint-disable-next-line no-nested-ternary
              a === true ? bc([P], g, s) : a === null ? P : P + "[]",
              l(U)
            );
          });
          return false;
        }
      }
      if (Ga(f)) {
        return true;
      }
      e.append(bc(S, P, s), l(f));
      return false;
    }
    const b = [];
    const _ = Object.assign(my, {
      defaultVisitor: c,
      convertValue: l,
      isVisitable: Ga
    });
    function x(f, P) {
      if (T.isUndefined(f))
        return;
      if (b.indexOf(f) !== -1) {
        throw Error("Circular reference detected in " + P.join("."));
      }
      b.push(f);
      T.forEach(f, function S(k, R) {
        const U = !(T.isUndefined(k) || k === null) && i.call(
          e,
          k,
          T.isString(R) ? R.trim() : R,
          P,
          _
        );
        if (U === true) {
          x(k, P ? P.concat(R) : [R]);
        }
      });
      b.pop();
    }
    if (!T.isObject(r)) {
      throw new TypeError("data must be an object");
    }
    x(r);
    return e;
  }
  var my, qt;
  var On = j(() => {
    "use strict";
    ye();
    vt();
    Wa();
    my = T.toFlatObject(T, {}, null, function r(e) {
      return /^is[A-Z]/.test(e);
    });
    qt = yy;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/AxiosURLSearchParams.js
  function wc(r) {
    const e = {
      "!": "%21",
      "'": "%27",
      "(": "%28",
      ")": "%29",
      "~": "%7E",
      "%20": "+",
      "%00": "\0"
    };
    return encodeURIComponent(r).replace(/[!'()~]|%20|%00/g, function t(n) {
      return e[n];
    });
  }
  function _c(r, e) {
    this._pairs = [];
    r && qt(r, this, e);
  }
  var vc, gi;
  var Xa = j(() => {
    "use strict";
    On();
    vc = _c.prototype;
    vc.append = function r(e, t) {
      this._pairs.push([e, t]);
    };
    vc.toString = function r(e) {
      const t = e ? function(n) {
        return e.call(this, n, wc);
      } : wc;
      return this._pairs.map(function n(i) {
        return t(i[0]) + "=" + t(i[1]);
      }, "").join("&");
    };
    gi = _c;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/buildURL.js
  function by(r) {
    return encodeURIComponent(r).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
  }
  function Pn(r, e, t) {
    if (!e) {
      return r;
    }
    const n = t && t.encode || by;
    const i = t && t.serialize;
    let s;
    if (i) {
      s = i(e, t);
    } else {
      s = T.isURLSearchParams(e) ? e.toString() : new gi(e, t).toString(n);
    }
    if (s) {
      const a = r.indexOf("#");
      if (a !== -1) {
        r = r.slice(0, a);
      }
      r += (r.indexOf("?") === -1 ? "?" : "&") + s;
    }
    return r;
  }
  var eo = j(() => {
    "use strict";
    ye();
    Xa();
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/core/InterceptorManager.js
  var to, ro;
  var xc = j(() => {
    "use strict";
    ye();
    to = class {
      constructor() {
        this.handlers = [];
      }
      /**
       * Add a new interceptor to the stack
       *
       * @param {Function} fulfilled The function to handle `then` for a `Promise`
       * @param {Function} rejected The function to handle `reject` for a `Promise`
       *
       * @return {Number} An ID used to remove interceptor later
       */
      use(e, t, n) {
        this.handlers.push({
          fulfilled: e,
          rejected: t,
          synchronous: n ? n.synchronous : false,
          runWhen: n ? n.runWhen : null
        });
        return this.handlers.length - 1;
      }
      /**
       * Remove an interceptor from the stack
       *
       * @param {Number} id The ID that was returned by `use`
       *
       * @returns {Boolean} `true` if the interceptor was removed, `false` otherwise
       */
      eject(e) {
        if (this.handlers[e]) {
          this.handlers[e] = null;
        }
      }
      /**
       * Clear all interceptors from the stack
       *
       * @returns {void}
       */
      clear() {
        if (this.handlers) {
          this.handlers = [];
        }
      }
      /**
       * Iterate over all the registered interceptors
       *
       * This method is particularly useful for skipping over any
       * interceptors that may have become `null` calling `eject`.
       *
       * @param {Function} fn The function to call for each interceptor
       *
       * @returns {void}
       */
      forEach(e) {
        T.forEach(this.handlers, function t(n) {
          if (n !== null) {
            e(n);
          }
        });
      }
    };
    ro = to;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/defaults/transitional.js
  var wi;
  var no = j(() => {
    "use strict";
    wi = {
      silentJSONParsing: true,
      forcedJSONParsing: true,
      clarifyTimeoutError: false
    };
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/platform/browser/classes/URLSearchParams.js
  var Oc;
  var Pc = j(() => {
    "use strict";
    Xa();
    Oc = typeof URLSearchParams !== "undefined" ? URLSearchParams : gi;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/platform/browser/classes/FormData.js
  var Ac;
  var Ec = j(() => {
    "use strict";
    Ac = typeof FormData !== "undefined" ? FormData : null;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/platform/browser/classes/Blob.js
  var Tc;
  var Ic = j(() => {
    "use strict";
    Tc = typeof Blob !== "undefined" ? Blob : null;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/platform/browser/index.js
  var gy, wy, Ee;
  var Cc = j(() => {
    Pc();
    Ec();
    Ic();
    gy = (() => {
      let r;
      if (typeof navigator !== "undefined" && ((r = navigator.product) === "ReactNative" || r === "NativeScript" || r === "NS")) {
        return false;
      }
      return typeof window !== "undefined" && typeof document !== "undefined";
    })();
    wy = (() => {
      return typeof WorkerGlobalScope !== "undefined" && // eslint-disable-next-line no-undef
      self instanceof WorkerGlobalScope && typeof self.importScripts === "function";
    })();
    Ee = {
      isBrowser: true,
      classes: {
        URLSearchParams: Oc,
        FormData: Ac,
        Blob: Tc
      },
      isStandardBrowserEnv: gy,
      isStandardBrowserWebWorkerEnv: wy,
      protocols: ["http", "https", "file", "blob", "url", "data"]
    };
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/platform/index.js
  var Sr = j(() => {
    Cc();
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/toURLEncodedForm.js
  function io(r, e) {
    return qt(r, new Ee.classes.URLSearchParams(), Object.assign({
      visitor: function(t, n, i, s) {
        if (Ee.isNode && T.isBuffer(t)) {
          this.append(n, t.toString("base64"));
          return false;
        }
        return s.defaultVisitor.apply(this, arguments);
      }
    }, e));
  }
  var Sc = j(() => {
    "use strict";
    ye();
    On();
    Sr();
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/formDataToJSON.js
  function _y(r) {
    return T.matchAll(/\w+|\[(\w*)]/g, r).map((e) => {
      return e[0] === "[]" ? "" : e[1] || e[0];
    });
  }
  function vy(r) {
    const e = {};
    const t = Object.keys(r);
    let n;
    const i = t.length;
    let s;
    for (n = 0; n < i; n++) {
      s = t[n];
      e[s] = r[s];
    }
    return e;
  }
  function xy(r) {
    function e(t, n, i, s) {
      let a = t[s++];
      const o = Number.isFinite(+a);
      const u = s >= t.length;
      a = !a && T.isArray(i) ? i.length : a;
      if (u) {
        if (T.hasOwnProp(i, a)) {
          i[a] = [i[a], n];
        } else {
          i[a] = n;
        }
        return !o;
      }
      if (!i[a] || !T.isObject(i[a])) {
        i[a] = [];
      }
      const l = e(t, n, i[a], s);
      if (l && T.isArray(i[a])) {
        i[a] = vy(i[a]);
      }
      return !o;
    }
    if (T.isFormData(r) && T.isFunction(r.entries)) {
      const t = {};
      T.forEachEntry(r, (n, i) => {
        e(_y(n), i, t, 0);
      });
      return t;
    }
    return null;
  }
  var _i;
  var so = j(() => {
    "use strict";
    ye();
    _i = xy;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/defaults/index.js
  function Py(r, e, t) {
    if (T.isString(r)) {
      try {
        (e || JSON.parse)(r);
        return T.trim(r);
      } catch (n) {
        if (n.name !== "SyntaxError") {
          throw n;
        }
      }
    }
    return (t || JSON.stringify)(r);
  }
  var Oy, vi, jr;
  var xi = j(() => {
    "use strict";
    ye();
    vt();
    no();
    On();
    Sc();
    Sr();
    so();
    Oy = {
      "Content-Type": void 0
    };
    vi = {
      transitional: wi,
      adapter: ["xhr", "http"],
      transformRequest: [function r(e, t) {
        const n = t.getContentType() || "";
        const i = n.indexOf("application/json") > -1;
        const s = T.isObject(e);
        if (s && T.isHTMLForm(e)) {
          e = new FormData(e);
        }
        const a = T.isFormData(e);
        if (a) {
          if (!i) {
            return e;
          }
          return i ? JSON.stringify(_i(e)) : e;
        }
        if (T.isArrayBuffer(e) || T.isBuffer(e) || T.isStream(e) || T.isFile(e) || T.isBlob(e)) {
          return e;
        }
        if (T.isArrayBufferView(e)) {
          return e.buffer;
        }
        if (T.isURLSearchParams(e)) {
          t.setContentType("application/x-www-form-urlencoded;charset=utf-8", false);
          return e.toString();
        }
        let o;
        if (s) {
          if (n.indexOf("application/x-www-form-urlencoded") > -1) {
            return io(e, this.formSerializer).toString();
          }
          if ((o = T.isFileList(e)) || n.indexOf("multipart/form-data") > -1) {
            const u = this.env && this.env.FormData;
            return qt(
              o ? { "files[]": e } : e,
              u && new u(),
              this.formSerializer
            );
          }
        }
        if (s || i) {
          t.setContentType("application/json", false);
          return Py(e);
        }
        return e;
      }],
      transformResponse: [function r(e) {
        const t = this.transitional || vi.transitional;
        const n = t && t.forcedJSONParsing;
        const i = this.responseType === "json";
        if (e && T.isString(e) && (n && !this.responseType || i)) {
          const s = t && t.silentJSONParsing;
          const a = !s && i;
          try {
            return JSON.parse(e);
          } catch (o) {
            if (a) {
              if (o.name === "SyntaxError") {
                throw ee.from(o, ee.ERR_BAD_RESPONSE, this, null, this.response);
              }
              throw o;
            }
          }
        }
        return e;
      }],
      /**
       * A timeout in milliseconds to abort a request. If set to 0 (default) a
       * timeout is not created.
       */
      timeout: 0,
      xsrfCookieName: "XSRF-TOKEN",
      xsrfHeaderName: "X-XSRF-TOKEN",
      maxContentLength: -1,
      maxBodyLength: -1,
      env: {
        FormData: Ee.classes.FormData,
        Blob: Ee.classes.Blob
      },
      validateStatus: function r(e) {
        return e >= 200 && e < 300;
      },
      headers: {
        common: {
          "Accept": "application/json, text/plain, */*"
        }
      }
    };
    T.forEach(["delete", "get", "head"], function r(e) {
      vi.headers[e] = {};
    });
    T.forEach(["post", "put", "patch"], function r(e) {
      vi.headers[e] = T.merge(Oy);
    });
    jr = vi;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/parseHeaders.js
  var Ay, jc;
  var kc = j(() => {
    "use strict";
    ye();
    Ay = T.toObjectSet([
      "age",
      "authorization",
      "content-length",
      "content-type",
      "etag",
      "expires",
      "from",
      "host",
      "if-modified-since",
      "if-unmodified-since",
      "last-modified",
      "location",
      "max-forwards",
      "proxy-authorization",
      "referer",
      "retry-after",
      "user-agent"
    ]);
    jc = (r) => {
      const e = {};
      let t;
      let n;
      let i;
      r && r.split("\n").forEach(function s(a) {
        i = a.indexOf(":");
        t = a.substring(0, i).trim().toLowerCase();
        n = a.substring(i + 1).trim();
        if (!t || e[t] && Ay[t]) {
          return;
        }
        if (t === "set-cookie") {
          if (e[t]) {
            e[t].push(n);
          } else {
            e[t] = [n];
          }
        } else {
          e[t] = e[t] ? e[t] + ", " + n : n;
        }
      });
      return e;
    };
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/core/AxiosHeaders.js
  function An(r) {
    return r && String(r).trim().toLowerCase();
  }
  function Oi(r) {
    if (r === false || r == null) {
      return r;
    }
    return T.isArray(r) ? r.map(Oi) : String(r);
  }
  function Ey(r) {
    const e = /* @__PURE__ */ Object.create(null);
    const t = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
    let n;
    while (n = t.exec(r)) {
      e[n[1]] = n[2];
    }
    return e;
  }
  function ao(r, e, t, n, i) {
    if (T.isFunction(n)) {
      return n.call(this, e, t);
    }
    if (i) {
      e = t;
    }
    if (!T.isString(e))
      return;
    if (T.isString(n)) {
      return e.indexOf(n) !== -1;
    }
    if (T.isRegExp(n)) {
      return n.test(e);
    }
  }
  function Iy(r) {
    return r.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (e, t, n) => {
      return t.toUpperCase() + n;
    });
  }
  function Cy(r, e) {
    const t = T.toCamelCase(" " + e);
    ["get", "set", "has"].forEach((n) => {
      Object.defineProperty(r, n + t, {
        value: function(i, s, a) {
          return this[n].call(this, e, i, s, a);
        },
        configurable: true
      });
    });
  }
  var Rc, Ty, kr, je;
  var er = j(() => {
    "use strict";
    ye();
    kc();
    Rc = Symbol("internals");
    Ty = (r) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(r.trim());
    kr = class {
      constructor(e) {
        e && this.set(e);
      }
      set(e, t, n) {
        const i = this;
        function s(o, u, l) {
          const c = An(u);
          if (!c) {
            throw new Error("header name must be a non-empty string");
          }
          const b = T.findKey(i, c);
          if (!b || i[b] === void 0 || l === true || l === void 0 && i[b] !== false) {
            i[b || u] = Oi(o);
          }
        }
        const a = (o, u) => T.forEach(o, (l, c) => s(l, c, u));
        if (T.isPlainObject(e) || e instanceof this.constructor) {
          a(e, t);
        } else if (T.isString(e) && (e = e.trim()) && !Ty(e)) {
          a(jc(e), t);
        } else {
          e != null && s(t, e, n);
        }
        return this;
      }
      get(e, t) {
        e = An(e);
        if (e) {
          const n = T.findKey(this, e);
          if (n) {
            const i = this[n];
            if (!t) {
              return i;
            }
            if (t === true) {
              return Ey(i);
            }
            if (T.isFunction(t)) {
              return t.call(this, i, n);
            }
            if (T.isRegExp(t)) {
              return t.exec(i);
            }
            throw new TypeError("parser must be boolean|regexp|function");
          }
        }
      }
      has(e, t) {
        e = An(e);
        if (e) {
          const n = T.findKey(this, e);
          return !!(n && this[n] !== void 0 && (!t || ao(this, this[n], n, t)));
        }
        return false;
      }
      delete(e, t) {
        const n = this;
        let i = false;
        function s(a) {
          a = An(a);
          if (a) {
            const o = T.findKey(n, a);
            if (o && (!t || ao(n, n[o], o, t))) {
              delete n[o];
              i = true;
            }
          }
        }
        if (T.isArray(e)) {
          e.forEach(s);
        } else {
          s(e);
        }
        return i;
      }
      clear(e) {
        const t = Object.keys(this);
        let n = t.length;
        let i = false;
        while (n--) {
          const s = t[n];
          if (!e || ao(this, this[s], s, e, true)) {
            delete this[s];
            i = true;
          }
        }
        return i;
      }
      normalize(e) {
        const t = this;
        const n = {};
        T.forEach(this, (i, s) => {
          const a = T.findKey(n, s);
          if (a) {
            t[a] = Oi(i);
            delete t[s];
            return;
          }
          const o = e ? Iy(s) : String(s).trim();
          if (o !== s) {
            delete t[s];
          }
          t[o] = Oi(i);
          n[o] = true;
        });
        return this;
      }
      concat(...e) {
        return this.constructor.concat(this, ...e);
      }
      toJSON(e) {
        const t = /* @__PURE__ */ Object.create(null);
        T.forEach(this, (n, i) => {
          n != null && n !== false && (t[i] = e && T.isArray(n) ? n.join(", ") : n);
        });
        return t;
      }
      [Symbol.iterator]() {
        return Object.entries(this.toJSON())[Symbol.iterator]();
      }
      toString() {
        return Object.entries(this.toJSON()).map(([e, t]) => e + ": " + t).join("\n");
      }
      get [Symbol.toStringTag]() {
        return "AxiosHeaders";
      }
      static from(e) {
        return e instanceof this ? e : new this(e);
      }
      static concat(e, ...t) {
        const n = new this(e);
        t.forEach((i) => n.set(i));
        return n;
      }
      static accessor(e) {
        const t = this[Rc] = this[Rc] = {
          accessors: {}
        };
        const n = t.accessors;
        const i = this.prototype;
        function s(a) {
          const o = An(a);
          if (!n[o]) {
            Cy(i, a);
            n[o] = true;
          }
        }
        T.isArray(e) ? e.forEach(s) : s(e);
        return this;
      }
    };
    kr.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]);
    T.freezeMethods(kr.prototype);
    T.freezeMethods(kr);
    je = kr;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/core/transformData.js
  function En(r, e) {
    const t = this || jr;
    const n = e || t;
    const i = je.from(n.headers);
    let s = n.data;
    T.forEach(r, function a(o) {
      s = o.call(t, s, i.normalize(), e ? e.status : void 0);
    });
    i.normalize();
    return s;
  }
  var Nc = j(() => {
    "use strict";
    ye();
    xi();
    er();
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/cancel/isCancel.js
  function Tn(r) {
    return !!(r && r.__CANCEL__);
  }
  var oo = j(() => {
    "use strict";
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/cancel/CanceledError.js
  function Mc(r, e, t) {
    ee.call(this, r == null ? "canceled" : r, ee.ERR_CANCELED, e, t);
    this.name = "CanceledError";
  }
  var Ut;
  var In = j(() => {
    "use strict";
    vt();
    ye();
    T.inherits(Mc, ee, {
      __CANCEL__: true
    });
    Ut = Mc;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/core/settle.js
  function uo(r, e, t) {
    const n = t.config.validateStatus;
    if (!t.status || !n || n(t.status)) {
      r(t);
    } else {
      e(new ee(
        "Request failed with status code " + t.status,
        [ee.ERR_BAD_REQUEST, ee.ERR_BAD_RESPONSE][Math.floor(t.status / 100) - 4],
        t.config,
        t.request,
        t
      ));
    }
  }
  var Lc = j(() => {
    "use strict";
    vt();
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/cookies.js
  var Dc;
  var qc = j(() => {
    "use strict";
    ye();
    Sr();
    Dc = Ee.isStandardBrowserEnv ? (
      // Standard browser envs support document.cookie
      function r() {
        return {
          write: function e(t, n, i, s, a, o) {
            const u = [];
            u.push(t + "=" + encodeURIComponent(n));
            if (T.isNumber(i)) {
              u.push("expires=" + new Date(i).toGMTString());
            }
            if (T.isString(s)) {
              u.push("path=" + s);
            }
            if (T.isString(a)) {
              u.push("domain=" + a);
            }
            if (o === true) {
              u.push("secure");
            }
            document.cookie = u.join("; ");
          },
          read: function e(t) {
            const n = document.cookie.match(new RegExp("(^|;\\s*)(" + t + ")=([^;]*)"));
            return n ? decodeURIComponent(n[3]) : null;
          },
          remove: function e(t) {
            this.write(t, "", Date.now() - 864e5);
          }
        };
      }()
    ) : (
      // Non standard browser env (web workers, react-native) lack needed support.
      function r() {
        return {
          write: function e() {
          },
          read: function e() {
            return null;
          },
          remove: function e() {
          }
        };
      }()
    );
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/isAbsoluteURL.js
  function lo(r) {
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(r);
  }
  var Uc = j(() => {
    "use strict";
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/combineURLs.js
  function co(r, e) {
    return e ? r.replace(/\/+$/, "") + "/" + e.replace(/^\/+/, "") : r;
  }
  var Vc = j(() => {
    "use strict";
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/core/buildFullPath.js
  function Cn(r, e) {
    if (r && !lo(e)) {
      return co(r, e);
    }
    return e;
  }
  var po = j(() => {
    "use strict";
    Uc();
    Vc();
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/isURLSameOrigin.js
  var zc;
  var Fc = j(() => {
    "use strict";
    ye();
    Sr();
    zc = Ee.isStandardBrowserEnv ? (
      // Standard browser envs have full support of the APIs needed to test
      // whether the request URL is of the same origin as current location.
      function r() {
        const e = /(msie|trident)/i.test(navigator.userAgent);
        const t = document.createElement("a");
        let n;
        function i(s) {
          let a = s;
          if (e) {
            t.setAttribute("href", a);
            a = t.href;
          }
          t.setAttribute("href", a);
          return {
            href: t.href,
            protocol: t.protocol ? t.protocol.replace(/:$/, "") : "",
            host: t.host,
            search: t.search ? t.search.replace(/^\?/, "") : "",
            hash: t.hash ? t.hash.replace(/^#/, "") : "",
            hostname: t.hostname,
            port: t.port,
            pathname: t.pathname.charAt(0) === "/" ? t.pathname : "/" + t.pathname
          };
        }
        n = i(window.location.href);
        return function s(a) {
          const o = T.isString(a) ? i(a) : a;
          return o.protocol === n.protocol && o.host === n.host;
        };
      }()
    ) : (
      // Non standard browser envs (web workers, react-native) lack needed support.
      function r() {
        return function e() {
          return true;
        };
      }()
    );
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/parseProtocol.js
  function ho(r) {
    const e = /^([-+\w]{1,25})(:?\/\/|:)/.exec(r);
    return e && e[1] || "";
  }
  var Kc = j(() => {
    "use strict";
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/speedometer.js
  function Sy(r, e) {
    r = r || 10;
    const t = new Array(r);
    const n = new Array(r);
    let i = 0;
    let s = 0;
    let a;
    e = e !== void 0 ? e : 1e3;
    return function o(u) {
      const l = Date.now();
      const c = n[s];
      if (!a) {
        a = l;
      }
      t[i] = u;
      n[i] = l;
      let b = s;
      let _ = 0;
      while (b !== i) {
        _ += t[b++];
        b = b % r;
      }
      i = (i + 1) % r;
      if (i === s) {
        s = (s + 1) % r;
      }
      if (l - a < e) {
        return;
      }
      const x = c && l - c;
      return x ? Math.round(_ * 1e3 / x) : void 0;
    };
  }
  var Bc;
  var $c = j(() => {
    "use strict";
    Bc = Sy;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/adapters/xhr.js
  function Zc(r, e) {
    let t = 0;
    const n = Bc(50, 250);
    return (i) => {
      const s = i.loaded;
      const a = i.lengthComputable ? i.total : void 0;
      const o = s - t;
      const u = n(o);
      const l = s <= a;
      t = s;
      const c = {
        loaded: s,
        total: a,
        progress: a ? s / a : void 0,
        bytes: o,
        rate: u ? u : void 0,
        estimated: u && a && l ? (a - s) / u : void 0,
        event: i
      };
      c[e ? "download" : "upload"] = true;
      r(c);
    };
  }
  var jy, Hc;
  var Qc = j(() => {
    "use strict";
    ye();
    Lc();
    qc();
    eo();
    po();
    Fc();
    no();
    vt();
    In();
    Kc();
    Sr();
    er();
    $c();
    jy = typeof XMLHttpRequest !== "undefined";
    Hc = jy && function(r) {
      return new Promise(function e(t, n) {
        let i = r.data;
        const s = je.from(r.headers).normalize();
        const a = r.responseType;
        let o;
        function u() {
          if (r.cancelToken) {
            r.cancelToken.unsubscribe(o);
          }
          if (r.signal) {
            r.signal.removeEventListener("abort", o);
          }
        }
        if (T.isFormData(i)) {
          if (Ee.isStandardBrowserEnv || Ee.isStandardBrowserWebWorkerEnv) {
            s.setContentType(false);
          } else {
            s.setContentType("multipart/form-data;", false);
          }
        }
        let l = new XMLHttpRequest();
        if (r.auth) {
          const x = r.auth.username || "";
          const f = r.auth.password ? unescape(encodeURIComponent(r.auth.password)) : "";
          s.set("Authorization", "Basic " + btoa(x + ":" + f));
        }
        const c = Cn(r.baseURL, r.url);
        l.open(r.method.toUpperCase(), Pn(c, r.params, r.paramsSerializer), true);
        l.timeout = r.timeout;
        function b() {
          if (!l) {
            return;
          }
          const x = je.from(
            "getAllResponseHeaders" in l && l.getAllResponseHeaders()
          );
          const f = !a || a === "text" || a === "json" ? l.responseText : l.response;
          const P = {
            data: f,
            status: l.status,
            statusText: l.statusText,
            headers: x,
            config: r,
            request: l
          };
          uo(function S(k) {
            t(k);
            u();
          }, function S(k) {
            n(k);
            u();
          }, P);
          l = null;
        }
        if ("onloadend" in l) {
          l.onloadend = b;
        } else {
          l.onreadystatechange = function x() {
            if (!l || l.readyState !== 4) {
              return;
            }
            if (l.status === 0 && !(l.responseURL && l.responseURL.indexOf("file:") === 0)) {
              return;
            }
            setTimeout(b);
          };
        }
        l.onabort = function x() {
          if (!l) {
            return;
          }
          n(new ee("Request aborted", ee.ECONNABORTED, r, l));
          l = null;
        };
        l.onerror = function x() {
          n(new ee("Network Error", ee.ERR_NETWORK, r, l));
          l = null;
        };
        l.ontimeout = function x() {
          let f = r.timeout ? "timeout of " + r.timeout + "ms exceeded" : "timeout exceeded";
          const P = r.transitional || wi;
          if (r.timeoutErrorMessage) {
            f = r.timeoutErrorMessage;
          }
          n(new ee(
            f,
            P.clarifyTimeoutError ? ee.ETIMEDOUT : ee.ECONNABORTED,
            r,
            l
          ));
          l = null;
        };
        if (Ee.isStandardBrowserEnv) {
          const x = (r.withCredentials || zc(c)) && r.xsrfCookieName && Dc.read(r.xsrfCookieName);
          if (x) {
            s.set(r.xsrfHeaderName, x);
          }
        }
        i === void 0 && s.setContentType(null);
        if ("setRequestHeader" in l) {
          T.forEach(s.toJSON(), function x(f, P) {
            l.setRequestHeader(P, f);
          });
        }
        if (!T.isUndefined(r.withCredentials)) {
          l.withCredentials = !!r.withCredentials;
        }
        if (a && a !== "json") {
          l.responseType = r.responseType;
        }
        if (typeof r.onDownloadProgress === "function") {
          l.addEventListener("progress", Zc(r.onDownloadProgress, true));
        }
        if (typeof r.onUploadProgress === "function" && l.upload) {
          l.upload.addEventListener("progress", Zc(r.onUploadProgress));
        }
        if (r.cancelToken || r.signal) {
          o = (x) => {
            if (!l) {
              return;
            }
            n(!x || x.type ? new Ut(null, r, l) : x);
            l.abort();
            l = null;
          };
          r.cancelToken && r.cancelToken.subscribe(o);
          if (r.signal) {
            r.signal.aborted ? o() : r.signal.addEventListener("abort", o);
          }
        }
        const _ = ho(c);
        if (_ && Ee.protocols.indexOf(_) === -1) {
          n(new ee("Unsupported protocol " + _ + ":", ee.ERR_BAD_REQUEST, r));
          return;
        }
        l.send(i || null);
      });
    };
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/adapters/adapters.js
  var Pi, Jc;
  var Yc = j(() => {
    ye();
    Wa();
    Qc();
    vt();
    Pi = {
      http: bi,
      xhr: Hc
    };
    T.forEach(Pi, (r, e) => {
      if (r) {
        try {
          Object.defineProperty(r, "name", { value: e });
        } catch (t) {
        }
        Object.defineProperty(r, "adapterName", { value: e });
      }
    });
    Jc = {
      getAdapter: (r) => {
        r = T.isArray(r) ? r : [r];
        const { length: e } = r;
        let t;
        let n;
        for (let i = 0; i < e; i++) {
          t = r[i];
          if (n = T.isString(t) ? Pi[t.toLowerCase()] : t) {
            break;
          }
        }
        if (!n) {
          if (n === false) {
            throw new ee(
              `Adapter ${t} is not supported by the environment`,
              "ERR_NOT_SUPPORT"
            );
          }
          throw new Error(
            T.hasOwnProp(Pi, t) ? `Adapter '${t}' is not available in the build` : `Unknown adapter '${t}'`
          );
        }
        if (!T.isFunction(n)) {
          throw new TypeError("adapter is not a function");
        }
        return n;
      },
      adapters: Pi
    };
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/core/dispatchRequest.js
  function fo(r) {
    if (r.cancelToken) {
      r.cancelToken.throwIfRequested();
    }
    if (r.signal && r.signal.aborted) {
      throw new Ut(null, r);
    }
  }
  function Ai(r) {
    fo(r);
    r.headers = je.from(r.headers);
    r.data = En.call(
      r,
      r.transformRequest
    );
    if (["post", "put", "patch"].indexOf(r.method) !== -1) {
      r.headers.setContentType("application/x-www-form-urlencoded", false);
    }
    const e = Jc.getAdapter(r.adapter || jr.adapter);
    return e(r).then(function t(n) {
      fo(r);
      n.data = En.call(
        r,
        r.transformResponse,
        n
      );
      n.headers = je.from(n.headers);
      return n;
    }, function t(n) {
      if (!Tn(n)) {
        fo(r);
        if (n && n.response) {
          n.response.data = En.call(
            r,
            r.transformResponse,
            n.response
          );
          n.response.headers = je.from(n.response.headers);
        }
      }
      return Promise.reject(n);
    });
  }
  var Wc = j(() => {
    "use strict";
    Nc();
    oo();
    xi();
    In();
    er();
    Yc();
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/core/mergeConfig.js
  function xt(r, e) {
    e = e || {};
    const t = {};
    function n(l, c, b) {
      if (T.isPlainObject(l) && T.isPlainObject(c)) {
        return T.merge.call({ caseless: b }, l, c);
      } else if (T.isPlainObject(c)) {
        return T.merge({}, c);
      } else if (T.isArray(c)) {
        return c.slice();
      }
      return c;
    }
    function i(l, c, b) {
      if (!T.isUndefined(c)) {
        return n(l, c, b);
      } else if (!T.isUndefined(l)) {
        return n(void 0, l, b);
      }
    }
    function s(l, c) {
      if (!T.isUndefined(c)) {
        return n(void 0, c);
      }
    }
    function a(l, c) {
      if (!T.isUndefined(c)) {
        return n(void 0, c);
      } else if (!T.isUndefined(l)) {
        return n(void 0, l);
      }
    }
    function o(l, c, b) {
      if (b in e) {
        return n(l, c);
      } else if (b in r) {
        return n(void 0, l);
      }
    }
    const u = {
      url: s,
      method: s,
      data: s,
      baseURL: a,
      transformRequest: a,
      transformResponse: a,
      paramsSerializer: a,
      timeout: a,
      timeoutMessage: a,
      withCredentials: a,
      adapter: a,
      responseType: a,
      xsrfCookieName: a,
      xsrfHeaderName: a,
      onUploadProgress: a,
      onDownloadProgress: a,
      decompress: a,
      maxContentLength: a,
      maxBodyLength: a,
      beforeRedirect: a,
      transport: a,
      httpAgent: a,
      httpsAgent: a,
      cancelToken: a,
      socketPath: a,
      responseEncoding: a,
      validateStatus: o,
      headers: (l, c) => i(Gc(l), Gc(c), true)
    };
    T.forEach(Object.keys(Object.assign({}, r, e)), function l(c) {
      const b = u[c] || i;
      const _ = b(r[c], e[c], c);
      T.isUndefined(_) && b !== o || (t[c] = _);
    });
    return t;
  }
  var Gc;
  var mo = j(() => {
    "use strict";
    ye();
    er();
    Gc = (r) => r instanceof je ? r.toJSON() : r;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/env/data.js
  var Ei;
  var yo = j(() => {
    Ei = "1.4.0";
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/validator.js
  function ky(r, e, t) {
    if (typeof r !== "object") {
      throw new ee("options must be an object", ee.ERR_BAD_OPTION_VALUE);
    }
    const n = Object.keys(r);
    let i = n.length;
    while (i-- > 0) {
      const s = n[i];
      const a = e[s];
      if (a) {
        const o = r[s];
        const u = o === void 0 || a(o, s, r);
        if (u !== true) {
          throw new ee("option " + s + " must be " + u, ee.ERR_BAD_OPTION_VALUE);
        }
        continue;
      }
      if (t !== true) {
        throw new ee("Unknown option " + s, ee.ERR_BAD_OPTION);
      }
    }
  }
  var bo, Xc, Ti;
  var ed = j(() => {
    "use strict";
    yo();
    vt();
    bo = {};
    ["object", "boolean", "number", "function", "string", "symbol"].forEach((r, e) => {
      bo[r] = function t(n) {
        return typeof n === r || "a" + (e < 1 ? "n " : " ") + r;
      };
    });
    Xc = {};
    bo.transitional = function r(e, t, n) {
      function i(s, a) {
        return "[Axios v" + Ei + "] Transitional option '" + s + "'" + a + (n ? ". " + n : "");
      }
      return (s, a, o) => {
        if (e === false) {
          throw new ee(
            i(a, " has been removed" + (t ? " in " + t : "")),
            ee.ERR_DEPRECATED
          );
        }
        if (t && !Xc[a]) {
          Xc[a] = true;
          console.warn(
            i(
              a,
              " has been deprecated since v" + t + " and will be removed in the near future"
            )
          );
        }
        return e ? e(s, a, o) : true;
      };
    };
    Ti = {
      assertOptions: ky,
      validators: bo
    };
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/core/Axios.js
  var Vt, Rr, Sn;
  var td = j(() => {
    "use strict";
    ye();
    eo();
    xc();
    Wc();
    mo();
    po();
    ed();
    er();
    Vt = Ti.validators;
    Rr = class {
      constructor(e) {
        this.defaults = e;
        this.interceptors = {
          request: new ro(),
          response: new ro()
        };
      }
      /**
       * Dispatch a request
       *
       * @param {String|Object} configOrUrl The config specific for this request (merged with this.defaults)
       * @param {?Object} config
       *
       * @returns {Promise} The Promise to be fulfilled
       */
      request(e, t) {
        if (typeof e === "string") {
          t = t || {};
          t.url = e;
        } else {
          t = e || {};
        }
        t = xt(this.defaults, t);
        const { transitional: n, paramsSerializer: i, headers: s } = t;
        if (n !== void 0) {
          Ti.assertOptions(n, {
            silentJSONParsing: Vt.transitional(Vt.boolean),
            forcedJSONParsing: Vt.transitional(Vt.boolean),
            clarifyTimeoutError: Vt.transitional(Vt.boolean)
          }, false);
        }
        if (i != null) {
          if (T.isFunction(i)) {
            t.paramsSerializer = {
              serialize: i
            };
          } else {
            Ti.assertOptions(i, {
              encode: Vt.function,
              serialize: Vt.function
            }, true);
          }
        }
        t.method = (t.method || this.defaults.method || "get").toLowerCase();
        let a;
        a = s && T.merge(
          s.common,
          s[t.method]
        );
        a && T.forEach(
          ["delete", "get", "head", "post", "put", "patch", "common"],
          (f) => {
            delete s[f];
          }
        );
        t.headers = je.concat(a, s);
        const o = [];
        let u = true;
        this.interceptors.request.forEach(function f(P) {
          if (typeof P.runWhen === "function" && P.runWhen(t) === false) {
            return;
          }
          u = u && P.synchronous;
          o.unshift(P.fulfilled, P.rejected);
        });
        const l = [];
        this.interceptors.response.forEach(function f(P) {
          l.push(P.fulfilled, P.rejected);
        });
        let c;
        let b = 0;
        let _;
        if (!u) {
          const f = [Ai.bind(this), void 0];
          f.unshift.apply(f, o);
          f.push.apply(f, l);
          _ = f.length;
          c = Promise.resolve(t);
          while (b < _) {
            c = c.then(f[b++], f[b++]);
          }
          return c;
        }
        _ = o.length;
        let x = t;
        b = 0;
        while (b < _) {
          const f = o[b++];
          const P = o[b++];
          try {
            x = f(x);
          } catch (S) {
            P.call(this, S);
            break;
          }
        }
        try {
          c = Ai.call(this, x);
        } catch (f) {
          return Promise.reject(f);
        }
        b = 0;
        _ = l.length;
        while (b < _) {
          c = c.then(l[b++], l[b++]);
        }
        return c;
      }
      getUri(e) {
        e = xt(this.defaults, e);
        const t = Cn(e.baseURL, e.url);
        return Pn(t, e.params, e.paramsSerializer);
      }
    };
    T.forEach(["delete", "get", "head", "options"], function r(e) {
      Rr.prototype[e] = function(t, n) {
        return this.request(xt(n || {}, {
          method: e,
          url: t,
          data: (n || {}).data
        }));
      };
    });
    T.forEach(["post", "put", "patch"], function r(e) {
      function t(n) {
        return function i(s, a, o) {
          return this.request(xt(o || {}, {
            method: e,
            headers: n ? {
              "Content-Type": "multipart/form-data"
            } : {},
            url: s,
            data: a
          }));
        };
      }
      Rr.prototype[e] = t();
      Rr.prototype[e + "Form"] = t(true);
    });
    Sn = Rr;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/cancel/CancelToken.js
  var jn, rd;
  var nd = j(() => {
    "use strict";
    In();
    jn = class {
      constructor(e) {
        if (typeof e !== "function") {
          throw new TypeError("executor must be a function.");
        }
        let t;
        this.promise = new Promise(function i(s) {
          t = s;
        });
        const n = this;
        this.promise.then((i) => {
          if (!n._listeners)
            return;
          let s = n._listeners.length;
          while (s-- > 0) {
            n._listeners[s](i);
          }
          n._listeners = null;
        });
        this.promise.then = (i) => {
          let s;
          const a = new Promise((o) => {
            n.subscribe(o);
            s = o;
          }).then(i);
          a.cancel = function o() {
            n.unsubscribe(s);
          };
          return a;
        };
        e(function i(s, a, o) {
          if (n.reason) {
            return;
          }
          n.reason = new Ut(s, a, o);
          t(n.reason);
        });
      }
      /**
       * Throws a `CanceledError` if cancellation has been requested.
       */
      throwIfRequested() {
        if (this.reason) {
          throw this.reason;
        }
      }
      /**
       * Subscribe to the cancel signal
       */
      subscribe(e) {
        if (this.reason) {
          e(this.reason);
          return;
        }
        if (this._listeners) {
          this._listeners.push(e);
        } else {
          this._listeners = [e];
        }
      }
      /**
       * Unsubscribe from the cancel signal
       */
      unsubscribe(e) {
        if (!this._listeners) {
          return;
        }
        const t = this._listeners.indexOf(e);
        if (t !== -1) {
          this._listeners.splice(t, 1);
        }
      }
      /**
       * Returns an object that contains a new `CancelToken` and a function that, when called,
       * cancels the `CancelToken`.
       */
      static source() {
        let e;
        const t = new jn(function n(i) {
          e = i;
        });
        return {
          token: t,
          cancel: e
        };
      }
    };
    rd = jn;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/spread.js
  function go(r) {
    return function e(t) {
      return r.apply(null, t);
    };
  }
  var id = j(() => {
    "use strict";
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/isAxiosError.js
  function wo(r) {
    return T.isObject(r) && r.isAxiosError === true;
  }
  var sd = j(() => {
    "use strict";
    ye();
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/helpers/HttpStatusCode.js
  var _o, ad;
  var od = j(() => {
    _o = {
      Continue: 100,
      SwitchingProtocols: 101,
      Processing: 102,
      EarlyHints: 103,
      Ok: 200,
      Created: 201,
      Accepted: 202,
      NonAuthoritativeInformation: 203,
      NoContent: 204,
      ResetContent: 205,
      PartialContent: 206,
      MultiStatus: 207,
      AlreadyReported: 208,
      ImUsed: 226,
      MultipleChoices: 300,
      MovedPermanently: 301,
      Found: 302,
      SeeOther: 303,
      NotModified: 304,
      UseProxy: 305,
      Unused: 306,
      TemporaryRedirect: 307,
      PermanentRedirect: 308,
      BadRequest: 400,
      Unauthorized: 401,
      PaymentRequired: 402,
      Forbidden: 403,
      NotFound: 404,
      MethodNotAllowed: 405,
      NotAcceptable: 406,
      ProxyAuthenticationRequired: 407,
      RequestTimeout: 408,
      Conflict: 409,
      Gone: 410,
      LengthRequired: 411,
      PreconditionFailed: 412,
      PayloadTooLarge: 413,
      UriTooLong: 414,
      UnsupportedMediaType: 415,
      RangeNotSatisfiable: 416,
      ExpectationFailed: 417,
      ImATeapot: 418,
      MisdirectedRequest: 421,
      UnprocessableEntity: 422,
      Locked: 423,
      FailedDependency: 424,
      TooEarly: 425,
      UpgradeRequired: 426,
      PreconditionRequired: 428,
      TooManyRequests: 429,
      RequestHeaderFieldsTooLarge: 431,
      UnavailableForLegalReasons: 451,
      InternalServerError: 500,
      NotImplemented: 501,
      BadGateway: 502,
      ServiceUnavailable: 503,
      GatewayTimeout: 504,
      HttpVersionNotSupported: 505,
      VariantAlsoNegotiates: 506,
      InsufficientStorage: 507,
      LoopDetected: 508,
      NotExtended: 510,
      NetworkAuthenticationRequired: 511
    };
    Object.entries(_o).forEach(([r, e]) => {
      _o[e] = r;
    });
    ad = _o;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/lib/axios.js
  function ud(r) {
    const e = new Sn(r);
    const t = _n(Sn.prototype.request, e);
    T.extend(t, Sn.prototype, e, { allOwnKeys: true });
    T.extend(t, e, null, { allOwnKeys: true });
    t.create = function n(i) {
      return ud(xt(r, i));
    };
    return t;
  }
  var ge, tr;
  var ld = j(() => {
    "use strict";
    ye();
    Ha();
    td();
    mo();
    xi();
    so();
    In();
    nd();
    oo();
    yo();
    On();
    vt();
    id();
    sd();
    er();
    od();
    ge = ud(jr);
    ge.Axios = Sn;
    ge.CanceledError = Ut;
    ge.CancelToken = rd;
    ge.isCancel = Tn;
    ge.VERSION = Ei;
    ge.toFormData = qt;
    ge.AxiosError = ee;
    ge.Cancel = ge.CanceledError;
    ge.all = function r(e) {
      return Promise.all(e);
    };
    ge.spread = go;
    ge.isAxiosError = wo;
    ge.mergeConfig = xt;
    ge.AxiosHeaders = je;
    ge.formToJSON = (r) => _i(T.isHTMLForm(r) ? new FormData(r) : r);
    ge.HttpStatusCode = ad;
    ge.default = ge;
    tr = ge;
  });

  // node_modules/.pnpm/registry.npmmirror.com+axios@1.4.0/node_modules/axios/index.js
  var P0, A0, E0, T0, I0, C0, S0, j0, k0, R0, N0, M0, L0, D0, q0;
  var cd = j(() => {
    ld();
    ({
      Axios: P0,
      AxiosError: A0,
      CanceledError: E0,
      isCancel: T0,
      CancelToken: I0,
      VERSION: C0,
      all: S0,
      Cancel: j0,
      isAxiosError: k0,
      spread: R0,
      toFormData: N0,
      AxiosHeaders: M0,
      HttpStatusCode: L0,
      formToJSON: D0,
      mergeConfig: q0
    } = tr);
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/util/event-source-parse.js
  async function dd(r, e) {
    const t = r.getReader();
    while (true) {
      const n = await t.read();
      if (n.done) {
        e(new Uint8Array(), true);
        break;
      }
      e(n.value);
    }
  }
  function pd(r) {
    let e;
    let t;
    let n;
    let i = false;
    return function s(a, o) {
      if (o) {
        r(a, 0, true);
        return;
      }
      if (e === void 0) {
        e = a;
        t = 0;
        n = -1;
      } else {
        e = Ry(e, a);
      }
      const u = e.length;
      let l = 0;
      while (t < u) {
        if (i) {
          if (e[t] === 10) {
            l = ++t;
          }
          i = false;
        }
        let c = -1;
        for (; t < u && c === -1; ++t) {
          switch (e[t]) {
            case 58:
              if (n === -1) {
                n = t - l;
              }
              break;
            case 13:
              i = true;
            case 10:
              c = t;
              break;
          }
        }
        if (c === -1) {
          break;
        }
        r(e.subarray(l, c), n);
        l = t;
        n = -1;
      }
      if (l === u) {
        e = void 0;
      } else if (l !== 0) {
        e = e.subarray(l);
        t -= l;
      }
    };
  }
  function hd(r, e, t) {
    let n = vo();
    const i = new TextDecoder();
    return function s(a, o, u) {
      if (u) {
        if (!Ny(n)) {
          r?.(n);
          n = vo();
        }
        return;
      }
      if (a.length === 0) {
        r?.(n);
        n = vo();
      } else if (o > 0) {
        const l = i.decode(a.subarray(0, o));
        const c = o + (a[o + 1] === 32 ? 2 : 1);
        const b = i.decode(a.subarray(c));
        switch (l) {
          case "data":
            n.data = n.data ? n.data + "\n" + b : b;
            break;
          case "event":
            n.event = b;
            break;
          case "id":
            e?.(n.id = b);
            break;
          case "retry": {
            const _ = parseInt(b, 10);
            if (!Number.isNaN(_)) {
              t?.(n.retry = _);
            }
            break;
          }
        }
      }
    };
  }
  function Ry(r, e) {
    const t = new Uint8Array(r.length + e.length);
    t.set(r);
    t.set(e, r.length);
    return t;
  }
  function vo() {
    return {
      data: "",
      event: "",
      id: "",
      retry: void 0
    };
  }
  function Ny(r) {
    return r.data === "" && r.event === "" && r.id === "" && r.retry === void 0;
  }
  var Ii;
  var fd = j(() => {
    Ii = "text/event-stream";
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/util/axios-fetch-adapter.js
  function My(r) {
    try {
      return JSON.stringify(r);
    } catch (e) {
      return r;
    }
  }
  function Ly(r, e, t) {
    const { validateStatus: n } = t.config;
    if (!t.status || !n || n(t.status)) {
      r(t);
    } else {
      e(Ci(`Request failed with status code ${t.status} and body ${typeof t.data === "string" ? t.data : My(t.data)}`, t.config, null, t.request, t));
    }
  }
  function Dy(r) {
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(r);
  }
  function qy(r, e) {
    return e ? r.replace(/\/+$/, "") + "/" + e.replace(/^\/+/, "") : r;
  }
  function md(r) {
    return encodeURIComponent(r).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
  }
  function Uy(r, e, t) {
    if (!e) {
      return r;
    }
    var n;
    if (t) {
      n = t(e);
    } else if (By(e)) {
      n = e.toString();
    } else {
      var i = [];
      yd(e, function a(o, u) {
        if (o === null || typeof o === "undefined") {
          return;
        }
        if (bd(o)) {
          u = `${u}[]`;
        } else {
          o = [o];
        }
        yd(o, function l(c) {
          if (Ky(c)) {
            c = c.toISOString();
          } else if (Fy(c)) {
            c = JSON.stringify(c);
          }
          i.push(`${md(u)}=${md(c)}`);
        });
      });
      n = i.join("&");
    }
    if (n) {
      var s = r.indexOf("#");
      if (s !== -1) {
        r = r.slice(0, s);
      }
      r += (r.indexOf("?") === -1 ? "?" : "&") + n;
    }
    return r;
  }
  function Vy(r, e) {
    if (r && !Dy(e)) {
      return qy(r, e);
    }
    return e;
  }
  function zy(r) {
    return typeof r === "undefined";
  }
  function Fy(r) {
    return r !== null && typeof r === "object";
  }
  function Ky(r) {
    return toString.call(r) === "[object Date]";
  }
  function By(r) {
    return toString.call(r) === "[object URLSearchParams]";
  }
  function bd(r) {
    return Array.isArray(r);
  }
  function yd(r, e) {
    if (r === null || typeof r === "undefined") {
      return;
    }
    if (typeof r !== "object") {
      r = [r];
    }
    if (bd(r)) {
      for (var t = 0, n = r.length; t < n; t++) {
        e.call(null, r[t], t, r);
      }
    } else {
      for (var i in r) {
        if (Object.prototype.hasOwnProperty.call(r, i)) {
          e.call(null, r[i], i, r);
        }
      }
    }
  }
  function $y(r) {
    return toString.call(r) === "[object FormData]";
  }
  function Zy() {
    if (typeof navigator !== "undefined" && // eslint-disable-next-line no-undef
    (navigator.product === "ReactNative" || // eslint-disable-next-line no-undef
    navigator.product === "NativeScript" || // eslint-disable-next-line no-undef
    navigator.product === "NS")) {
      return false;
    }
    return typeof window !== "undefined" && typeof document !== "undefined";
  }
  async function Fe(r) {
    const e = Qy(r);
    const t = await Hy(e, r);
    return new Promise((n, i) => {
      if (t instanceof Error) {
        i(t);
      } else {
        Object.prototype.toString.call(r.settle) === "[object Function]" ? r.settle(n, i, t) : Ly(n, i, t);
      }
    });
  }
  async function Hy(r, e) {
    let t;
    try {
      t = await fetch(r);
    } catch (s) {
      if (s && s.name === "AbortError") {
        return Ci("Request aborted", e, "ECONNABORTED", r);
      }
      if (s && s.name === "TimeoutError") {
        return Ci("Request timeout", e, "ECONNABORTED", r);
      }
      return Ci("Network Error", e, "ERR_NETWORK", r);
    }
    const n = {};
    t.headers.forEach((s, a) => {
      n[a] = s;
    });
    const i = {
      ok: t.ok,
      status: t.status,
      statusText: t.statusText,
      headers: n,
      config: e,
      request: r
    };
    if (t.status >= 200 && t.status !== 204) {
      if (e.responseType === "stream") {
        const s = t.headers.get("content-type");
        if (!s?.startsWith(Ii)) {
          if (t.status >= 400) {
            if (s?.startsWith("application/json")) {
              i.data = await t.json();
              return i;
            } else {
              i.data = await t.text();
              return i;
            }
          }
          throw new Error(`Expected content-type to be ${Ii}, Actual: ${s}`);
        }
        await dd(t.body, pd(hd(e.onmessage)));
      } else {
        switch (e.responseType) {
          case "arraybuffer":
            i.data = await t.arrayBuffer();
            break;
          case "blob":
            i.data = await t.blob();
            break;
          case "json":
            i.data = await t.json();
            break;
          case "formData":
            i.data = await t.formData();
            break;
          default:
            i.data = await t.text();
            break;
        }
      }
    }
    return i;
  }
  function Qy(r) {
    const e = new Headers(r.headers);
    if (r.auth) {
      const a = r.auth.username || "";
      const o = r.auth.password ? decodeURI(encodeURIComponent(r.auth.password)) : "";
      e.set("Authorization", `Basic ${btoa(`${a}:${o}`)}`);
    }
    const t = r.method.toUpperCase();
    const n = {
      headers: e,
      method: t
    };
    if (t !== "GET" && t !== "HEAD") {
      n.body = r.data;
      if ($y(n.body) && Zy()) {
        e.delete("Content-Type");
      }
    }
    if (typeof n.body === "string") {
      n.body = new TextEncoder().encode(n.body);
    }
    if (r.mode) {
      n.mode = r.mode;
    }
    if (r.cache) {
      n.cache = r.cache;
    }
    if (r.integrity) {
      n.integrity = r.integrity;
    }
    if (r.redirect) {
      n.redirect = r.redirect;
    }
    if (r.referrer) {
      n.referrer = r.referrer;
    }
    if (r.timeout && r.timeout > 0) {
      n.signal = AbortSignal.timeout(r.timeout);
    }
    if (r.signal) {
      n.signal = r.signal;
    }
    if (!zy(r.withCredentials)) {
      n.credentials = r.withCredentials ? "include" : "omit";
    }
    if (r.responseType === "stream") {
      n.headers.set("Accept", Ii);
    }
    const i = Vy(r.baseURL, r.url);
    const s = Uy(i, r.params, r.paramsSerializer);
    return new Request(s, n);
  }
  function Ci(r, e, t, n, i) {
    if (tr.AxiosError && typeof tr.AxiosError === "function") {
      return new tr.AxiosError(r, tr.AxiosError[t], e, n, i);
    }
    const s = new Error(r);
    return Jy(s, e, t, n, i);
  }
  function Jy(r, e, t, n, i) {
    r.config = e;
    if (t) {
      r.code = t;
    }
    r.request = n;
    r.response = i;
    r.isAxiosError = true;
    r.toJSON = function s() {
      return {
        // Standard
        message: this.message,
        name: this.name,
        // Microsoft
        description: this.description,
        number: this.number,
        // Mozilla
        fileName: this.fileName,
        lineNumber: this.lineNumber,
        columnNumber: this.columnNumber,
        stack: this.stack,
        // Axios
        config: this.config,
        code: this.code,
        status: this.response && this.response.status ? this.response.status : null
      };
    };
    return r;
  }
  var Nr = j(() => {
    cd();
    fd();
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/util/chunk.js
  var kn;
  var xo = j(() => {
    kn = (r, e) => r.reduce((t, n, i) => {
      const s = Math.floor(i / e);
      const a = t[s] || [];
      t[s] = a.concat([n]);
      return t;
    }, []);
  });

  // node_modules/.pnpm/object-hash@3.0.0/node_modules/object-hash/dist/object_hash.js
  var _d = N((gd, wd) => {
    !function(r) {
      var e;
      "object" == typeof gd ? wd.exports = r() : "function" == typeof define && define.amd ? define(r) : ("undefined" != typeof window ? e = window : "undefined" != typeof global ? e = global : "undefined" != typeof self && (e = self), e.objectHash = r());
    }(function() {
      return function r(e, t, n) {
        function i(o, u) {
          if (!t[o]) {
            if (!e[o]) {
              var l = "function" == typeof bn && bn;
              if (!u && l)
                return l(o, true);
              if (s)
                return s(o, true);
              throw new Error("Cannot find module '" + o + "'");
            }
            u = t[o] = { exports: {} };
            e[o][0].call(u.exports, function(c) {
              var b = e[o][1][c];
              return i(b || c);
            }, u, u.exports, r, e, t, n);
          }
          return t[o].exports;
        }
        for (var s = "function" == typeof bn && bn, a = 0; a < n.length; a++)
          i(n[a]);
        return i;
      }({ 1: [function(r, e, t) {
        !function(n, i, s, a, o, u, l, c, b) {
          "use strict";
          var _ = r("crypto");
          function x(g, C) {
            C = S(g, C);
            var h;
            return void 0 === (h = "passthrough" !== C.algorithm ? _.createHash(C.algorithm) : new U()).write && (h.write = h.update, h.end = h.update), R(C, h).dispatch(g), h.update || h.end(""), h.digest ? h.digest("buffer" === C.encoding ? void 0 : C.encoding) : (g = h.read(), "buffer" !== C.encoding ? g.toString(C.encoding) : g);
          }
          (t = e.exports = x).sha1 = function(g) {
            return x(g);
          }, t.keys = function(g) {
            return x(g, { excludeValues: true, algorithm: "sha1", encoding: "hex" });
          }, t.MD5 = function(g) {
            return x(g, { algorithm: "md5", encoding: "hex" });
          }, t.keysMD5 = function(g) {
            return x(g, { algorithm: "md5", encoding: "hex", excludeValues: true });
          };
          var f = _.getHashes ? _.getHashes().slice() : ["sha1", "md5"], P = (f.push("passthrough"), ["buffer", "hex", "binary", "base64"]);
          function S(g, C) {
            var h = {};
            if (h.algorithm = (C = C || {}).algorithm || "sha1", h.encoding = C.encoding || "hex", h.excludeValues = !!C.excludeValues, h.algorithm = h.algorithm.toLowerCase(), h.encoding = h.encoding.toLowerCase(), h.ignoreUnknown = true === C.ignoreUnknown, h.respectType = false !== C.respectType, h.respectFunctionNames = false !== C.respectFunctionNames, h.respectFunctionProperties = false !== C.respectFunctionProperties, h.unorderedArrays = true === C.unorderedArrays, h.unorderedSets = false !== C.unorderedSets, h.unorderedObjects = false !== C.unorderedObjects, h.replacer = C.replacer || void 0, h.excludeKeys = C.excludeKeys || void 0, void 0 === g)
              throw new Error("Object argument required.");
            for (var y = 0; y < f.length; ++y)
              f[y].toLowerCase() === h.algorithm.toLowerCase() && (h.algorithm = f[y]);
            if (-1 === f.indexOf(h.algorithm))
              throw new Error('Algorithm "' + h.algorithm + '"  not supported. supported values: ' + f.join(", "));
            if (-1 === P.indexOf(h.encoding) && "passthrough" !== h.algorithm)
              throw new Error('Encoding "' + h.encoding + '"  not supported. supported values: ' + P.join(", "));
            return h;
          }
          function k(g) {
            if ("function" == typeof g)
              return null != /^function\s+\w*\s*\(\s*\)\s*{\s+\[native code\]\s+}$/i.exec(Function.prototype.toString.call(g));
          }
          function R(g, C, h) {
            h = h || [];
            function y(p) {
              return C.update ? C.update(p, "utf8") : C.write(p, "utf8");
            }
            return { dispatch: function(p) {
              return this["_" + (null === (p = g.replacer ? g.replacer(p) : p) ? "null" : typeof p)](p);
            }, _object: function(p) {
              var A, I = Object.prototype.toString.call(p), Q = /\[object (.*)\]/i.exec(I);
              Q = (Q = Q ? Q[1] : "unknown:[" + I + "]").toLowerCase();
              if (0 <= (I = h.indexOf(p)))
                return this.dispatch("[CIRCULAR:" + I + "]");
              if (h.push(p), void 0 !== s && s.isBuffer && s.isBuffer(p))
                return y("buffer:"), y(p);
              if ("object" === Q || "function" === Q || "asyncfunction" === Q)
                return I = Object.keys(p), g.unorderedObjects && (I = I.sort()), false === g.respectType || k(p) || I.splice(0, 0, "prototype", "__proto__", "constructor"), g.excludeKeys && (I = I.filter(function(Z) {
                  return !g.excludeKeys(Z);
                })), y("object:" + I.length + ":"), A = this, I.forEach(function(Z) {
                  A.dispatch(Z), y(":"), g.excludeValues || A.dispatch(p[Z]), y(",");
                });
              if (!this["_" + Q]) {
                if (g.ignoreUnknown)
                  return y("[" + Q + "]");
                throw new Error('Unknown object type "' + Q + '"');
              }
              this["_" + Q](p);
            }, _array: function(p, Z) {
              Z = void 0 !== Z ? Z : false !== g.unorderedArrays;
              var I = this;
              if (y("array:" + p.length + ":"), !Z || p.length <= 1)
                return p.forEach(function(J) {
                  return I.dispatch(J);
                });
              var Q = [], Z = p.map(function(J) {
                var F = new U(), de = h.slice();
                return R(g, F, de).dispatch(J), Q = Q.concat(de.slice(h.length)), F.read().toString();
              });
              return h = h.concat(Q), Z.sort(), this._array(Z, false);
            }, _date: function(p) {
              return y("date:" + p.toJSON());
            }, _symbol: function(p) {
              return y("symbol:" + p.toString());
            }, _error: function(p) {
              return y("error:" + p.toString());
            }, _boolean: function(p) {
              return y("bool:" + p.toString());
            }, _string: function(p) {
              y("string:" + p.length + ":"), y(p.toString());
            }, _function: function(p) {
              y("fn:"), k(p) ? this.dispatch("[native]") : this.dispatch(p.toString()), false !== g.respectFunctionNames && this.dispatch("function-name:" + String(p.name)), g.respectFunctionProperties && this._object(p);
            }, _number: function(p) {
              return y("number:" + p.toString());
            }, _xml: function(p) {
              return y("xml:" + p.toString());
            }, _null: function() {
              return y("Null");
            }, _undefined: function() {
              return y("Undefined");
            }, _regexp: function(p) {
              return y("regex:" + p.toString());
            }, _uint8array: function(p) {
              return y("uint8array:"), this.dispatch(Array.prototype.slice.call(p));
            }, _uint8clampedarray: function(p) {
              return y("uint8clampedarray:"), this.dispatch(Array.prototype.slice.call(p));
            }, _int8array: function(p) {
              return y("int8array:"), this.dispatch(Array.prototype.slice.call(p));
            }, _uint16array: function(p) {
              return y("uint16array:"), this.dispatch(Array.prototype.slice.call(p));
            }, _int16array: function(p) {
              return y("int16array:"), this.dispatch(Array.prototype.slice.call(p));
            }, _uint32array: function(p) {
              return y("uint32array:"), this.dispatch(Array.prototype.slice.call(p));
            }, _int32array: function(p) {
              return y("int32array:"), this.dispatch(Array.prototype.slice.call(p));
            }, _float32array: function(p) {
              return y("float32array:"), this.dispatch(Array.prototype.slice.call(p));
            }, _float64array: function(p) {
              return y("float64array:"), this.dispatch(Array.prototype.slice.call(p));
            }, _arraybuffer: function(p) {
              return y("arraybuffer:"), this.dispatch(new Uint8Array(p));
            }, _url: function(p) {
              return y("url:" + p.toString());
            }, _map: function(p) {
              y("map:");
              p = Array.from(p);
              return this._array(p, false !== g.unorderedSets);
            }, _set: function(p) {
              y("set:");
              p = Array.from(p);
              return this._array(p, false !== g.unorderedSets);
            }, _file: function(p) {
              return y("file:"), this.dispatch([p.name, p.size, p.type, p.lastModfied]);
            }, _blob: function() {
              if (g.ignoreUnknown)
                return y("[blob]");
              throw Error('Hashing Blob objects is currently not supported\n(see https://github.com/puleos/object-hash/issues/26)\nUse "options.replacer" or "options.ignoreUnknown"\n');
            }, _domwindow: function() {
              return y("domwindow");
            }, _bigint: function(p) {
              return y("bigint:" + p.toString());
            }, _process: function() {
              return y("process");
            }, _timer: function() {
              return y("timer");
            }, _pipe: function() {
              return y("pipe");
            }, _tcp: function() {
              return y("tcp");
            }, _udp: function() {
              return y("udp");
            }, _tty: function() {
              return y("tty");
            }, _statwatcher: function() {
              return y("statwatcher");
            }, _securecontext: function() {
              return y("securecontext");
            }, _connection: function() {
              return y("connection");
            }, _zlib: function() {
              return y("zlib");
            }, _context: function() {
              return y("context");
            }, _nodescript: function() {
              return y("nodescript");
            }, _httpparser: function() {
              return y("httpparser");
            }, _dataview: function() {
              return y("dataview");
            }, _signal: function() {
              return y("signal");
            }, _fsevent: function() {
              return y("fsevent");
            }, _tlswrap: function() {
              return y("tlswrap");
            } };
          }
          function U() {
            return { buf: "", write: function(g) {
              this.buf += g;
            }, end: function(g) {
              this.buf += g;
            }, read: function() {
              return this.buf;
            } };
          }
          t.writeToStream = function(g, C, h) {
            return void 0 === h && (h = C, C = {}), R(C = S(g, C), h).dispatch(g);
          };
        }.call(this, r("lYpoI2"), "undefined" != typeof self ? self : "undefined" != typeof window ? window : {}, r("buffer").Buffer, arguments[3], arguments[4], arguments[5], arguments[6], "/fake_9a5aa49d.js", "/");
      }, { buffer: 3, crypto: 5, lYpoI2: 11 }], 2: [function(r, e, t) {
        !function(n, i, s, a, o, u, l, c, b) {
          !function(_) {
            "use strict";
            var x = "undefined" != typeof Uint8Array ? Uint8Array : Array, f = "+".charCodeAt(0), P = "/".charCodeAt(0), S = "0".charCodeAt(0), k = "a".charCodeAt(0), R = "A".charCodeAt(0), U = "-".charCodeAt(0), g = "_".charCodeAt(0);
            function C(h) {
              h = h.charCodeAt(0);
              return h === f || h === U ? 62 : h === P || h === g ? 63 : h < S ? -1 : h < S + 10 ? h - S + 26 + 26 : h < R + 26 ? h - R : h < k + 26 ? h - k + 26 : void 0;
            }
            _.toByteArray = function(h) {
              var y, p;
              if (0 < h.length % 4)
                throw new Error("Invalid string. Length must be a multiple of 4");
              var A = h.length, A = "=" === h.charAt(A - 2) ? 2 : "=" === h.charAt(A - 1) ? 1 : 0, I = new x(3 * h.length / 4 - A), Q = 0 < A ? h.length - 4 : h.length, Z = 0;
              function J(F) {
                I[Z++] = F;
              }
              for (y = 0; y < Q; y += 4, 0)
                J((16711680 & (p = C(h.charAt(y)) << 18 | C(h.charAt(y + 1)) << 12 | C(h.charAt(y + 2)) << 6 | C(h.charAt(y + 3)))) >> 16), J((65280 & p) >> 8), J(255 & p);
              return 2 == A ? J(255 & (p = C(h.charAt(y)) << 2 | C(h.charAt(y + 1)) >> 4)) : 1 == A && (J((p = C(h.charAt(y)) << 10 | C(h.charAt(y + 1)) << 4 | C(h.charAt(y + 2)) >> 2) >> 8 & 255), J(255 & p)), I;
            }, _.fromByteArray = function(h) {
              var y, p, A, I, Q = h.length % 3, Z = "";
              function J(F) {
                return "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(F);
              }
              for (y = 0, A = h.length - Q; y < A; y += 3)
                p = (h[y] << 16) + (h[y + 1] << 8) + h[y + 2], Z += J((I = p) >> 18 & 63) + J(I >> 12 & 63) + J(I >> 6 & 63) + J(63 & I);
              switch (Q) {
                case 1:
                  Z = (Z += J((p = h[h.length - 1]) >> 2)) + J(p << 4 & 63) + "==";
                  break;
                case 2:
                  Z = (Z = (Z += J((p = (h[h.length - 2] << 8) + h[h.length - 1]) >> 10)) + J(p >> 4 & 63)) + J(p << 2 & 63) + "=";
              }
              return Z;
            };
          }(void 0 === t ? this.base64js = {} : t);
        }.call(this, r("lYpoI2"), "undefined" != typeof self ? self : "undefined" != typeof window ? window : {}, r("buffer").Buffer, arguments[3], arguments[4], arguments[5], arguments[6], "/node_modules/gulp-browserify/node_modules/base64-js/lib/b64.js", "/node_modules/gulp-browserify/node_modules/base64-js/lib");
      }, { buffer: 3, lYpoI2: 11 }], 3: [function(r, e, t) {
        !function(n, i, f, a, o, u, l, c, b) {
          var _ = r("base64-js"), x = r("ieee754");
          function f(d, m, w) {
            if (!(this instanceof f))
              return new f(d, m, w);
            var L, M, z, te, fe = typeof d;
            if ("base64" === m && "string" == fe)
              for (d = (te = d).trim ? te.trim() : te.replace(/^\s+|\s+$/g, ""); d.length % 4 != 0; )
                d += "=";
            if ("number" == fe)
              L = Ae(d);
            else if ("string" == fe)
              L = f.byteLength(d, m);
            else {
              if ("object" != fe)
                throw new Error("First argument needs to be a number, array or string.");
              L = Ae(d.length);
            }
            if (f._useTypedArrays ? M = f._augment(new Uint8Array(L)) : ((M = this).length = L, M._isBuffer = true), f._useTypedArrays && "number" == typeof d.byteLength)
              M._set(d);
            else if (he(te = d) || f.isBuffer(te) || te && "object" == typeof te && "number" == typeof te.length)
              for (z = 0; z < L; z++)
                f.isBuffer(d) ? M[z] = d.readUInt8(z) : M[z] = d[z];
            else if ("string" == fe)
              M.write(d, 0, m);
            else if ("number" == fe && !f._useTypedArrays && !w)
              for (z = 0; z < L; z++)
                M[z] = 0;
            return M;
          }
          function P(d, m, w, L) {
            return f._charsWritten = ni(function(M) {
              for (var z = [], te = 0; te < M.length; te++)
                z.push(255 & M.charCodeAt(te));
              return z;
            }(m), d, w, L);
          }
          function S(d, m, w, L) {
            return f._charsWritten = ni(function(M) {
              for (var z, te, fe = [], _e = 0; _e < M.length; _e++)
                te = M.charCodeAt(_e), z = te >> 8, te = te % 256, fe.push(te), fe.push(z);
              return fe;
            }(m), d, w, L);
          }
          function k(d, m, w) {
            var L = "";
            w = Math.min(d.length, w);
            for (var M = m; M < w; M++)
              L += String.fromCharCode(d[M]);
            return L;
          }
          function R(d, m, w, z) {
            z || (V("boolean" == typeof w, "missing or invalid endian"), V(null != m, "missing offset"), V(m + 1 < d.length, "Trying to read beyond buffer length"));
            var M, z = d.length;
            if (!(z <= m))
              return w ? (M = d[m], m + 1 < z && (M |= d[m + 1] << 8)) : (M = d[m] << 8, m + 1 < z && (M |= d[m + 1])), M;
          }
          function U(d, m, w, z) {
            z || (V("boolean" == typeof w, "missing or invalid endian"), V(null != m, "missing offset"), V(m + 3 < d.length, "Trying to read beyond buffer length"));
            var M, z = d.length;
            if (!(z <= m))
              return w ? (m + 2 < z && (M = d[m + 2] << 16), m + 1 < z && (M |= d[m + 1] << 8), M |= d[m], m + 3 < z && (M += d[m + 3] << 24 >>> 0)) : (m + 1 < z && (M = d[m + 1] << 16), m + 2 < z && (M |= d[m + 2] << 8), m + 3 < z && (M |= d[m + 3]), M += d[m] << 24 >>> 0), M;
          }
          function g(d, m, w, L) {
            if (L || (V("boolean" == typeof w, "missing or invalid endian"), V(null != m, "missing offset"), V(m + 1 < d.length, "Trying to read beyond buffer length")), !(d.length <= m))
              return L = R(d, m, w, true), 32768 & L ? -1 * (65535 - L + 1) : L;
          }
          function C(d, m, w, L) {
            if (L || (V("boolean" == typeof w, "missing or invalid endian"), V(null != m, "missing offset"), V(m + 3 < d.length, "Trying to read beyond buffer length")), !(d.length <= m))
              return L = U(d, m, w, true), 2147483648 & L ? -1 * (4294967295 - L + 1) : L;
          }
          function h(d, m, w, L) {
            return L || (V("boolean" == typeof w, "missing or invalid endian"), V(m + 3 < d.length, "Trying to read beyond buffer length")), x.read(d, m, w, 23, 4);
          }
          function y(d, m, w, L) {
            return L || (V("boolean" == typeof w, "missing or invalid endian"), V(m + 7 < d.length, "Trying to read beyond buffer length")), x.read(d, m, w, 52, 8);
          }
          function p(d, m, w, L, M) {
            M || (V(null != m, "missing value"), V("boolean" == typeof L, "missing or invalid endian"), V(null != w, "missing offset"), V(w + 1 < d.length, "trying to write beyond buffer length"), ma(m, 65535));
            M = d.length;
            if (!(M <= w))
              for (var z = 0, te = Math.min(M - w, 2); z < te; z++)
                d[w + z] = (m & 255 << 8 * (L ? z : 1 - z)) >>> 8 * (L ? z : 1 - z);
          }
          function A(d, m, w, L, M) {
            M || (V(null != m, "missing value"), V("boolean" == typeof L, "missing or invalid endian"), V(null != w, "missing offset"), V(w + 3 < d.length, "trying to write beyond buffer length"), ma(m, 4294967295));
            M = d.length;
            if (!(M <= w))
              for (var z = 0, te = Math.min(M - w, 4); z < te; z++)
                d[w + z] = m >>> 8 * (L ? z : 3 - z) & 255;
          }
          function I(d, m, w, L, M) {
            M || (V(null != m, "missing value"), V("boolean" == typeof L, "missing or invalid endian"), V(null != w, "missing offset"), V(w + 1 < d.length, "Trying to write beyond buffer length"), ya(m, 32767, -32768)), d.length <= w || p(d, 0 <= m ? m : 65535 + m + 1, w, L, M);
          }
          function Q(d, m, w, L, M) {
            M || (V(null != m, "missing value"), V("boolean" == typeof L, "missing or invalid endian"), V(null != w, "missing offset"), V(w + 3 < d.length, "Trying to write beyond buffer length"), ya(m, 2147483647, -2147483648)), d.length <= w || A(d, 0 <= m ? m : 4294967295 + m + 1, w, L, M);
          }
          function Z(d, m, w, L, M) {
            M || (V(null != m, "missing value"), V("boolean" == typeof L, "missing or invalid endian"), V(null != w, "missing offset"), V(w + 3 < d.length, "Trying to write beyond buffer length"), Fu(m, 34028234663852886e22, -34028234663852886e22)), d.length <= w || x.write(d, m, w, L, 23, 4);
          }
          function J(d, m, w, L, M) {
            M || (V(null != m, "missing value"), V("boolean" == typeof L, "missing or invalid endian"), V(null != w, "missing offset"), V(w + 7 < d.length, "Trying to write beyond buffer length"), Fu(m, 17976931348623157e292, -17976931348623157e292)), d.length <= w || x.write(d, m, w, L, 52, 8);
          }
          t.Buffer = f, t.SlowBuffer = f, t.INSPECT_MAX_BYTES = 50, f.poolSize = 8192, f._useTypedArrays = function() {
            try {
              var d = new ArrayBuffer(0), m = new Uint8Array(d);
              return m.foo = function() {
                return 42;
              }, 42 === m.foo() && "function" == typeof m.subarray;
            } catch (w) {
              return false;
            }
          }(), f.isEncoding = function(d) {
            switch (String(d).toLowerCase()) {
              case "hex":
              case "utf8":
              case "utf-8":
              case "ascii":
              case "binary":
              case "base64":
              case "raw":
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return true;
              default:
                return false;
            }
          }, f.isBuffer = function(d) {
            return !(null == d || !d._isBuffer);
          }, f.byteLength = function(d, m) {
            var w;
            switch (d += "", m || "utf8") {
              case "hex":
                w = d.length / 2;
                break;
              case "utf8":
              case "utf-8":
                w = gt(d).length;
                break;
              case "ascii":
              case "binary":
              case "raw":
                w = d.length;
                break;
              case "base64":
                w = Vu(d).length;
                break;
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                w = 2 * d.length;
                break;
              default:
                throw new Error("Unknown encoding");
            }
            return w;
          }, f.concat = function(d, m) {
            if (V(he(d), "Usage: Buffer.concat(list, [totalLength])\nlist should be an Array."), 0 === d.length)
              return new f(0);
            if (1 === d.length)
              return d[0];
            if ("number" != typeof m)
              for (M = m = 0; M < d.length; M++)
                m += d[M].length;
            for (var w = new f(m), L = 0, M = 0; M < d.length; M++) {
              var z = d[M];
              z.copy(w, L), L += z.length;
            }
            return w;
          }, f.prototype.write = function(d, m, w, L) {
            isFinite(m) ? isFinite(w) || (L = w, w = void 0) : (_e = L, L = m, m = w, w = _e), m = Number(m) || 0;
            var M, z, te, fe, _e = this.length - m;
            switch ((!w || _e < (w = Number(w))) && (w = _e), L = String(L || "utf8").toLowerCase()) {
              case "hex":
                M = function(et, Le, De, ve) {
                  De = Number(De) || 0;
                  var me = et.length - De;
                  (!ve || me < (ve = Number(ve))) && (ve = me), V((me = Le.length) % 2 == 0, "Invalid hex string"), me / 2 < ve && (ve = me / 2);
                  for (var Or = 0; Or < ve; Or++) {
                    var Ku = parseInt(Le.substr(2 * Or, 2), 16);
                    V(!isNaN(Ku), "Invalid hex string"), et[De + Or] = Ku;
                  }
                  return f._charsWritten = 2 * Or, Or;
                }(this, d, m, w);
                break;
              case "utf8":
              case "utf-8":
                z = this, te = m, fe = w, M = f._charsWritten = ni(gt(d), z, te, fe);
                break;
              case "ascii":
              case "binary":
                M = P(this, d, m, w);
                break;
              case "base64":
                z = this, te = m, fe = w, M = f._charsWritten = ni(Vu(d), z, te, fe);
                break;
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                M = S(this, d, m, w);
                break;
              default:
                throw new Error("Unknown encoding");
            }
            return M;
          }, f.prototype.toString = function(d, m, w) {
            var L, M, z, te, fe = this;
            if (d = String(d || "utf8").toLowerCase(), m = Number(m) || 0, (w = void 0 !== w ? Number(w) : fe.length) === m)
              return "";
            switch (d) {
              case "hex":
                L = function(_e, et, Le) {
                  var De = _e.length;
                  (!et || et < 0) && (et = 0);
                  (!Le || Le < 0 || De < Le) && (Le = De);
                  for (var ve = "", me = et; me < Le; me++)
                    ve += le(_e[me]);
                  return ve;
                }(fe, m, w);
                break;
              case "utf8":
              case "utf-8":
                L = function(_e, et, Le) {
                  var De = "", ve = "";
                  Le = Math.min(_e.length, Le);
                  for (var me = et; me < Le; me++)
                    _e[me] <= 127 ? (De += zu(ve) + String.fromCharCode(_e[me]), ve = "") : ve += "%" + _e[me].toString(16);
                  return De + zu(ve);
                }(fe, m, w);
                break;
              case "ascii":
              case "binary":
                L = k(fe, m, w);
                break;
              case "base64":
                M = fe, te = w, L = 0 === (z = m) && te === M.length ? _.fromByteArray(M) : _.fromByteArray(M.slice(z, te));
                break;
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                L = function(_e, et, Le) {
                  for (var De = _e.slice(et, Le), ve = "", me = 0; me < De.length; me += 2)
                    ve += String.fromCharCode(De[me] + 256 * De[me + 1]);
                  return ve;
                }(fe, m, w);
                break;
              default:
                throw new Error("Unknown encoding");
            }
            return L;
          }, f.prototype.toJSON = function() {
            return { type: "Buffer", data: Array.prototype.slice.call(this._arr || this, 0) };
          }, f.prototype.copy = function(d, m, w, L) {
            if (m = m || 0, (L = L || 0 === L ? L : this.length) !== (w = w || 0) && 0 !== d.length && 0 !== this.length) {
              V(w <= L, "sourceEnd < sourceStart"), V(0 <= m && m < d.length, "targetStart out of bounds"), V(0 <= w && w < this.length, "sourceStart out of bounds"), V(0 <= L && L <= this.length, "sourceEnd out of bounds"), L > this.length && (L = this.length);
              var M = (L = d.length - m < L - w ? d.length - m + w : L) - w;
              if (M < 100 || !f._useTypedArrays)
                for (var z = 0; z < M; z++)
                  d[z + m] = this[z + w];
              else
                d._set(this.subarray(w, w + M), m);
            }
          }, f.prototype.slice = function(d, m) {
            var w = this.length;
            if (d = de(d, w, 0), m = de(m, w, w), f._useTypedArrays)
              return f._augment(this.subarray(d, m));
            for (var L = m - d, M = new f(L, void 0, true), z = 0; z < L; z++)
              M[z] = this[z + d];
            return M;
          }, f.prototype.get = function(d) {
            return console.log(".get() is deprecated. Access using array indexes instead."), this.readUInt8(d);
          }, f.prototype.set = function(d, m) {
            return console.log(".set() is deprecated. Access using array indexes instead."), this.writeUInt8(d, m);
          }, f.prototype.readUInt8 = function(d, m) {
            if (m || (V(null != d, "missing offset"), V(d < this.length, "Trying to read beyond buffer length")), !(d >= this.length))
              return this[d];
          }, f.prototype.readUInt16LE = function(d, m) {
            return R(this, d, true, m);
          }, f.prototype.readUInt16BE = function(d, m) {
            return R(this, d, false, m);
          }, f.prototype.readUInt32LE = function(d, m) {
            return U(this, d, true, m);
          }, f.prototype.readUInt32BE = function(d, m) {
            return U(this, d, false, m);
          }, f.prototype.readInt8 = function(d, m) {
            if (m || (V(null != d, "missing offset"), V(d < this.length, "Trying to read beyond buffer length")), !(d >= this.length))
              return 128 & this[d] ? -1 * (255 - this[d] + 1) : this[d];
          }, f.prototype.readInt16LE = function(d, m) {
            return g(this, d, true, m);
          }, f.prototype.readInt16BE = function(d, m) {
            return g(this, d, false, m);
          }, f.prototype.readInt32LE = function(d, m) {
            return C(this, d, true, m);
          }, f.prototype.readInt32BE = function(d, m) {
            return C(this, d, false, m);
          }, f.prototype.readFloatLE = function(d, m) {
            return h(this, d, true, m);
          }, f.prototype.readFloatBE = function(d, m) {
            return h(this, d, false, m);
          }, f.prototype.readDoubleLE = function(d, m) {
            return y(this, d, true, m);
          }, f.prototype.readDoubleBE = function(d, m) {
            return y(this, d, false, m);
          }, f.prototype.writeUInt8 = function(d, m, w) {
            w || (V(null != d, "missing value"), V(null != m, "missing offset"), V(m < this.length, "trying to write beyond buffer length"), ma(d, 255)), m >= this.length || (this[m] = d);
          }, f.prototype.writeUInt16LE = function(d, m, w) {
            p(this, d, m, true, w);
          }, f.prototype.writeUInt16BE = function(d, m, w) {
            p(this, d, m, false, w);
          }, f.prototype.writeUInt32LE = function(d, m, w) {
            A(this, d, m, true, w);
          }, f.prototype.writeUInt32BE = function(d, m, w) {
            A(this, d, m, false, w);
          }, f.prototype.writeInt8 = function(d, m, w) {
            w || (V(null != d, "missing value"), V(null != m, "missing offset"), V(m < this.length, "Trying to write beyond buffer length"), ya(d, 127, -128)), m >= this.length || (0 <= d ? this.writeUInt8(d, m, w) : this.writeUInt8(255 + d + 1, m, w));
          }, f.prototype.writeInt16LE = function(d, m, w) {
            I(this, d, m, true, w);
          }, f.prototype.writeInt16BE = function(d, m, w) {
            I(this, d, m, false, w);
          }, f.prototype.writeInt32LE = function(d, m, w) {
            Q(this, d, m, true, w);
          }, f.prototype.writeInt32BE = function(d, m, w) {
            Q(this, d, m, false, w);
          }, f.prototype.writeFloatLE = function(d, m, w) {
            Z(this, d, m, true, w);
          }, f.prototype.writeFloatBE = function(d, m, w) {
            Z(this, d, m, false, w);
          }, f.prototype.writeDoubleLE = function(d, m, w) {
            J(this, d, m, true, w);
          }, f.prototype.writeDoubleBE = function(d, m, w) {
            J(this, d, m, false, w);
          }, f.prototype.fill = function(d, m, w) {
            if (m = m || 0, w = w || this.length, V("number" == typeof (d = "string" == typeof (d = d || 0) ? d.charCodeAt(0) : d) && !isNaN(d), "value is not a number"), V(m <= w, "end < start"), w !== m && 0 !== this.length) {
              V(0 <= m && m < this.length, "start out of bounds"), V(0 <= w && w <= this.length, "end out of bounds");
              for (var L = m; L < w; L++)
                this[L] = d;
            }
          }, f.prototype.inspect = function() {
            for (var d = [], m = this.length, w = 0; w < m; w++)
              if (d[w] = le(this[w]), w === t.INSPECT_MAX_BYTES) {
                d[w + 1] = "...";
                break;
              }
            return "<Buffer " + d.join(" ") + ">";
          }, f.prototype.toArrayBuffer = function() {
            if ("undefined" == typeof Uint8Array)
              throw new Error("Buffer.toArrayBuffer not supported in this browser");
            if (f._useTypedArrays)
              return new f(this).buffer;
            for (var d = new Uint8Array(this.length), m = 0, w = d.length; m < w; m += 1)
              d[m] = this[m];
            return d.buffer;
          };
          var F = f.prototype;
          function de(d, m, w) {
            return "number" != typeof d ? w : m <= (d = ~~d) ? m : 0 <= d || 0 <= (d += m) ? d : 0;
          }
          function Ae(d) {
            return (d = ~~Math.ceil(+d)) < 0 ? 0 : d;
          }
          function he(d) {
            return (Array.isArray || function(m) {
              return "[object Array]" === Object.prototype.toString.call(m);
            })(d);
          }
          function le(d) {
            return d < 16 ? "0" + d.toString(16) : d.toString(16);
          }
          function gt(d) {
            for (var m = [], w = 0; w < d.length; w++) {
              var L = d.charCodeAt(w);
              if (L <= 127)
                m.push(d.charCodeAt(w));
              else
                for (var M = w, z = (55296 <= L && L <= 57343 && w++, encodeURIComponent(d.slice(M, w + 1)).substr(1).split("%")), te = 0; te < z.length; te++)
                  m.push(parseInt(z[te], 16));
            }
            return m;
          }
          function Vu(d) {
            return _.toByteArray(d);
          }
          function ni(d, m, w, L) {
            for (var M = 0; M < L && !(M + w >= m.length || M >= d.length); M++)
              m[M + w] = d[M];
            return M;
          }
          function zu(d) {
            try {
              return decodeURIComponent(d);
            } catch (m) {
              return String.fromCharCode(65533);
            }
          }
          function ma(d, m) {
            V("number" == typeof d, "cannot write a non-number as a number"), V(0 <= d, "specified a negative value for writing an unsigned value"), V(d <= m, "value is larger than maximum value for type"), V(Math.floor(d) === d, "value has a fractional component");
          }
          function ya(d, m, w) {
            V("number" == typeof d, "cannot write a non-number as a number"), V(d <= m, "value larger than maximum allowed value"), V(w <= d, "value smaller than minimum allowed value"), V(Math.floor(d) === d, "value has a fractional component");
          }
          function Fu(d, m, w) {
            V("number" == typeof d, "cannot write a non-number as a number"), V(d <= m, "value larger than maximum allowed value"), V(w <= d, "value smaller than minimum allowed value");
          }
          function V(d, m) {
            if (!d)
              throw new Error(m || "Failed assertion");
          }
          f._augment = function(d) {
            return d._isBuffer = true, d._get = d.get, d._set = d.set, d.get = F.get, d.set = F.set, d.write = F.write, d.toString = F.toString, d.toLocaleString = F.toString, d.toJSON = F.toJSON, d.copy = F.copy, d.slice = F.slice, d.readUInt8 = F.readUInt8, d.readUInt16LE = F.readUInt16LE, d.readUInt16BE = F.readUInt16BE, d.readUInt32LE = F.readUInt32LE, d.readUInt32BE = F.readUInt32BE, d.readInt8 = F.readInt8, d.readInt16LE = F.readInt16LE, d.readInt16BE = F.readInt16BE, d.readInt32LE = F.readInt32LE, d.readInt32BE = F.readInt32BE, d.readFloatLE = F.readFloatLE, d.readFloatBE = F.readFloatBE, d.readDoubleLE = F.readDoubleLE, d.readDoubleBE = F.readDoubleBE, d.writeUInt8 = F.writeUInt8, d.writeUInt16LE = F.writeUInt16LE, d.writeUInt16BE = F.writeUInt16BE, d.writeUInt32LE = F.writeUInt32LE, d.writeUInt32BE = F.writeUInt32BE, d.writeInt8 = F.writeInt8, d.writeInt16LE = F.writeInt16LE, d.writeInt16BE = F.writeInt16BE, d.writeInt32LE = F.writeInt32LE, d.writeInt32BE = F.writeInt32BE, d.writeFloatLE = F.writeFloatLE, d.writeFloatBE = F.writeFloatBE, d.writeDoubleLE = F.writeDoubleLE, d.writeDoubleBE = F.writeDoubleBE, d.fill = F.fill, d.inspect = F.inspect, d.toArrayBuffer = F.toArrayBuffer, d;
          };
        }.call(this, r("lYpoI2"), "undefined" != typeof self ? self : "undefined" != typeof window ? window : {}, r("buffer").Buffer, arguments[3], arguments[4], arguments[5], arguments[6], "/node_modules/gulp-browserify/node_modules/buffer/index.js", "/node_modules/gulp-browserify/node_modules/buffer");
      }, { "base64-js": 2, buffer: 3, ieee754: 10, lYpoI2: 11 }], 4: [function(r, e, t) {
        !function(n, i, _, a, o, u, l, c, b) {
          var _ = r("buffer").Buffer, x = 4, f = new _(x);
          f.fill(0);
          e.exports = { hash: function(P, S, k, R) {
            for (var U = S(function(p, A) {
              p.length % x != 0 && (I = p.length + (x - p.length % x), p = _.concat([p, f], I));
              for (var I, Q = [], Z = A ? p.readInt32BE : p.readInt32LE, J = 0; J < p.length; J += x)
                Q.push(Z.call(p, J));
              return Q;
            }(P = _.isBuffer(P) ? P : new _(P), R), 8 * P.length), S = R, g = new _(k), C = S ? g.writeInt32BE : g.writeInt32LE, h = 0; h < U.length; h++)
              C.call(g, U[h], 4 * h, true);
            return g;
          } };
        }.call(this, r("lYpoI2"), "undefined" != typeof self ? self : "undefined" != typeof window ? window : {}, r("buffer").Buffer, arguments[3], arguments[4], arguments[5], arguments[6], "/node_modules/gulp-browserify/node_modules/crypto-browserify/helpers.js", "/node_modules/gulp-browserify/node_modules/crypto-browserify");
      }, { buffer: 3, lYpoI2: 11 }], 5: [function(r, e, t) {
        !function(n, i, _, a, o, u, l, c, b) {
          var _ = r("buffer").Buffer, x = r("./sha"), f = r("./sha256"), P = r("./rng"), S = { sha1: x, sha256: f, md5: r("./md5") }, k = 64, R = new _(k);
          function U(p, A) {
            var I = S[p = p || "sha1"], Q = [];
            return I || g("algorithm:", p, "is not yet supported"), { update: function(Z) {
              return _.isBuffer(Z) || (Z = new _(Z)), Q.push(Z), Z.length, this;
            }, digest: function(Z) {
              var J = _.concat(Q), J = A ? function(F, de, Ae) {
                _.isBuffer(de) || (de = new _(de)), _.isBuffer(Ae) || (Ae = new _(Ae)), de.length > k ? de = F(de) : de.length < k && (de = _.concat([de, R], k));
                for (var he = new _(k), le = new _(k), gt = 0; gt < k; gt++)
                  he[gt] = 54 ^ de[gt], le[gt] = 92 ^ de[gt];
                return Ae = F(_.concat([he, Ae])), F(_.concat([le, Ae]));
              }(I, A, J) : I(J);
              return Q = null, Z ? J.toString(Z) : J;
            } };
          }
          function g() {
            var p = [].slice.call(arguments).join(" ");
            throw new Error([p, "we accept pull requests", "http://github.com/dominictarr/crypto-browserify"].join("\n"));
          }
          R.fill(0), t.createHash = function(p) {
            return U(p);
          }, t.createHmac = U, t.randomBytes = function(p, A) {
            if (!A || !A.call)
              return new _(P(p));
            try {
              A.call(this, void 0, new _(P(p)));
            } catch (I) {
              A(I);
            }
          };
          var C, h = ["createCredentials", "createCipher", "createCipheriv", "createDecipher", "createDecipheriv", "createSign", "createVerify", "createDiffieHellman", "pbkdf2"], y = function(p) {
            t[p] = function() {
              g("sorry,", p, "is not implemented yet");
            };
          };
          for (C in h)
            y(h[C], C);
        }.call(this, r("lYpoI2"), "undefined" != typeof self ? self : "undefined" != typeof window ? window : {}, r("buffer").Buffer, arguments[3], arguments[4], arguments[5], arguments[6], "/node_modules/gulp-browserify/node_modules/crypto-browserify/index.js", "/node_modules/gulp-browserify/node_modules/crypto-browserify");
      }, { "./md5": 6, "./rng": 7, "./sha": 8, "./sha256": 9, buffer: 3, lYpoI2: 11 }], 6: [function(r, e, t) {
        !function(n, i, s, a, o, u, l, c, b) {
          var _ = r("./helpers");
          function x(g, C) {
            g[C >> 5] |= 128 << C % 32, g[14 + (C + 64 >>> 9 << 4)] = C;
            for (var h = 1732584193, y = -271733879, p = -1732584194, A = 271733878, I = 0; I < g.length; I += 16) {
              var Q = h, Z = y, J = p, F = A, h = P(h, y, p, A, g[I + 0], 7, -680876936), A = P(A, h, y, p, g[I + 1], 12, -389564586), p = P(p, A, h, y, g[I + 2], 17, 606105819), y = P(y, p, A, h, g[I + 3], 22, -1044525330);
              h = P(h, y, p, A, g[I + 4], 7, -176418897), A = P(A, h, y, p, g[I + 5], 12, 1200080426), p = P(p, A, h, y, g[I + 6], 17, -1473231341), y = P(y, p, A, h, g[I + 7], 22, -45705983), h = P(h, y, p, A, g[I + 8], 7, 1770035416), A = P(A, h, y, p, g[I + 9], 12, -1958414417), p = P(p, A, h, y, g[I + 10], 17, -42063), y = P(y, p, A, h, g[I + 11], 22, -1990404162), h = P(h, y, p, A, g[I + 12], 7, 1804603682), A = P(A, h, y, p, g[I + 13], 12, -40341101), p = P(p, A, h, y, g[I + 14], 17, -1502002290), h = S(h, y = P(y, p, A, h, g[I + 15], 22, 1236535329), p, A, g[I + 1], 5, -165796510), A = S(A, h, y, p, g[I + 6], 9, -1069501632), p = S(p, A, h, y, g[I + 11], 14, 643717713), y = S(y, p, A, h, g[I + 0], 20, -373897302), h = S(h, y, p, A, g[I + 5], 5, -701558691), A = S(A, h, y, p, g[I + 10], 9, 38016083), p = S(p, A, h, y, g[I + 15], 14, -660478335), y = S(y, p, A, h, g[I + 4], 20, -405537848), h = S(h, y, p, A, g[I + 9], 5, 568446438), A = S(A, h, y, p, g[I + 14], 9, -1019803690), p = S(p, A, h, y, g[I + 3], 14, -187363961), y = S(y, p, A, h, g[I + 8], 20, 1163531501), h = S(h, y, p, A, g[I + 13], 5, -1444681467), A = S(A, h, y, p, g[I + 2], 9, -51403784), p = S(p, A, h, y, g[I + 7], 14, 1735328473), h = k(h, y = S(y, p, A, h, g[I + 12], 20, -1926607734), p, A, g[I + 5], 4, -378558), A = k(A, h, y, p, g[I + 8], 11, -2022574463), p = k(p, A, h, y, g[I + 11], 16, 1839030562), y = k(y, p, A, h, g[I + 14], 23, -35309556), h = k(h, y, p, A, g[I + 1], 4, -1530992060), A = k(A, h, y, p, g[I + 4], 11, 1272893353), p = k(p, A, h, y, g[I + 7], 16, -155497632), y = k(y, p, A, h, g[I + 10], 23, -1094730640), h = k(h, y, p, A, g[I + 13], 4, 681279174), A = k(A, h, y, p, g[I + 0], 11, -358537222), p = k(p, A, h, y, g[I + 3], 16, -722521979), y = k(y, p, A, h, g[I + 6], 23, 76029189), h = k(h, y, p, A, g[I + 9], 4, -640364487), A = k(A, h, y, p, g[I + 12], 11, -421815835), p = k(p, A, h, y, g[I + 15], 16, 530742520), h = R(h, y = k(y, p, A, h, g[I + 2], 23, -995338651), p, A, g[I + 0], 6, -198630844), A = R(A, h, y, p, g[I + 7], 10, 1126891415), p = R(p, A, h, y, g[I + 14], 15, -1416354905), y = R(y, p, A, h, g[I + 5], 21, -57434055), h = R(h, y, p, A, g[I + 12], 6, 1700485571), A = R(A, h, y, p, g[I + 3], 10, -1894986606), p = R(p, A, h, y, g[I + 10], 15, -1051523), y = R(y, p, A, h, g[I + 1], 21, -2054922799), h = R(h, y, p, A, g[I + 8], 6, 1873313359), A = R(A, h, y, p, g[I + 15], 10, -30611744), p = R(p, A, h, y, g[I + 6], 15, -1560198380), y = R(y, p, A, h, g[I + 13], 21, 1309151649), h = R(h, y, p, A, g[I + 4], 6, -145523070), A = R(A, h, y, p, g[I + 11], 10, -1120210379), p = R(p, A, h, y, g[I + 2], 15, 718787259), y = R(y, p, A, h, g[I + 9], 21, -343485551), h = U(h, Q), y = U(y, Z), p = U(p, J), A = U(A, F);
            }
            return Array(h, y, p, A);
          }
          function f(g, C, h, y, p, A) {
            return U((C = U(U(C, g), U(y, A))) << p | C >>> 32 - p, h);
          }
          function P(g, C, h, y, p, A, I) {
            return f(C & h | ~C & y, g, C, p, A, I);
          }
          function S(g, C, h, y, p, A, I) {
            return f(C & y | h & ~y, g, C, p, A, I);
          }
          function k(g, C, h, y, p, A, I) {
            return f(C ^ h ^ y, g, C, p, A, I);
          }
          function R(g, C, h, y, p, A, I) {
            return f(h ^ (C | ~y), g, C, p, A, I);
          }
          function U(g, C) {
            var h = (65535 & g) + (65535 & C);
            return (g >> 16) + (C >> 16) + (h >> 16) << 16 | 65535 & h;
          }
          e.exports = function(g) {
            return _.hash(g, x, 16);
          };
        }.call(this, r("lYpoI2"), "undefined" != typeof self ? self : "undefined" != typeof window ? window : {}, r("buffer").Buffer, arguments[3], arguments[4], arguments[5], arguments[6], "/node_modules/gulp-browserify/node_modules/crypto-browserify/md5.js", "/node_modules/gulp-browserify/node_modules/crypto-browserify");
      }, { "./helpers": 4, buffer: 3, lYpoI2: 11 }], 7: [function(r, e, t) {
        !function(n, i, s, a, o, u, l, c, b) {
          var _;
          e.exports = _ || function(x) {
            for (var f, P = new Array(x), S = 0; S < x; S++)
              0 == (3 & S) && (f = 4294967296 * Math.random()), P[S] = f >>> ((3 & S) << 3) & 255;
            return P;
          };
        }.call(this, r("lYpoI2"), "undefined" != typeof self ? self : "undefined" != typeof window ? window : {}, r("buffer").Buffer, arguments[3], arguments[4], arguments[5], arguments[6], "/node_modules/gulp-browserify/node_modules/crypto-browserify/rng.js", "/node_modules/gulp-browserify/node_modules/crypto-browserify");
      }, { buffer: 3, lYpoI2: 11 }], 8: [function(r, e, t) {
        !function(n, i, s, a, o, u, l, c, b) {
          var _ = r("./helpers");
          function x(S, k) {
            S[k >> 5] |= 128 << 24 - k % 32, S[15 + (k + 64 >> 9 << 4)] = k;
            for (var R, U, g, C = Array(80), h = 1732584193, y = -271733879, p = -1732584194, A = 271733878, I = -1009589776, Q = 0; Q < S.length; Q += 16) {
              for (var Z = h, J = y, F = p, de = A, Ae = I, he = 0; he < 80; he++) {
                C[he] = he < 16 ? S[Q + he] : P(C[he - 3] ^ C[he - 8] ^ C[he - 14] ^ C[he - 16], 1);
                var le = f(f(P(h, 5), (le = y, U = p, g = A, (R = he) < 20 ? le & U | ~le & g : !(R < 40) && R < 60 ? le & U | le & g | U & g : le ^ U ^ g)), f(f(I, C[he]), (R = he) < 20 ? 1518500249 : R < 40 ? 1859775393 : R < 60 ? -1894007588 : -899497514)), I = A, A = p, p = P(y, 30), y = h, h = le;
              }
              h = f(h, Z), y = f(y, J), p = f(p, F), A = f(A, de), I = f(I, Ae);
            }
            return Array(h, y, p, A, I);
          }
          function f(S, k) {
            var R = (65535 & S) + (65535 & k);
            return (S >> 16) + (k >> 16) + (R >> 16) << 16 | 65535 & R;
          }
          function P(S, k) {
            return S << k | S >>> 32 - k;
          }
          e.exports = function(S) {
            return _.hash(S, x, 20, true);
          };
        }.call(this, r("lYpoI2"), "undefined" != typeof self ? self : "undefined" != typeof window ? window : {}, r("buffer").Buffer, arguments[3], arguments[4], arguments[5], arguments[6], "/node_modules/gulp-browserify/node_modules/crypto-browserify/sha.js", "/node_modules/gulp-browserify/node_modules/crypto-browserify");
      }, { "./helpers": 4, buffer: 3, lYpoI2: 11 }], 9: [function(r, e, t) {
        !function(n, i, s, a, o, u, l, c, b) {
          function _(k, R) {
            var U = (65535 & k) + (65535 & R);
            return (k >> 16) + (R >> 16) + (U >> 16) << 16 | 65535 & U;
          }
          function x(k, R) {
            var U, g = new Array(1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298), C = new Array(1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225), h = new Array(64);
            k[R >> 5] |= 128 << 24 - R % 32, k[15 + (R + 64 >> 9 << 4)] = R;
            for (var y, p, A = 0; A < k.length; A += 16) {
              for (var I = C[0], Q = C[1], Z = C[2], J = C[3], F = C[4], de = C[5], Ae = C[6], he = C[7], le = 0; le < 64; le++)
                h[le] = le < 16 ? k[le + A] : _(_(_((p = h[le - 2], P(p, 17) ^ P(p, 19) ^ S(p, 10)), h[le - 7]), (p = h[le - 15], P(p, 7) ^ P(p, 18) ^ S(p, 3))), h[le - 16]), U = _(_(_(_(he, P(p = F, 6) ^ P(p, 11) ^ P(p, 25)), F & de ^ ~F & Ae), g[le]), h[le]), y = _(P(y = I, 2) ^ P(y, 13) ^ P(y, 22), I & Q ^ I & Z ^ Q & Z), he = Ae, Ae = de, de = F, F = _(J, U), J = Z, Z = Q, Q = I, I = _(U, y);
              C[0] = _(I, C[0]), C[1] = _(Q, C[1]), C[2] = _(Z, C[2]), C[3] = _(J, C[3]), C[4] = _(F, C[4]), C[5] = _(de, C[5]), C[6] = _(Ae, C[6]), C[7] = _(he, C[7]);
            }
            return C;
          }
          var f = r("./helpers"), P = function(k, R) {
            return k >>> R | k << 32 - R;
          }, S = function(k, R) {
            return k >>> R;
          };
          e.exports = function(k) {
            return f.hash(k, x, 32, true);
          };
        }.call(this, r("lYpoI2"), "undefined" != typeof self ? self : "undefined" != typeof window ? window : {}, r("buffer").Buffer, arguments[3], arguments[4], arguments[5], arguments[6], "/node_modules/gulp-browserify/node_modules/crypto-browserify/sha256.js", "/node_modules/gulp-browserify/node_modules/crypto-browserify");
      }, { "./helpers": 4, buffer: 3, lYpoI2: 11 }], 10: [function(r, e, t) {
        !function(n, i, s, a, o, u, l, c, b) {
          t.read = function(_, x, f, P, A) {
            var k, R, U = 8 * A - P - 1, g = (1 << U) - 1, C = g >> 1, h = -7, y = f ? A - 1 : 0, p = f ? -1 : 1, A = _[x + y];
            for (y += p, k = A & (1 << -h) - 1, A >>= -h, h += U; 0 < h; k = 256 * k + _[x + y], y += p, h -= 8)
              ;
            for (R = k & (1 << -h) - 1, k >>= -h, h += P; 0 < h; R = 256 * R + _[x + y], y += p, h -= 8)
              ;
            if (0 === k)
              k = 1 - C;
            else {
              if (k === g)
                return R ? NaN : 1 / 0 * (A ? -1 : 1);
              R += Math.pow(2, P), k -= C;
            }
            return (A ? -1 : 1) * R * Math.pow(2, k - P);
          }, t.write = function(_, x, f, P, S, I) {
            var R, U, g = 8 * I - S - 1, C = (1 << g) - 1, h = C >> 1, y = 23 === S ? Math.pow(2, -24) - Math.pow(2, -77) : 0, p = P ? 0 : I - 1, A = P ? 1 : -1, I = x < 0 || 0 === x && 1 / x < 0 ? 1 : 0;
            for (x = Math.abs(x), isNaN(x) || x === 1 / 0 ? (U = isNaN(x) ? 1 : 0, R = C) : (R = Math.floor(Math.log(x) / Math.LN2), x * (P = Math.pow(2, -R)) < 1 && (R--, P *= 2), 2 <= (x += 1 <= R + h ? y / P : y * Math.pow(2, 1 - h)) * P && (R++, P /= 2), C <= R + h ? (U = 0, R = C) : 1 <= R + h ? (U = (x * P - 1) * Math.pow(2, S), R += h) : (U = x * Math.pow(2, h - 1) * Math.pow(2, S), R = 0)); 8 <= S; _[f + p] = 255 & U, p += A, U /= 256, S -= 8)
              ;
            for (R = R << S | U, g += S; 0 < g; _[f + p] = 255 & R, p += A, R /= 256, g -= 8)
              ;
            _[f + p - A] |= 128 * I;
          };
        }.call(this, r("lYpoI2"), "undefined" != typeof self ? self : "undefined" != typeof window ? window : {}, r("buffer").Buffer, arguments[3], arguments[4], arguments[5], arguments[6], "/node_modules/gulp-browserify/node_modules/ieee754/index.js", "/node_modules/gulp-browserify/node_modules/ieee754");
      }, { buffer: 3, lYpoI2: 11 }], 11: [function(r, e, t) {
        !function(n, i, s, a, o, u, l, c, b) {
          var _, x, f;
          function P() {
          }
          (n = e.exports = {}).nextTick = (x = "undefined" != typeof window && window.setImmediate, f = "undefined" != typeof window && window.postMessage && window.addEventListener, x ? function(S) {
            return window.setImmediate(S);
          } : f ? (_ = [], window.addEventListener("message", function(S) {
            var k = S.source;
            k !== window && null !== k || "process-tick" !== S.data || (S.stopPropagation(), 0 < _.length && _.shift()());
          }, true), function(S) {
            _.push(S), window.postMessage("process-tick", "*");
          }) : function(S) {
            setTimeout(S, 0);
          }), n.title = "browser", n.browser = true, n.env = {}, n.argv = [], n.on = P, n.addListener = P, n.once = P, n.off = P, n.removeListener = P, n.removeAllListeners = P, n.emit = P, n.binding = function(S) {
            throw new Error("process.binding is not supported");
          }, n.cwd = function() {
            return "/";
          }, n.chdir = function(S) {
            throw new Error("process.chdir is not supported");
          };
        }.call(this, r("lYpoI2"), "undefined" != typeof self ? self : "undefined" != typeof window ? window : {}, r("buffer").Buffer, arguments[3], arguments[4], arguments[5], arguments[6], "/node_modules/gulp-browserify/node_modules/process/browser.js", "/node_modules/gulp-browserify/node_modules/process");
      }, { buffer: 3, lYpoI2: 11 }] }, {}, [1])(1);
    });
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/cache/base.js
  var vd, Oo;
  var xd = j(() => {
    vd = be(_d(), 1);
    Oo = (...r) => (0, vd.default)(r.join("_"));
  });

  // node_modules/.pnpm/decamelize@5.0.1/node_modules/decamelize/index.js
  var Pd = N((H0, Od) => {
    "use strict";
    var Yy = (r, e) => {
      r = r.replace(
        /((?<![\p{Uppercase_Letter}\d])[\p{Uppercase_Letter}\d](?![\p{Uppercase_Letter}\d]))/gu,
        (t) => {
          return t.toLowerCase();
        }
      );
      return r.replace(
        /(\p{Uppercase_Letter}+)(\p{Uppercase_Letter}\p{Lowercase_Letter}+)/gu,
        (t, n, i) => {
          return n + e + i.toLowerCase();
        }
      );
    };
    Od.exports = (r, {
      separator: e = "_",
      preserveConsecutiveUppercase: t = false
    } = {}) => {
      if (!(typeof r === "string" && typeof e === "string")) {
        throw new TypeError(
          "The `text` and `separator` arguments should be of type `string`"
        );
      }
      if (r.length < 2) {
        return t ? r : r.toLowerCase();
      }
      const n = `$1${e}$2`;
      const i = r.replace(
        /([\p{Lowercase_Letter}\d])(\p{Uppercase_Letter})/gu,
        n
      );
      if (t) {
        return Yy(i, e);
      }
      return i.replace(
        /(\p{Uppercase_Letter})(\p{Uppercase_Letter}\p{Lowercase_Letter}+)/gu,
        n
      ).toLowerCase();
    };
  });

  // node_modules/.pnpm/camelcase@6.3.0/node_modules/camelcase/index.js
  var jd = N((Q0, Po) => {
    "use strict";
    var Wy = /[\p{Lu}]/u;
    var Gy = /[\p{Ll}]/u;
    var Ad = /^[\p{Lu}](?![\p{Lu}])/gu;
    var Id = /([\p{Alpha}\p{N}_]|$)/u;
    var Cd = /[_.\- ]+/;
    var Xy = new RegExp("^" + Cd.source);
    var Ed = new RegExp(Cd.source + Id.source, "gu");
    var Td = new RegExp("\\d+" + Id.source, "gu");
    var eb = (r, e, t) => {
      let n = false;
      let i = false;
      let s = false;
      for (let a = 0; a < r.length; a++) {
        const o = r[a];
        if (n && Wy.test(o)) {
          r = r.slice(0, a) + "-" + r.slice(a);
          n = false;
          s = i;
          i = true;
          a++;
        } else if (i && s && Gy.test(o)) {
          r = r.slice(0, a - 1) + "-" + r.slice(a - 1);
          s = i;
          i = false;
          n = true;
        } else {
          n = e(o) === o && t(o) !== o;
          s = i;
          i = t(o) === o && e(o) !== o;
        }
      }
      return r;
    };
    var tb = (r, e) => {
      Ad.lastIndex = 0;
      return r.replace(Ad, (t) => e(t));
    };
    var rb = (r, e) => {
      Ed.lastIndex = 0;
      Td.lastIndex = 0;
      return r.replace(Ed, (t, n) => e(n)).replace(Td, (t) => e(t));
    };
    var Sd = (r, e) => {
      if (!(typeof r === "string" || Array.isArray(r))) {
        throw new TypeError("Expected the input to be `string | string[]`");
      }
      e = {
        pascalCase: false,
        preserveConsecutiveUppercase: false,
        ...e
      };
      if (Array.isArray(r)) {
        r = r.map((s) => s.trim()).filter((s) => s.length).join("-");
      } else {
        r = r.trim();
      }
      if (r.length === 0) {
        return "";
      }
      const t = e.locale === false ? (s) => s.toLowerCase() : (s) => s.toLocaleLowerCase(e.locale);
      const n = e.locale === false ? (s) => s.toUpperCase() : (s) => s.toLocaleUpperCase(e.locale);
      if (r.length === 1) {
        return e.pascalCase ? n(r) : t(r);
      }
      const i = r !== t(r);
      if (i) {
        r = eb(r, t, n);
      }
      r = r.replace(Xy, "");
      if (e.preserveConsecutiveUppercase) {
        r = tb(r, t);
      } else {
        r = t(r);
      }
      if (e.pascalCase) {
        r = n(r.charAt(0)) + r.slice(1);
      }
      return rb(r, n);
    };
    Po.exports = Sd;
    Po.exports.default = Sd;
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/load/map_keys.js
  function Rd(r, e) {
    return e?.[r] || (0, kd.default)(r);
  }
  function Nd(r, e, t) {
    const n = {};
    for (const i in r) {
      if (Object.hasOwn(r, i)) {
        n[e(i, t)] = r[i];
      }
    }
    return n;
  }
  var kd, nb;
  var Md = j(() => {
    kd = be(Pd(), 1);
    nb = be(jd(), 1);
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/load/serializable.js
  function Ld(r) {
    return Array.isArray(r) ? [...r] : { ...r };
  }
  function ib(r, e) {
    const t = Ld(r);
    for (const [n, i] of Object.entries(e)) {
      const [s, ...a] = n.split(".").reverse();
      let o = t;
      for (const u of a.reverse()) {
        if (o[u] === void 0) {
          break;
        }
        o[u] = Ld(o[u]);
        o = o[u];
      }
      if (o[s] !== void 0) {
        o[s] = {
          lc: 1,
          type: "secret",
          id: [i]
        };
      }
    }
    return t;
  }
  var Te;
  var rr = j(() => {
    Md();
    Te = class {
      /**
       * A map of secrets, which will be omitted from serialization.
       * Keys are paths to the secret in constructor args, e.g. "foo.bar.baz".
       * Values are the secret ids, which will be used when deserializing.
       */
      get lc_secrets() {
        return void 0;
      }
      /**
       * A map of additional attributes to merge with constructor args.
       * Keys are the attribute names, e.g. "foo".
       * Values are the attribute values, which will be serialized.
       * These attributes need to be accepted by the constructor as arguments.
       */
      get lc_attributes() {
        return void 0;
      }
      /**
       * A map of aliases for constructor args.
       * Keys are the attribute names, e.g. "foo".
       * Values are the alias that will replace the key in serialization.
       * This is used to eg. make argument names match Python.
       */
      get lc_aliases() {
        return void 0;
      }
      constructor(e, ...t) {
        Object.defineProperty(this, "lc_serializable", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        Object.defineProperty(this, "lc_kwargs", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.lc_kwargs = e || {};
      }
      toJSON() {
        if (!this.lc_serializable) {
          return this.toJSONNotImplemented();
        }
        if (
          // eslint-disable-next-line no-instanceof/no-instanceof
          this.lc_kwargs instanceof Te || typeof this.lc_kwargs !== "object" || Array.isArray(this.lc_kwargs)
        ) {
          return this.toJSONNotImplemented();
        }
        const e = {};
        const t = {};
        const n = Object.keys(this.lc_kwargs).reduce((i, s) => {
          i[s] = s in this ? this[s] : this.lc_kwargs[s];
          return i;
        }, {});
        for (let i = Object.getPrototypeOf(this); i; i = Object.getPrototypeOf(i)) {
          Object.assign(e, Reflect.get(i, "lc_aliases", this));
          Object.assign(t, Reflect.get(i, "lc_secrets", this));
          Object.assign(n, Reflect.get(i, "lc_attributes", this));
        }
        return {
          lc: 1,
          type: "constructor",
          id: [...this.lc_namespace, this.constructor.name],
          kwargs: Nd(this.lc_secrets ? ib(n, t) : n, Rd, e)
        };
      }
      toJSONNotImplemented() {
        return {
          lc: 1,
          type: "not_implemented",
          id: [...this.lc_namespace, this.constructor.name]
        };
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/schema/index.js
  var qr, Mr, lt, Ot, Lr, Rn, Dr, Si, ji;
  var ct = j(() => {
    rr();
    qr = "__run";
    Mr = class {
      constructor(e, t) {
        Object.defineProperty(this, "text", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "name", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "additional_kwargs", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: {}
        });
        this.text = e;
        this.additional_kwargs = t || {};
      }
      toJSON() {
        return {
          type: this._getType(),
          data: {
            content: this.text,
            role: "role" in this ? this.role : void 0,
            name: this.name,
            additional_kwargs: this.additional_kwargs
          }
        };
      }
    };
    lt = class extends Mr {
      _getType() {
        return "human";
      }
    };
    Ot = class extends Mr {
      _getType() {
        return "ai";
      }
    };
    Lr = class extends Mr {
      _getType() {
        return "system";
      }
    };
    Rn = class extends Mr {
      constructor(e, t) {
        super(e);
        Object.defineProperty(this, "role", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.role = t;
      }
      _getType() {
        return "generic";
      }
    };
    Dr = class extends Te {
    };
    Si = class {
    };
    ji = class {
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/cache/index.js
  var sb, Ur;
  var Dd = j(() => {
    xd();
    ct();
    sb = /* @__PURE__ */ new Map();
    Ur = class extends ji {
      constructor(e) {
        super();
        Object.defineProperty(this, "cache", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.cache = e ?? /* @__PURE__ */ new Map();
      }
      lookup(e, t) {
        return Promise.resolve(this.cache.get(Oo(e, t)) ?? null);
      }
      async update(e, t, n) {
        this.cache.set(Oo(e, t), n);
      }
      static global() {
        return new Ur(sb);
      }
    };
  });

  // node_modules/.pnpm/retry@0.13.1/node_modules/retry/lib/retry_operation.js
  var Ud = N((nP, qd) => {
    function He(r, e) {
      if (typeof e === "boolean") {
        e = { forever: e };
      }
      this._originalTimeouts = JSON.parse(JSON.stringify(r));
      this._timeouts = r;
      this._options = e || {};
      this._maxRetryTime = e && e.maxRetryTime || Infinity;
      this._fn = null;
      this._errors = [];
      this._attempts = 1;
      this._operationTimeout = null;
      this._operationTimeoutCb = null;
      this._timeout = null;
      this._operationStart = null;
      this._timer = null;
      if (this._options.forever) {
        this._cachedTimeouts = this._timeouts.slice(0);
      }
    }
    qd.exports = He;
    He.prototype.reset = function() {
      this._attempts = 1;
      this._timeouts = this._originalTimeouts.slice(0);
    };
    He.prototype.stop = function() {
      if (this._timeout) {
        clearTimeout(this._timeout);
      }
      if (this._timer) {
        clearTimeout(this._timer);
      }
      this._timeouts = [];
      this._cachedTimeouts = null;
    };
    He.prototype.retry = function(r) {
      if (this._timeout) {
        clearTimeout(this._timeout);
      }
      if (!r) {
        return false;
      }
      var e = (/* @__PURE__ */ new Date()).getTime();
      if (r && e - this._operationStart >= this._maxRetryTime) {
        this._errors.push(r);
        this._errors.unshift(new Error("RetryOperation timeout occurred"));
        return false;
      }
      this._errors.push(r);
      var t = this._timeouts.shift();
      if (t === void 0) {
        if (this._cachedTimeouts) {
          this._errors.splice(0, this._errors.length - 1);
          t = this._cachedTimeouts.slice(-1);
        } else {
          return false;
        }
      }
      var n = this;
      this._timer = setTimeout(function() {
        n._attempts++;
        if (n._operationTimeoutCb) {
          n._timeout = setTimeout(function() {
            n._operationTimeoutCb(n._attempts);
          }, n._operationTimeout);
          if (n._options.unref) {
            n._timeout.unref();
          }
        }
        n._fn(n._attempts);
      }, t);
      if (this._options.unref) {
        this._timer.unref();
      }
      return true;
    };
    He.prototype.attempt = function(r, e) {
      this._fn = r;
      if (e) {
        if (e.timeout) {
          this._operationTimeout = e.timeout;
        }
        if (e.cb) {
          this._operationTimeoutCb = e.cb;
        }
      }
      var t = this;
      if (this._operationTimeoutCb) {
        this._timeout = setTimeout(function() {
          t._operationTimeoutCb();
        }, t._operationTimeout);
      }
      this._operationStart = (/* @__PURE__ */ new Date()).getTime();
      this._fn(this._attempts);
    };
    He.prototype.try = function(r) {
      console.log("Using RetryOperation.try() is deprecated");
      this.attempt(r);
    };
    He.prototype.start = function(r) {
      console.log("Using RetryOperation.start() is deprecated");
      this.attempt(r);
    };
    He.prototype.start = He.prototype.try;
    He.prototype.errors = function() {
      return this._errors;
    };
    He.prototype.attempts = function() {
      return this._attempts;
    };
    He.prototype.mainError = function() {
      if (this._errors.length === 0) {
        return null;
      }
      var r = {};
      var e = null;
      var t = 0;
      for (var n = 0; n < this._errors.length; n++) {
        var i = this._errors[n];
        var s = i.message;
        var a = (r[s] || 0) + 1;
        r[s] = a;
        if (a >= t) {
          e = i;
          t = a;
        }
      }
      return e;
    };
  });

  // node_modules/.pnpm/retry@0.13.1/node_modules/retry/lib/retry.js
  var Vd = N((nr) => {
    var ab = Ud();
    nr.operation = function(r) {
      var e = nr.timeouts(r);
      return new ab(e, {
        forever: r && (r.forever || r.retries === Infinity),
        unref: r && r.unref,
        maxRetryTime: r && r.maxRetryTime
      });
    };
    nr.timeouts = function(r) {
      if (r instanceof Array) {
        return [].concat(r);
      }
      var e = {
        retries: 10,
        factor: 2,
        minTimeout: 1 * 1e3,
        maxTimeout: Infinity,
        randomize: false
      };
      for (var t in r) {
        e[t] = r[t];
      }
      if (e.minTimeout > e.maxTimeout) {
        throw new Error("minTimeout is greater than maxTimeout");
      }
      var n = [];
      for (var i = 0; i < e.retries; i++) {
        n.push(this.createTimeout(i, e));
      }
      if (r && r.forever && !n.length) {
        n.push(this.createTimeout(i, e));
      }
      n.sort(function(s, a) {
        return s - a;
      });
      return n;
    };
    nr.createTimeout = function(r, e) {
      var t = e.randomize ? Math.random() + 1 : 1;
      var n = Math.round(t * Math.max(e.minTimeout, 1) * Math.pow(e.factor, r));
      n = Math.min(n, e.maxTimeout);
      return n;
    };
    nr.wrap = function(r, e, t) {
      if (e instanceof Array) {
        t = e;
        e = null;
      }
      if (!t) {
        t = [];
        for (var n in r) {
          if (typeof r[n] === "function") {
            t.push(n);
          }
        }
      }
      for (var i = 0; i < t.length; i++) {
        var s = t[i];
        var a = r[s];
        r[s] = function o(u) {
          var l = nr.operation(e);
          var c = Array.prototype.slice.call(arguments, 1);
          var b = c.pop();
          c.push(function(_) {
            if (l.retry(_)) {
              return;
            }
            if (_) {
              arguments[0] = l.mainError();
            }
            b.apply(this, arguments);
          });
          l.attempt(function() {
            u.apply(r, c);
          });
        }.bind(r, a);
        r[s].options = e;
      }
    };
  });

  // node_modules/.pnpm/retry@0.13.1/node_modules/retry/index.js
  var Fd = N((sP, zd) => {
    zd.exports = Vd();
  });

  // node_modules/.pnpm/p-retry@4.6.2/node_modules/p-retry/index.js
  var Ao = N((aP, Ri) => {
    "use strict";
    var ob = Fd();
    var ub = [
      "Failed to fetch",
      // Chrome
      "NetworkError when attempting to fetch resource.",
      // Firefox
      "The Internet connection appears to be offline.",
      // Safari
      "Network request failed"
      // `cross-fetch`
    ];
    var ki = class extends Error {
      constructor(e) {
        super();
        if (e instanceof Error) {
          this.originalError = e;
          ({ message: e } = e);
        } else {
          this.originalError = new Error(e);
          this.originalError.stack = this.stack;
        }
        this.name = "AbortError";
        this.message = e;
      }
    };
    var lb = (r, e, t) => {
      const n = t.retries - (e - 1);
      r.attemptNumber = e;
      r.retriesLeft = n;
      return r;
    };
    var cb = (r) => ub.includes(r);
    var Kd = (r, e) => new Promise((t, n) => {
      e = {
        onFailedAttempt: () => {
        },
        retries: 10,
        ...e
      };
      const i = ob.operation(e);
      i.attempt(async (s) => {
        try {
          t(await r(s));
        } catch (a) {
          if (!(a instanceof Error)) {
            n(new TypeError(`Non-error was thrown: "${a}". You should only throw errors.`));
            return;
          }
          if (a instanceof ki) {
            i.stop();
            n(a.originalError);
          } else if (a instanceof TypeError && !cb(a.message)) {
            i.stop();
            n(a);
          } else {
            lb(a, s, e);
            try {
              await e.onFailedAttempt(a);
            } catch (o) {
              n(o);
              return;
            }
            if (!i.retry(a)) {
              n(i.mainError());
            }
          }
        }
      });
    });
    Ri.exports = Kd;
    Ri.exports.default = Kd;
    Ri.exports.AbortError = ki;
  });

  // node_modules/.pnpm/eventemitter3@4.0.7/node_modules/eventemitter3/index.js
  var $d = N((oP, Eo) => {
    "use strict";
    var db = Object.prototype.hasOwnProperty;
    var ke = "~";
    function Nn() {
    }
    if (Object.create) {
      Nn.prototype = /* @__PURE__ */ Object.create(null);
      if (!new Nn().__proto__)
        ke = false;
    }
    function pb(r, e, t) {
      this.fn = r;
      this.context = e;
      this.once = t || false;
    }
    function Bd(r, e, t, n, i) {
      if (typeof t !== "function") {
        throw new TypeError("The listener must be a function");
      }
      var s = new pb(t, n || r, i), a = ke ? ke + e : e;
      if (!r._events[a])
        r._events[a] = s, r._eventsCount++;
      else if (!r._events[a].fn)
        r._events[a].push(s);
      else
        r._events[a] = [r._events[a], s];
      return r;
    }
    function Ni(r, e) {
      if (--r._eventsCount === 0)
        r._events = new Nn();
      else
        delete r._events[e];
    }
    function Ie() {
      this._events = new Nn();
      this._eventsCount = 0;
    }
    Ie.prototype.eventNames = function r() {
      var e = [], t, n;
      if (this._eventsCount === 0)
        return e;
      for (n in t = this._events) {
        if (db.call(t, n))
          e.push(ke ? n.slice(1) : n);
      }
      if (Object.getOwnPropertySymbols) {
        return e.concat(Object.getOwnPropertySymbols(t));
      }
      return e;
    };
    Ie.prototype.listeners = function r(e) {
      var t = ke ? ke + e : e, n = this._events[t];
      if (!n)
        return [];
      if (n.fn)
        return [n.fn];
      for (var i = 0, s = n.length, a = new Array(s); i < s; i++) {
        a[i] = n[i].fn;
      }
      return a;
    };
    Ie.prototype.listenerCount = function r(e) {
      var t = ke ? ke + e : e, n = this._events[t];
      if (!n)
        return 0;
      if (n.fn)
        return 1;
      return n.length;
    };
    Ie.prototype.emit = function r(e, t, n, i, s, a) {
      var o = ke ? ke + e : e;
      if (!this._events[o])
        return false;
      var u = this._events[o], l = arguments.length, c, b;
      if (u.fn) {
        if (u.once)
          this.removeListener(e, u.fn, void 0, true);
        switch (l) {
          case 1:
            return u.fn.call(u.context), true;
          case 2:
            return u.fn.call(u.context, t), true;
          case 3:
            return u.fn.call(u.context, t, n), true;
          case 4:
            return u.fn.call(u.context, t, n, i), true;
          case 5:
            return u.fn.call(u.context, t, n, i, s), true;
          case 6:
            return u.fn.call(u.context, t, n, i, s, a), true;
        }
        for (b = 1, c = new Array(l - 1); b < l; b++) {
          c[b - 1] = arguments[b];
        }
        u.fn.apply(u.context, c);
      } else {
        var _ = u.length, x;
        for (b = 0; b < _; b++) {
          if (u[b].once)
            this.removeListener(e, u[b].fn, void 0, true);
          switch (l) {
            case 1:
              u[b].fn.call(u[b].context);
              break;
            case 2:
              u[b].fn.call(u[b].context, t);
              break;
            case 3:
              u[b].fn.call(u[b].context, t, n);
              break;
            case 4:
              u[b].fn.call(u[b].context, t, n, i);
              break;
            default:
              if (!c)
                for (x = 1, c = new Array(l - 1); x < l; x++) {
                  c[x - 1] = arguments[x];
                }
              u[b].fn.apply(u[b].context, c);
          }
        }
      }
      return true;
    };
    Ie.prototype.on = function r(e, t, n) {
      return Bd(this, e, t, n, false);
    };
    Ie.prototype.once = function r(e, t, n) {
      return Bd(this, e, t, n, true);
    };
    Ie.prototype.removeListener = function r(e, t, n, i) {
      var s = ke ? ke + e : e;
      if (!this._events[s])
        return this;
      if (!t) {
        Ni(this, s);
        return this;
      }
      var a = this._events[s];
      if (a.fn) {
        if (a.fn === t && (!i || a.once) && (!n || a.context === n)) {
          Ni(this, s);
        }
      } else {
        for (var o = 0, u = [], l = a.length; o < l; o++) {
          if (a[o].fn !== t || i && !a[o].once || n && a[o].context !== n) {
            u.push(a[o]);
          }
        }
        if (u.length)
          this._events[s] = u.length === 1 ? u[0] : u;
        else
          Ni(this, s);
      }
      return this;
    };
    Ie.prototype.removeAllListeners = function r(e) {
      var t;
      if (e) {
        t = ke ? ke + e : e;
        if (this._events[t])
          Ni(this, t);
      } else {
        this._events = new Nn();
        this._eventsCount = 0;
      }
      return this;
    };
    Ie.prototype.off = Ie.prototype.removeListener;
    Ie.prototype.addListener = Ie.prototype.on;
    Ie.prefixed = ke;
    Ie.EventEmitter = Ie;
    if ("undefined" !== typeof Eo) {
      Eo.exports = Ie;
    }
  });

  // node_modules/.pnpm/p-finally@1.0.0/node_modules/p-finally/index.js
  var Hd = N((uP, Zd) => {
    "use strict";
    Zd.exports = (r, e) => {
      e = e || (() => {
      });
      return r.then(
        (t) => new Promise((n) => {
          n(e());
        }).then(() => t),
        (t) => new Promise((n) => {
          n(e());
        }).then(() => {
          throw t;
        })
      );
    };
  });

  // node_modules/.pnpm/p-timeout@3.2.0/node_modules/p-timeout/index.js
  var Jd = N((lP, Li) => {
    "use strict";
    var hb = Hd();
    var Mi = class extends Error {
      constructor(e) {
        super(e);
        this.name = "TimeoutError";
      }
    };
    var Qd = (r, e, t) => new Promise((n, i) => {
      if (typeof e !== "number" || e < 0) {
        throw new TypeError("Expected `milliseconds` to be a positive number");
      }
      if (e === Infinity) {
        n(r);
        return;
      }
      const s = setTimeout(() => {
        if (typeof t === "function") {
          try {
            n(t());
          } catch (u) {
            i(u);
          }
          return;
        }
        const a = typeof t === "string" ? t : `Promise timed out after ${e} milliseconds`;
        const o = t instanceof Error ? t : new Mi(a);
        if (typeof r.cancel === "function") {
          r.cancel();
        }
        i(o);
      }, e);
      hb(
        // eslint-disable-next-line promise/prefer-await-to-then
        r.then(n, i),
        () => {
          clearTimeout(s);
        }
      );
    });
    Li.exports = Qd;
    Li.exports.default = Qd;
    Li.exports.TimeoutError = Mi;
  });

  // node_modules/.pnpm/p-queue@6.6.2/node_modules/p-queue/dist/lower-bound.js
  var Yd = N((To) => {
    "use strict";
    Object.defineProperty(To, "__esModule", { value: true });
    function fb(r, e, t) {
      let n = 0;
      let i = r.length;
      while (i > 0) {
        const s = i / 2 | 0;
        let a = n + s;
        if (t(r[a], e) <= 0) {
          n = ++a;
          i -= s + 1;
        } else {
          i = s;
        }
      }
      return n;
    }
    To.default = fb;
  });

  // node_modules/.pnpm/p-queue@6.6.2/node_modules/p-queue/dist/priority-queue.js
  var Wd = N((Co) => {
    "use strict";
    Object.defineProperty(Co, "__esModule", { value: true });
    var mb = Yd();
    var Io = class {
      constructor() {
        this._queue = [];
      }
      enqueue(e, t) {
        t = Object.assign({ priority: 0 }, t);
        const n = {
          priority: t.priority,
          run: e
        };
        if (this.size && this._queue[this.size - 1].priority >= t.priority) {
          this._queue.push(n);
          return;
        }
        const i = mb.default(this._queue, n, (s, a) => a.priority - s.priority);
        this._queue.splice(i, 0, n);
      }
      dequeue() {
        const e = this._queue.shift();
        return e === null || e === void 0 ? void 0 : e.run;
      }
      filter(e) {
        return this._queue.filter((t) => t.priority === e.priority).map((t) => t.run);
      }
      get size() {
        return this._queue.length;
      }
    };
    Co.default = Io;
  });

  // node_modules/.pnpm/p-queue@6.6.2/node_modules/p-queue/dist/index.js
  var qi = N((jo) => {
    "use strict";
    Object.defineProperty(jo, "__esModule", { value: true });
    var yb = $d();
    var Gd = Jd();
    var bb = Wd();
    var Di = () => {
    };
    var gb = new Gd.TimeoutError();
    var So = class extends yb {
      constructor(e) {
        var t, n, i, s;
        super();
        this._intervalCount = 0;
        this._intervalEnd = 0;
        this._pendingCount = 0;
        this._resolveEmpty = Di;
        this._resolveIdle = Di;
        e = Object.assign({ carryoverConcurrencyCount: false, intervalCap: Infinity, interval: 0, concurrency: Infinity, autoStart: true, queueClass: bb.default }, e);
        if (!(typeof e.intervalCap === "number" && e.intervalCap >= 1)) {
          throw new TypeError(`Expected \`intervalCap\` to be a number from 1 and up, got \`${(n = (t = e.intervalCap) === null || t === void 0 ? void 0 : t.toString()) !== null && n !== void 0 ? n : ""}\` (${typeof e.intervalCap})`);
        }
        if (e.interval === void 0 || !(Number.isFinite(e.interval) && e.interval >= 0)) {
          throw new TypeError(`Expected \`interval\` to be a finite number >= 0, got \`${(s = (i = e.interval) === null || i === void 0 ? void 0 : i.toString()) !== null && s !== void 0 ? s : ""}\` (${typeof e.interval})`);
        }
        this._carryoverConcurrencyCount = e.carryoverConcurrencyCount;
        this._isIntervalIgnored = e.intervalCap === Infinity || e.interval === 0;
        this._intervalCap = e.intervalCap;
        this._interval = e.interval;
        this._queue = new e.queueClass();
        this._queueClass = e.queueClass;
        this.concurrency = e.concurrency;
        this._timeout = e.timeout;
        this._throwOnTimeout = e.throwOnTimeout === true;
        this._isPaused = e.autoStart === false;
      }
      get _doesIntervalAllowAnother() {
        return this._isIntervalIgnored || this._intervalCount < this._intervalCap;
      }
      get _doesConcurrentAllowAnother() {
        return this._pendingCount < this._concurrency;
      }
      _next() {
        this._pendingCount--;
        this._tryToStartAnother();
        this.emit("next");
      }
      _resolvePromises() {
        this._resolveEmpty();
        this._resolveEmpty = Di;
        if (this._pendingCount === 0) {
          this._resolveIdle();
          this._resolveIdle = Di;
          this.emit("idle");
        }
      }
      _onResumeInterval() {
        this._onInterval();
        this._initializeIntervalIfNeeded();
        this._timeoutId = void 0;
      }
      _isIntervalPaused() {
        const e = Date.now();
        if (this._intervalId === void 0) {
          const t = this._intervalEnd - e;
          if (t < 0) {
            this._intervalCount = this._carryoverConcurrencyCount ? this._pendingCount : 0;
          } else {
            if (this._timeoutId === void 0) {
              this._timeoutId = setTimeout(() => {
                this._onResumeInterval();
              }, t);
            }
            return true;
          }
        }
        return false;
      }
      _tryToStartAnother() {
        if (this._queue.size === 0) {
          if (this._intervalId) {
            clearInterval(this._intervalId);
          }
          this._intervalId = void 0;
          this._resolvePromises();
          return false;
        }
        if (!this._isPaused) {
          const e = !this._isIntervalPaused();
          if (this._doesIntervalAllowAnother && this._doesConcurrentAllowAnother) {
            const t = this._queue.dequeue();
            if (!t) {
              return false;
            }
            this.emit("active");
            t();
            if (e) {
              this._initializeIntervalIfNeeded();
            }
            return true;
          }
        }
        return false;
      }
      _initializeIntervalIfNeeded() {
        if (this._isIntervalIgnored || this._intervalId !== void 0) {
          return;
        }
        this._intervalId = setInterval(() => {
          this._onInterval();
        }, this._interval);
        this._intervalEnd = Date.now() + this._interval;
      }
      _onInterval() {
        if (this._intervalCount === 0 && this._pendingCount === 0 && this._intervalId) {
          clearInterval(this._intervalId);
          this._intervalId = void 0;
        }
        this._intervalCount = this._carryoverConcurrencyCount ? this._pendingCount : 0;
        this._processQueue();
      }
      /**
      Executes all queued functions until it reaches the limit.
      */
      _processQueue() {
        while (this._tryToStartAnother()) {
        }
      }
      get concurrency() {
        return this._concurrency;
      }
      set concurrency(e) {
        if (!(typeof e === "number" && e >= 1)) {
          throw new TypeError(`Expected \`concurrency\` to be a number from 1 and up, got \`${e}\` (${typeof e})`);
        }
        this._concurrency = e;
        this._processQueue();
      }
      /**
      Adds a sync or async task to the queue. Always returns a promise.
      */
      async add(e, t = {}) {
        return new Promise((n, i) => {
          const s = async () => {
            this._pendingCount++;
            this._intervalCount++;
            try {
              const a = this._timeout === void 0 && t.timeout === void 0 ? e() : Gd.default(Promise.resolve(e()), t.timeout === void 0 ? this._timeout : t.timeout, () => {
                if (t.throwOnTimeout === void 0 ? this._throwOnTimeout : t.throwOnTimeout) {
                  i(gb);
                }
                return void 0;
              });
              n(await a);
            } catch (a) {
              i(a);
            }
            this._next();
          };
          this._queue.enqueue(s, t);
          this._tryToStartAnother();
          this.emit("add");
        });
      }
      /**
          Same as `.add()`, but accepts an array of sync or async functions.
      
          @returns A promise that resolves when all functions are resolved.
          */
      async addAll(e, t) {
        return Promise.all(e.map(async (n) => this.add(n, t)));
      }
      /**
      Start (or resume) executing enqueued tasks within concurrency limit. No need to call this if queue is not paused (via `options.autoStart = false` or by `.pause()` method.)
      */
      start() {
        if (!this._isPaused) {
          return this;
        }
        this._isPaused = false;
        this._processQueue();
        return this;
      }
      /**
      Put queue execution on hold.
      */
      pause() {
        this._isPaused = true;
      }
      /**
      Clear the queue.
      */
      clear() {
        this._queue = new this._queueClass();
      }
      /**
          Can be called multiple times. Useful if you for example add additional items at a later time.
      
          @returns A promise that settles when the queue becomes empty.
          */
      async onEmpty() {
        if (this._queue.size === 0) {
          return;
        }
        return new Promise((e) => {
          const t = this._resolveEmpty;
          this._resolveEmpty = () => {
            t();
            e();
          };
        });
      }
      /**
          The difference with `.onEmpty` is that `.onIdle` guarantees that all work from the queue has finished. `.onEmpty` merely signals that the queue is empty, but it could mean that some promises haven't completed yet.
      
          @returns A promise that settles when the queue becomes empty, and all promises have completed; `queue.size === 0 && queue.pending === 0`.
          */
      async onIdle() {
        if (this._pendingCount === 0 && this._queue.size === 0) {
          return;
        }
        return new Promise((e) => {
          const t = this._resolveIdle;
          this._resolveIdle = () => {
            t();
            e();
          };
        });
      }
      /**
      Size of the queue.
      */
      get size() {
        return this._queue.size;
      }
      /**
          Size of the queue, filtered by the given options.
      
          For example, this can be used to find the number of items remaining in the queue with a specific priority level.
          */
      sizeBy(e) {
        return this._queue.filter(e).length;
      }
      /**
      Number of pending promises.
      */
      get pending() {
        return this._pendingCount;
      }
      /**
      Whether the queue is currently paused.
      */
      get isPaused() {
        return this._isPaused;
      }
      get timeout() {
        return this._timeout;
      }
      /**
      Set the timeout for future operations.
      */
      set timeout(e) {
        this._timeout = e;
      }
    };
    jo.default = So;
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/util/async_caller.js
  var Xd, Ui, wb, Pt;
  var Mn = j(() => {
    Xd = be(Ao(), 1);
    Ui = be(qi(), 1);
    wb = [
      400,
      401,
      403,
      404,
      405,
      406,
      407,
      408,
      409
      // Conflict
    ];
    Pt = class {
      constructor(e) {
        Object.defineProperty(this, "maxConcurrency", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "maxRetries", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "queue", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.maxConcurrency = e.maxConcurrency ?? Infinity;
        this.maxRetries = e.maxRetries ?? 6;
        const t = "default" in Ui.default ? Ui.default.default : Ui.default;
        this.queue = new t({ concurrency: this.maxConcurrency });
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      call(e, ...t) {
        return this.queue.add(() => (0, Xd.default)(() => e(...t).catch((n) => {
          if (n instanceof Error) {
            throw n;
          } else {
            throw new Error(n);
          }
        }), {
          onFailedAttempt(n) {
            if (n.message.startsWith("Cancel") || n.message.startsWith("TimeoutError") || n.message.startsWith("AbortError")) {
              throw n;
            }
            if (n?.code === "ECONNABORTED") {
              throw n;
            }
            const i = n?.response?.status;
            if (i && wb.includes(+i)) {
              throw n;
            }
          },
          retries: this.maxRetries,
          randomize: true
          // If needed we can change some of the defaults here,
          // but they're quite sensible.
        }), { throwOnTimeout: true });
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      callWithOptions(e, t, ...n) {
        if (e.signal) {
          return Promise.race([
            this.call(t, ...n),
            new Promise((i, s) => {
              e.signal?.addEventListener("abort", () => {
                s(new Error("AbortError"));
              });
            })
          ]);
        }
        return this.call(t, ...n);
      }
      fetch(...e) {
        return this.call(() => fetch(...e).then((t) => t.ok ? t : Promise.reject(t)));
      }
    };
  });

  // node_modules/.pnpm/js-tiktoken@1.0.6/node_modules/js-tiktoken/dist/chunk-XXPGZHWZ.js
  var _b, vb, ep;
  var ko = j(() => {
    _b = Object.defineProperty;
    vb = (r, e, t) => e in r ? _b(r, e, { enumerable: true, configurable: true, writable: true, value: t }) : r[e] = t;
    ep = (r, e, t) => {
      vb(r, typeof e !== "symbol" ? e + "" : e, t);
      return t;
    };
  });

  // node_modules/.pnpm/base64-js@1.5.1/node_modules/base64-js/index.js
  var np = N((Vi) => {
    "use strict";
    Vi.byteLength = Ob;
    Vi.toByteArray = Ab;
    Vi.fromByteArray = Ib;
    var dt = [];
    var Qe = [];
    var xb = typeof Uint8Array !== "undefined" ? Uint8Array : Array;
    var Ro = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (ir = 0, tp = Ro.length; ir < tp; ++ir) {
      dt[ir] = Ro[ir];
      Qe[Ro.charCodeAt(ir)] = ir;
    }
    var ir;
    var tp;
    Qe["-".charCodeAt(0)] = 62;
    Qe["_".charCodeAt(0)] = 63;
    function rp(r) {
      var e = r.length;
      if (e % 4 > 0) {
        throw new Error("Invalid string. Length must be a multiple of 4");
      }
      var t = r.indexOf("=");
      if (t === -1)
        t = e;
      var n = t === e ? 0 : 4 - t % 4;
      return [t, n];
    }
    function Ob(r) {
      var e = rp(r);
      var t = e[0];
      var n = e[1];
      return (t + n) * 3 / 4 - n;
    }
    function Pb(r, e, t) {
      return (e + t) * 3 / 4 - t;
    }
    function Ab(r) {
      var e;
      var t = rp(r);
      var n = t[0];
      var i = t[1];
      var s = new xb(Pb(r, n, i));
      var a = 0;
      var o = i > 0 ? n - 4 : n;
      var u;
      for (u = 0; u < o; u += 4) {
        e = Qe[r.charCodeAt(u)] << 18 | Qe[r.charCodeAt(u + 1)] << 12 | Qe[r.charCodeAt(u + 2)] << 6 | Qe[r.charCodeAt(u + 3)];
        s[a++] = e >> 16 & 255;
        s[a++] = e >> 8 & 255;
        s[a++] = e & 255;
      }
      if (i === 2) {
        e = Qe[r.charCodeAt(u)] << 2 | Qe[r.charCodeAt(u + 1)] >> 4;
        s[a++] = e & 255;
      }
      if (i === 1) {
        e = Qe[r.charCodeAt(u)] << 10 | Qe[r.charCodeAt(u + 1)] << 4 | Qe[r.charCodeAt(u + 2)] >> 2;
        s[a++] = e >> 8 & 255;
        s[a++] = e & 255;
      }
      return s;
    }
    function Eb(r) {
      return dt[r >> 18 & 63] + dt[r >> 12 & 63] + dt[r >> 6 & 63] + dt[r & 63];
    }
    function Tb(r, e, t) {
      var n;
      var i = [];
      for (var s = e; s < t; s += 3) {
        n = (r[s] << 16 & 16711680) + (r[s + 1] << 8 & 65280) + (r[s + 2] & 255);
        i.push(Eb(n));
      }
      return i.join("");
    }
    function Ib(r) {
      var e;
      var t = r.length;
      var n = t % 3;
      var i = [];
      var s = 16383;
      for (var a = 0, o = t - n; a < o; a += s) {
        i.push(Tb(r, a, a + s > o ? o : a + s));
      }
      if (n === 1) {
        e = r[t - 1];
        i.push(
          dt[e >> 2] + dt[e << 4 & 63] + "=="
        );
      } else if (n === 2) {
        e = (r[t - 2] << 8) + r[t - 1];
        i.push(
          dt[e >> 10] + dt[e >> 4 & 63] + dt[e << 2 & 63] + "="
        );
      }
      return i.join("");
    }
  });

  // node_modules/.pnpm/js-tiktoken@1.0.6/node_modules/js-tiktoken/dist/chunk-HORODD5P.js
  function Cb(r, e) {
    let t = Array.from(
      { length: r.length },
      (n, i) => ({ start: i, end: i + 1 })
    );
    while (t.length > 1) {
      let n = null;
      for (let i = 0; i < t.length - 1; i++) {
        const s = r.slice(t[i].start, t[i + 1].end);
        const a = e.get(s.join(","));
        if (a == null)
          continue;
        if (n == null || a < n[0]) {
          n = [a, i];
        }
      }
      if (n != null) {
        const i = n[1];
        t[i] = { start: t[i].start, end: t[i + 1].end };
        t.splice(i + 1, 1);
      } else {
        break;
      }
    }
    return t;
  }
  function Sb(r, e) {
    if (r.length === 1)
      return [e.get(r.join(","))];
    return Cb(r, e).map((t) => e.get(r.slice(t.start, t.end).join(","))).filter((t) => t != null);
  }
  function jb(r) {
    return r.replace(/[\\^$*+?.()|[\]{}]/g, "\\$&");
  }
  function Mo(r) {
    switch (r) {
      case "gpt2": {
        return "gpt2";
      }
      case "code-cushman-001":
      case "code-cushman-002":
      case "code-davinci-001":
      case "code-davinci-002":
      case "cushman-codex":
      case "davinci-codex":
      case "text-davinci-002":
      case "text-davinci-003": {
        return "p50k_base";
      }
      case "code-davinci-edit-001":
      case "text-davinci-edit-001": {
        return "p50k_edit";
      }
      case "ada":
      case "babbage":
      case "code-search-ada-code-001":
      case "code-search-babbage-code-001":
      case "curie":
      case "davinci":
      case "text-ada-001":
      case "text-babbage-001":
      case "text-curie-001":
      case "text-davinci-001":
      case "text-search-ada-doc-001":
      case "text-search-babbage-doc-001":
      case "text-search-curie-doc-001":
      case "text-search-davinci-doc-001":
      case "text-similarity-ada-001":
      case "text-similarity-babbage-001":
      case "text-similarity-curie-001":
      case "text-similarity-davinci-001": {
        return "r50k_base";
      }
      case "gpt-3.5-turbo-0301":
      case "gpt-3.5-turbo":
      case "gpt-4-0314":
      case "gpt-4-32k-0314":
      case "gpt-4-32k":
      case "gpt-4":
      case "text-embedding-ada-002": {
        return "cl100k_base";
      }
      default:
        throw new Error("Unknown model");
    }
  }
  var ip, No, zi;
  var sp = j(() => {
    ko();
    ip = be(np(), 1);
    No = class {
      /** @internal */
      specialTokens;
      /** @internal */
      inverseSpecialTokens;
      /** @internal */
      patStr;
      /** @internal */
      textEncoder = new TextEncoder();
      /** @internal */
      textDecoder = new TextDecoder("utf-8");
      /** @internal */
      rankMap = /* @__PURE__ */ new Map();
      /** @internal */
      textMap = /* @__PURE__ */ new Map();
      constructor(r, e) {
        this.patStr = r.pat_str;
        const t = r.bpe_ranks.split("\n").filter(Boolean).reduce((n, i) => {
          const [s, a, ...o] = i.split(" ");
          const u = Number.parseInt(a, 10);
          o.forEach((l, c) => n[l] = u + c);
          return n;
        }, {});
        for (const [n, i] of Object.entries(t)) {
          const s = ip.default.toByteArray(n);
          this.rankMap.set(s.join(","), i);
          this.textMap.set(i, s);
        }
        this.specialTokens = { ...r.special_tokens, ...e };
        this.inverseSpecialTokens = Object.entries(this.specialTokens).reduce((n, [i, s]) => {
          n[s] = this.textEncoder.encode(i);
          return n;
        }, {});
      }
      encode(r, e = [], t = "all") {
        const n = new RegExp(this.patStr, "ug");
        const i = No.specialTokenRegex(
          Object.keys(this.specialTokens)
        );
        const s = [];
        const a = new Set(
          e === "all" ? Object.keys(this.specialTokens) : e
        );
        const o = new Set(
          t === "all" ? Object.keys(this.specialTokens).filter(
            (l) => !a.has(l)
          ) : t
        );
        if (o.size > 0) {
          const l = No.specialTokenRegex([
            ...o
          ]);
          const c = r.match(l);
          if (c != null) {
            throw new Error(
              `The text contains a special token that is not allowed: ${c[0]}`
            );
          }
        }
        let u = 0;
        while (true) {
          let l = null;
          let c = u;
          while (true) {
            i.lastIndex = c;
            l = i.exec(r);
            if (l == null || a.has(l[0]))
              break;
            c = l.index + 1;
          }
          const b = l?.index ?? r.length;
          for (const x of r.substring(u, b).matchAll(n)) {
            const f = this.textEncoder.encode(x[0]);
            const P = this.rankMap.get(f.join(","));
            if (P != null) {
              s.push(P);
              continue;
            }
            s.push(...Sb(f, this.rankMap));
          }
          if (l == null)
            break;
          let _ = this.specialTokens[l[0]];
          s.push(_);
          u = l.index + l[0].length;
        }
        return s;
      }
      decode(r) {
        const e = [];
        let t = 0;
        for (let s = 0; s < r.length; ++s) {
          const a = r[s];
          const o = this.textMap.get(a) ?? this.inverseSpecialTokens[a];
          if (o != null) {
            e.push(o);
            t += o.length;
          }
        }
        const n = new Uint8Array(t);
        let i = 0;
        for (const s of e) {
          n.set(s, i);
          i += s.length;
        }
        return this.textDecoder.decode(n);
      }
    };
    zi = No;
    ep(zi, "specialTokenRegex", (r) => {
      return new RegExp(r.map((e) => jb(e)).join("|"), "g");
    });
  });

  // node_modules/.pnpm/js-tiktoken@1.0.6/node_modules/js-tiktoken/dist/lite.js
  var ap = j(() => {
    sp();
    ko();
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/util/tiktoken.js
  async function Lo(r, e) {
    if (!(r in Fi)) {
      Fi[r] = kb.fetch(`https://tiktoken.pages.dev/js/${r}.json`, {
        signal: e?.signal
      }).then((t) => t.json()).catch((t) => {
        delete Fi[r];
        throw t;
      });
    }
    return new zi(await Fi[r], e?.extendedSpecialTokens);
  }
  async function Ki(r, e) {
    return Lo(Mo(r), e);
  }
  var Fi, kb;
  var Bi = j(() => {
    ap();
    Mn();
    Fi = {};
    kb = /* @__PURE__ */ new Pt({});
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/base_language/count_tokens.js
  var Vr, op, $i;
  var zr = j(() => {
    Bi();
    Vr = (r) => {
      if (r.startsWith("gpt-3.5-turbo-")) {
        return "gpt-3.5-turbo";
      }
      if (r.startsWith("gpt-4-32k-")) {
        return "gpt-4-32k";
      }
      if (r.startsWith("gpt-4-")) {
        return "gpt-4";
      }
      return r;
    };
    op = (r) => {
      switch (Vr(r)) {
        case "gpt-3.5-turbo":
          return 4096;
        case "gpt-4-32k":
          return 32768;
        case "gpt-4":
          return 8192;
        case "text-davinci-003":
          return 4097;
        case "text-curie-001":
          return 2048;
        case "text-babbage-001":
          return 2048;
        case "text-ada-001":
          return 2048;
        case "code-davinci-002":
          return 8e3;
        case "code-cushman-001":
          return 2048;
        default:
          return 4097;
      }
    };
    $i = async ({ prompt: r, modelName: e }) => {
      let t = Math.ceil(r.length / 4);
      try {
        t = (await Ki(e)).encode(r).length;
      } catch (i) {
        console.warn("Failed to calculate number of tokens, falling back to approximate count");
      }
      const n = op(e);
      return n - t;
    };
  });

  // node_modules/.pnpm/uuid@9.0.0/node_modules/uuid/dist/esm-browser/rng.js
  function Do() {
    if (!Zi) {
      Zi = typeof crypto !== "undefined" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto);
      if (!Zi) {
        throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
      }
    }
    return Zi(Rb);
  }
  var Zi, Rb;
  var up = j(() => {
    Rb = new Uint8Array(16);
  });

  // node_modules/.pnpm/uuid@9.0.0/node_modules/uuid/dist/esm-browser/stringify.js
  function lp(r, e = 0) {
    return (Pe[r[e + 0]] + Pe[r[e + 1]] + Pe[r[e + 2]] + Pe[r[e + 3]] + "-" + Pe[r[e + 4]] + Pe[r[e + 5]] + "-" + Pe[r[e + 6]] + Pe[r[e + 7]] + "-" + Pe[r[e + 8]] + Pe[r[e + 9]] + "-" + Pe[r[e + 10]] + Pe[r[e + 11]] + Pe[r[e + 12]] + Pe[r[e + 13]] + Pe[r[e + 14]] + Pe[r[e + 15]]).toLowerCase();
  }
  var Pe;
  var cp = j(() => {
    Pe = [];
    for (let r = 0; r < 256; ++r) {
      Pe.push((r + 256).toString(16).slice(1));
    }
  });

  // node_modules/.pnpm/uuid@9.0.0/node_modules/uuid/dist/esm-browser/native.js
  var Nb, qo;
  var dp = j(() => {
    Nb = typeof crypto !== "undefined" && crypto.randomUUID && crypto.randomUUID.bind(crypto);
    qo = {
      randomUUID: Nb
    };
  });

  // node_modules/.pnpm/uuid@9.0.0/node_modules/uuid/dist/esm-browser/v4.js
  function Mb(r, e, t) {
    if (qo.randomUUID && !e && !r) {
      return qo.randomUUID();
    }
    r = r || {};
    const n = r.random || (r.rng || Do)();
    n[6] = n[6] & 15 | 64;
    n[8] = n[8] & 63 | 128;
    if (e) {
      t = t || 0;
      for (let i = 0; i < 16; ++i) {
        e[t + i] = n[i];
      }
      return e;
    }
    return lp(n);
  }
  var nt;
  var pp = j(() => {
    dp();
    up();
    cp();
    nt = Mb;
  });

  // node_modules/.pnpm/uuid@9.0.0/node_modules/uuid/dist/esm-browser/index.js
  var Hi = j(() => {
    pp();
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/callbacks/base.js
  var Uo, At;
  var Vo = j(() => {
    Hi();
    rr();
    Uo = class {
    };
    At = class extends Uo {
      get lc_namespace() {
        return ["langchain", "callbacks", this.name];
      }
      get lc_secrets() {
        return void 0;
      }
      get lc_attributes() {
        return void 0;
      }
      get lc_aliases() {
        return void 0;
      }
      constructor(e) {
        super();
        Object.defineProperty(this, "lc_serializable", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        Object.defineProperty(this, "lc_kwargs", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "ignoreLLM", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        Object.defineProperty(this, "ignoreChain", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        Object.defineProperty(this, "ignoreAgent", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        Object.defineProperty(this, "awaitHandlers", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: typeof process !== "undefined" ? (
            // eslint-disable-next-line no-process-env
            process.env?.LANGCHAIN_CALLBACKS_BACKGROUND !== "true"
          ) : true
        });
        this.lc_kwargs = e || {};
        if (e) {
          this.ignoreLLM = e.ignoreLLM ?? this.ignoreLLM;
          this.ignoreChain = e.ignoreChain ?? this.ignoreChain;
          this.ignoreAgent = e.ignoreAgent ?? this.ignoreAgent;
        }
      }
      copy() {
        return new this.constructor(this);
      }
      toJSON() {
        return Te.prototype.toJSON.call(this);
      }
      toJSONNotImplemented() {
        return Te.prototype.toJSONNotImplemented.call(this);
      }
      static fromMethods(e) {
        class t extends At {
          constructor() {
            super();
            Object.defineProperty(this, "name", {
              enumerable: true,
              configurable: true,
              writable: true,
              value: nt()
            });
            Object.assign(this, e);
          }
        }
        return new t();
      }
    };
  });

  // node_modules/.pnpm/ansi-styles@5.2.0/node_modules/ansi-styles/index.js
  var gp = N((DP, bp) => {
    "use strict";
    var fp = 10;
    var mp = (r = 0) => (e) => `\x1B[${38 + r};5;${e}m`;
    var yp = (r = 0) => (e, t, n) => `\x1B[${38 + r};2;${e};${t};${n}m`;
    function Lb() {
      const r = /* @__PURE__ */ new Map();
      const e = {
        modifier: {
          reset: [0, 0],
          // 21 isn't widely supported and 22 does the same thing
          bold: [1, 22],
          dim: [2, 22],
          italic: [3, 23],
          underline: [4, 24],
          overline: [53, 55],
          inverse: [7, 27],
          hidden: [8, 28],
          strikethrough: [9, 29]
        },
        color: {
          black: [30, 39],
          red: [31, 39],
          green: [32, 39],
          yellow: [33, 39],
          blue: [34, 39],
          magenta: [35, 39],
          cyan: [36, 39],
          white: [37, 39],
          // Bright color
          blackBright: [90, 39],
          redBright: [91, 39],
          greenBright: [92, 39],
          yellowBright: [93, 39],
          blueBright: [94, 39],
          magentaBright: [95, 39],
          cyanBright: [96, 39],
          whiteBright: [97, 39]
        },
        bgColor: {
          bgBlack: [40, 49],
          bgRed: [41, 49],
          bgGreen: [42, 49],
          bgYellow: [43, 49],
          bgBlue: [44, 49],
          bgMagenta: [45, 49],
          bgCyan: [46, 49],
          bgWhite: [47, 49],
          // Bright color
          bgBlackBright: [100, 49],
          bgRedBright: [101, 49],
          bgGreenBright: [102, 49],
          bgYellowBright: [103, 49],
          bgBlueBright: [104, 49],
          bgMagentaBright: [105, 49],
          bgCyanBright: [106, 49],
          bgWhiteBright: [107, 49]
        }
      };
      e.color.gray = e.color.blackBright;
      e.bgColor.bgGray = e.bgColor.bgBlackBright;
      e.color.grey = e.color.blackBright;
      e.bgColor.bgGrey = e.bgColor.bgBlackBright;
      for (const [t, n] of Object.entries(e)) {
        for (const [i, s] of Object.entries(n)) {
          e[i] = {
            open: `\x1B[${s[0]}m`,
            close: `\x1B[${s[1]}m`
          };
          n[i] = e[i];
          r.set(s[0], s[1]);
        }
        Object.defineProperty(e, t, {
          value: n,
          enumerable: false
        });
      }
      Object.defineProperty(e, "codes", {
        value: r,
        enumerable: false
      });
      e.color.close = "\x1B[39m";
      e.bgColor.close = "\x1B[49m";
      e.color.ansi256 = mp();
      e.color.ansi16m = yp();
      e.bgColor.ansi256 = mp(fp);
      e.bgColor.ansi16m = yp(fp);
      Object.defineProperties(e, {
        rgbToAnsi256: {
          value: (t, n, i) => {
            if (t === n && n === i) {
              if (t < 8) {
                return 16;
              }
              if (t > 248) {
                return 231;
              }
              return Math.round((t - 8) / 247 * 24) + 232;
            }
            return 16 + 36 * Math.round(t / 255 * 5) + 6 * Math.round(n / 255 * 5) + Math.round(i / 255 * 5);
          },
          enumerable: false
        },
        hexToRgb: {
          value: (t) => {
            const n = /(?<colorString>[a-f\d]{6}|[a-f\d]{3})/i.exec(t.toString(16));
            if (!n) {
              return [0, 0, 0];
            }
            let { colorString: i } = n.groups;
            if (i.length === 3) {
              i = i.split("").map((a) => a + a).join("");
            }
            const s = Number.parseInt(i, 16);
            return [
              s >> 16 & 255,
              s >> 8 & 255,
              s & 255
            ];
          },
          enumerable: false
        },
        hexToAnsi256: {
          value: (t) => e.rgbToAnsi256(...e.hexToRgb(t)),
          enumerable: false
        }
      });
      return e;
    }
    Object.defineProperty(bp, "exports", {
      enumerable: true,
      get: Lb
    });
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/callbacks/handlers/tracer.js
  var zt;
  var Qi = j(() => {
    Vo();
    zt = class extends At {
      constructor(e) {
        super(...arguments);
        Object.defineProperty(this, "runMap", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: /* @__PURE__ */ new Map()
        });
      }
      copy() {
        return this;
      }
      _addChildRun(e, t) {
        e.child_runs.push(t);
      }
      _startTrace(e) {
        if (e.parent_run_id !== void 0) {
          const t = this.runMap.get(e.parent_run_id);
          if (t) {
            this._addChildRun(t, e);
          }
        }
        this.runMap.set(e.id, e);
      }
      async _endTrace(e) {
        const t = e.parent_run_id !== void 0 && this.runMap.get(e.parent_run_id);
        if (t) {
          t.child_execution_order = Math.max(t.child_execution_order, e.child_execution_order);
        } else {
          await this.persistRun(e);
        }
        this.runMap.delete(e.id);
      }
      _getExecutionOrder(e) {
        const t = e !== void 0 && this.runMap.get(e);
        if (!t) {
          return 1;
        }
        return t.child_execution_order + 1;
      }
      async handleLLMStart(e, t, n, i, s, a) {
        const o = this._getExecutionOrder(i);
        const u = Date.now();
        const l = {
          id: n,
          name: e.id[e.id.length - 1],
          parent_run_id: i,
          start_time: u,
          serialized: e,
          events: [
            {
              name: "start",
              time: u
            }
          ],
          inputs: { prompts: t },
          execution_order: o,
          child_runs: [],
          child_execution_order: o,
          run_type: "llm",
          extra: s ?? {},
          tags: a || []
        };
        this._startTrace(l);
        await this.onLLMStart?.(l);
      }
      async handleChatModelStart(e, t, n, i, s, a) {
        const o = this._getExecutionOrder(i);
        const u = Date.now();
        const l = {
          id: n,
          name: e.id[e.id.length - 1],
          parent_run_id: i,
          start_time: u,
          serialized: e,
          events: [
            {
              name: "start",
              time: u
            }
          ],
          inputs: { messages: t },
          execution_order: o,
          child_runs: [],
          child_execution_order: o,
          run_type: "llm",
          extra: s ?? {},
          tags: a || []
        };
        this._startTrace(l);
        await this.onLLMStart?.(l);
      }
      async handleLLMEnd(e, t) {
        const n = this.runMap.get(t);
        if (!n || n?.run_type !== "llm") {
          throw new Error("No LLM run to end.");
        }
        n.end_time = Date.now();
        n.outputs = e;
        n.events.push({
          name: "end",
          time: n.end_time
        });
        await this.onLLMEnd?.(n);
        await this._endTrace(n);
      }
      async handleLLMError(e, t) {
        const n = this.runMap.get(t);
        if (!n || n?.run_type !== "llm") {
          throw new Error("No LLM run to end.");
        }
        n.end_time = Date.now();
        n.error = e.message;
        n.events.push({
          name: "error",
          time: n.end_time
        });
        await this.onLLMError?.(n);
        await this._endTrace(n);
      }
      async handleChainStart(e, t, n, i, s) {
        const a = this._getExecutionOrder(i);
        const o = Date.now();
        const u = {
          id: n,
          name: e.id[e.id.length - 1],
          parent_run_id: i,
          start_time: o,
          serialized: e,
          events: [
            {
              name: "start",
              time: o
            }
          ],
          inputs: t,
          execution_order: a,
          child_execution_order: a,
          run_type: "chain",
          child_runs: [],
          extra: {},
          tags: s || []
        };
        this._startTrace(u);
        await this.onChainStart?.(u);
      }
      async handleChainEnd(e, t) {
        const n = this.runMap.get(t);
        if (!n || n?.run_type !== "chain") {
          throw new Error("No chain run to end.");
        }
        n.end_time = Date.now();
        n.outputs = e;
        n.events.push({
          name: "end",
          time: n.end_time
        });
        await this.onChainEnd?.(n);
        await this._endTrace(n);
      }
      async handleChainError(e, t) {
        const n = this.runMap.get(t);
        if (!n || n?.run_type !== "chain") {
          throw new Error("No chain run to end.");
        }
        n.end_time = Date.now();
        n.error = e.message;
        n.events.push({
          name: "error",
          time: n.end_time
        });
        await this.onChainError?.(n);
        await this._endTrace(n);
      }
      async handleToolStart(e, t, n, i, s) {
        const a = this._getExecutionOrder(i);
        const o = Date.now();
        const u = {
          id: n,
          name: e.id[e.id.length - 1],
          parent_run_id: i,
          start_time: o,
          serialized: e,
          events: [
            {
              name: "start",
              time: o
            }
          ],
          inputs: { input: t },
          execution_order: a,
          child_execution_order: a,
          run_type: "tool",
          child_runs: [],
          extra: {},
          tags: s || []
        };
        this._startTrace(u);
        await this.onToolStart?.(u);
      }
      async handleToolEnd(e, t) {
        const n = this.runMap.get(t);
        if (!n || n?.run_type !== "tool") {
          throw new Error("No tool run to end");
        }
        n.end_time = Date.now();
        n.outputs = { output: e };
        n.events.push({
          name: "end",
          time: n.end_time
        });
        await this.onToolEnd?.(n);
        await this._endTrace(n);
      }
      async handleToolError(e, t) {
        const n = this.runMap.get(t);
        if (!n || n?.run_type !== "tool") {
          throw new Error("No tool run to end");
        }
        n.end_time = Date.now();
        n.error = e.message;
        n.events.push({
          name: "error",
          time: n.end_time
        });
        await this.onToolError?.(n);
        await this._endTrace(n);
      }
      async handleAgentAction(e, t) {
        const n = this.runMap.get(t);
        if (!n || n?.run_type !== "chain") {
          return;
        }
        const i = n;
        i.actions = i.actions || [];
        i.actions.push(e);
        i.events.push({
          name: "agent_action",
          time: Date.now(),
          kwargs: { action: e }
        });
        await this.onAgentAction?.(n);
      }
      async handleText(e, t) {
        const n = this.runMap.get(t);
        if (!n || n?.run_type !== "chain") {
          return;
        }
        n.events.push({
          name: "text",
          time: Date.now(),
          kwargs: { text: e }
        });
        await this.onText?.(n);
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/callbacks/handlers/console.js
  function Je(r, e) {
    return `${r.open}${e}${r.close}`;
  }
  function Ft(r, e) {
    try {
      return JSON.stringify(r, null, 2);
    } catch (t) {
      return e;
    }
  }
  function Fr(r) {
    if (!r.end_time)
      return "";
    const e = r.end_time - r.start_time;
    if (e < 1e3) {
      return `${e}ms`;
    }
    return `${(e / 1e3).toFixed(2)}s`;
  }
  var zo, it, Ln;
  var wp = j(() => {
    zo = be(gp(), 1);
    Qi();
    ({ color: it } = zo.default);
    Ln = class extends zt {
      constructor() {
        super(...arguments);
        Object.defineProperty(this, "name", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "console_callback_handler"
        });
      }
      persistRun(e) {
        return Promise.resolve();
      }
      // utility methods
      getParents(e) {
        const t = [];
        let n = e;
        while (n.parent_run_id) {
          const i = this.runMap.get(n.parent_run_id);
          if (i) {
            t.push(i);
            n = i;
          } else {
            break;
          }
        }
        return t;
      }
      getBreadcrumbs(e) {
        const t = this.getParents(e).reverse();
        const n = [...t, e].map((i, s, a) => {
          const o = `${i.execution_order}:${i.run_type}:${i.name}`;
          return s === a.length - 1 ? Je(zo.default.bold, o) : o;
        }).join(" > ");
        return Je(it.grey, n);
      }
      // logging methods
      onChainStart(e) {
        const t = this.getBreadcrumbs(e);
        console.log(`${Je(it.green, "[chain/start]")} [${t}] Entering Chain run with input: ${Ft(e.inputs, "[inputs]")}`);
      }
      onChainEnd(e) {
        const t = this.getBreadcrumbs(e);
        console.log(`${Je(it.cyan, "[chain/end]")} [${t}] [${Fr(e)}] Exiting Chain run with output: ${Ft(e.outputs, "[outputs]")}`);
      }
      onChainError(e) {
        const t = this.getBreadcrumbs(e);
        console.log(`${Je(it.red, "[chain/error]")} [${t}] [${Fr(e)}] Chain run errored with error: ${Ft(e.error, "[error]")}`);
      }
      onLLMStart(e) {
        const t = this.getBreadcrumbs(e);
        const n = "prompts" in e.inputs ? { prompts: e.inputs.prompts.map((i) => i.trim()) } : e.inputs;
        console.log(`${Je(it.green, "[llm/start]")} [${t}] Entering LLM run with input: ${Ft(n, "[inputs]")}`);
      }
      onLLMEnd(e) {
        const t = this.getBreadcrumbs(e);
        console.log(`${Je(it.cyan, "[llm/end]")} [${t}] [${Fr(e)}] Exiting LLM run with output: ${Ft(e.outputs, "[response]")}`);
      }
      onLLMError(e) {
        const t = this.getBreadcrumbs(e);
        console.log(`${Je(it.red, "[llm/error]")} [${t}] [${Fr(e)}] LLM run errored with error: ${Ft(e.error, "[error]")}`);
      }
      onToolStart(e) {
        const t = this.getBreadcrumbs(e);
        console.log(`${Je(it.green, "[tool/start]")} [${t}] Entering Tool run with input: "${e.inputs.input?.trim()}"`);
      }
      onToolEnd(e) {
        const t = this.getBreadcrumbs(e);
        console.log(`${Je(it.cyan, "[tool/end]")} [${t}] [${Fr(e)}] Exiting Tool run with output: "${e.outputs?.output?.trim()}"`);
      }
      onToolError(e) {
        const t = this.getBreadcrumbs(e);
        console.log(`${Je(it.red, "[tool/error]")} [${t}] [${Fr(e)}] Tool run errored with error: ${Ft(e.error, "[error]")}`);
      }
      onAgentAction(e) {
        const t = e;
        const n = this.getBreadcrumbs(e);
        console.log(`${Je(it.blue, "[agent/action]")} [${n}] Agent selected action: ${Ft(t.actions[t.actions.length - 1], "[action]")}`);
      }
    };
  });

  // node_modules/.pnpm/langchainplus-sdk@0.0.11/node_modules/langchainplus-sdk/dist/utils/async_caller.js
  var _p, Ji, Db, Yi;
  var vp = j(() => {
    _p = be(Ao(), 1);
    Ji = be(qi(), 1);
    Db = [
      400,
      401,
      403,
      404,
      405,
      406,
      407,
      408,
      409
      // Conflict
    ];
    Yi = class {
      constructor(e) {
        Object.defineProperty(this, "maxConcurrency", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "maxRetries", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "queue", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.maxConcurrency = e.maxConcurrency ?? Infinity;
        this.maxRetries = e.maxRetries ?? 6;
        const t = "default" in Ji.default ? Ji.default.default : Ji.default;
        this.queue = new t({ concurrency: this.maxConcurrency });
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      call(e, ...t) {
        return this.queue.add(() => (0, _p.default)(() => e(...t).catch((n) => {
          if (n instanceof Error) {
            throw n;
          } else {
            throw new Error(n);
          }
        }), {
          onFailedAttempt(n) {
            if (n.message.startsWith("Cancel") || n.message.startsWith("TimeoutError") || n.message.startsWith("AbortError")) {
              throw n;
            }
            if (n?.code === "ECONNABORTED") {
              throw n;
            }
            const i = n?.response?.status;
            if (i && Db.includes(+i)) {
              throw n;
            }
          },
          retries: this.maxRetries,
          randomize: true
          // If needed we can change some of the defaults here,
          // but they're quite sensible.
        }), { throwOnTimeout: true });
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      callWithOptions(e, t, ...n) {
        if (e.signal) {
          return Promise.race([
            this.call(t, ...n),
            new Promise((i, s) => {
              e.signal?.addEventListener("abort", () => {
                s(new Error("AbortError"));
              });
            })
          ]);
        }
        return this.call(t, ...n);
      }
      fetch(...e) {
        return this.call(() => fetch(...e).then((t) => t.ok ? t : Promise.reject(t)));
      }
    };
  });

  // node_modules/.pnpm/langchainplus-sdk@0.0.11/node_modules/langchainplus-sdk/dist/utils/env.js
  async function Ko() {
    if (Fo === void 0) {
      const r = Fb();
      Fo = {
        library: "langchainplus-sdk",
        runtime: r
      };
    }
    return Fo;
  }
  function Wi(r) {
    try {
      return typeof process !== "undefined" ? (
        // eslint-disable-next-line no-process-env
        process.env?.[r]
      ) : void 0;
    } catch (e) {
      return void 0;
    }
  }
  var qb, Ub, Vb, xp, zb, Fb, Fo;
  var Bo = j(() => {
    qb = () => typeof window !== "undefined" && typeof window.document !== "undefined";
    Ub = () => typeof globalThis === "object" && globalThis.constructor && globalThis.constructor.name === "DedicatedWorkerGlobalScope";
    Vb = () => typeof window !== "undefined" && window.name === "nodejs" || typeof navigator !== "undefined" && (navigator.userAgent.includes("Node.js") || navigator.userAgent.includes("jsdom"));
    xp = () => typeof Deno !== "undefined";
    zb = () => typeof process !== "undefined" && typeof process.versions !== "undefined" && typeof process.versions.node !== "undefined" && !xp();
    Fb = () => {
      let r;
      if (qb()) {
        r = "browser";
      } else if (zb()) {
        r = "node";
      } else if (Ub()) {
        r = "webworker";
      } else if (Vb()) {
        r = "jsdom";
      } else if (xp()) {
        r = "deno";
      } else {
        r = "other";
      }
      return r;
    };
  });

  // node_modules/.pnpm/langchainplus-sdk@0.0.11/node_modules/langchainplus-sdk/dist/client.js
  var Kb, $o, Kt;
  var Zo = j(() => {
    Hi();
    vp();
    Bo();
    Kb = (r) => {
      const e = r.replace("http://", "").replace("https://", "");
      const t = e.split("/")[0].split(":")[0];
      return t === "localhost" || t === "127.0.0.1" || t === "::1";
    };
    $o = async (r, e) => {
      const t = await r.text();
      if (!r.ok) {
        throw new Error(`Failed to ${e}: ${r.status} ${r.statusText} ${t}`);
      }
    };
    Kt = class {
      constructor(e = {}) {
        Object.defineProperty(this, "apiKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "apiUrl", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "caller", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "timeout_ms", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        const t = Kt.getDefaultClientConfig();
        this.apiUrl = e.apiUrl ?? t.apiUrl;
        this.apiKey = e.apiKey ?? t.apiKey;
        this.validateApiKeyIfHosted();
        this.timeout_ms = e.timeout_ms ?? 4e3;
        this.caller = new Yi(e.callerOptions ?? {});
      }
      static getDefaultClientConfig() {
        return {
          apiUrl: Wi("LANGCHAIN_ENDPOINT") ?? "http://localhost:1984",
          apiKey: Wi("LANGCHAIN_API_KEY")
        };
      }
      validateApiKeyIfHosted() {
        const e = Kb(this.apiUrl);
        if (!e && !this.apiKey) {
          throw new Error("API key must be provided when using hosted LangChain+ API");
        }
      }
      get headers() {
        const e = {};
        if (this.apiKey) {
          e["x-api-key"] = `${this.apiKey}`;
        }
        return e;
      }
      async _get(e, t) {
        const n = t?.toString() ?? "";
        const i = `${this.apiUrl}${e}?${n}`;
        const s = await this.caller.call(fetch, i, {
          method: "GET",
          headers: this.headers,
          signal: AbortSignal.timeout(this.timeout_ms)
        });
        if (!s.ok) {
          throw new Error(`Failed to fetch ${e}: ${s.status} ${s.statusText}`);
        }
        return s.json();
      }
      async createRun(e) {
        const t = { ...this.headers, "Content-Type": "application/json" };
        const n = e.extra ?? {};
        const i = await Ko();
        const s = {
          ...e,
          extra: {
            ...e.extra,
            runtime: {
              ...i,
              ...n.runtime
            }
          }
        };
        const a = await this.caller.call(fetch, `${this.apiUrl}/runs`, {
          method: "POST",
          headers: t,
          body: JSON.stringify(s),
          signal: AbortSignal.timeout(this.timeout_ms)
        });
        await $o(a, "create run");
      }
      async updateRun(e, t) {
        const n = { ...this.headers, "Content-Type": "application/json" };
        const i = await this.caller.call(fetch, `${this.apiUrl}/runs/${e}`, {
          method: "PATCH",
          headers: n,
          body: JSON.stringify(t),
          signal: AbortSignal.timeout(this.timeout_ms)
        });
        await $o(i, "update run");
      }
      async readRun(e) {
        return await this._get(`/runs/${e}`);
      }
      async listRuns({ sessionId: e, sessionName: t, executionOrder: n, runType: i, error: s }) {
        const a = new URLSearchParams();
        let o = e;
        if (t) {
          if (e) {
            throw new Error("Only one of sessionId or sessionName may be given");
          }
          o = (await this.readSession({ sessionName: t })).id;
        }
        if (o) {
          a.append("session", o);
        }
        if (n) {
          a.append("execution_order", n.toString());
        }
        if (i) {
          a.append("run_type", i);
        }
        if (s !== void 0) {
          a.append("error", s.toString());
        }
        return this._get("/runs", a);
      }
      async createSession({ sessionName: e, sessionExtra: t }) {
        const n = `${this.apiUrl}/sessions?upsert=true`;
        const i = {
          name: e,
          extra: t
        };
        const s = await this.caller.call(fetch, n, {
          method: "POST",
          headers: { ...this.headers, "Content-Type": "application/json" },
          body: JSON.stringify(i),
          signal: AbortSignal.timeout(this.timeout_ms)
        });
        const a = await s.json();
        if (!s.ok) {
          throw new Error(`Failed to create session ${e}: ${s.status} ${s.statusText}`);
        }
        return a;
      }
      async readSession({ sessionId: e, sessionName: t }) {
        let n = "/sessions";
        const i = new URLSearchParams();
        if (e !== void 0 && t !== void 0) {
          throw new Error("Must provide either sessionName or sessionId, not both");
        } else if (e !== void 0) {
          n += `/${e}`;
        } else if (t !== void 0) {
          i.append("name", t);
        } else {
          throw new Error("Must provide sessionName or sessionId");
        }
        const s = await this._get(n, i);
        let a;
        if (Array.isArray(s)) {
          if (s.length === 0) {
            throw new Error(`Session[id=${e}, name=${t}] not found`);
          }
          a = s[0];
        } else {
          a = s;
        }
        return a;
      }
      async listSessions() {
        return this._get("/sessions");
      }
      async deleteSession({ sessionId: e, sessionName: t }) {
        let n;
        if (e === void 0 && t === void 0) {
          throw new Error("Must provide sessionName or sessionId");
        } else if (e !== void 0 && t !== void 0) {
          throw new Error("Must provide either sessionName or sessionId, not both");
        } else if (e === void 0) {
          n = (await this.readSession({ sessionName: t })).id;
        } else {
          n = e;
        }
        const i = await this.caller.call(fetch, `${this.apiUrl}/sessions/${n}`, {
          method: "DELETE",
          headers: this.headers,
          signal: AbortSignal.timeout(this.timeout_ms)
        });
        await $o(i, `delete session ${n} (${t})`);
      }
      async uploadCsv({ csvFile: e, fileName: t, inputKeys: n, outputKeys: i, description: s }) {
        const a = `${this.apiUrl}/datasets/upload`;
        const o = new FormData();
        o.append("file", e, t);
        o.append("input_keys", n.join(","));
        o.append("output_keys", i.join(","));
        if (s) {
          o.append("description", s);
        }
        const u = await this.caller.call(fetch, a, {
          method: "POST",
          headers: this.headers,
          body: o,
          signal: AbortSignal.timeout(this.timeout_ms)
        });
        if (!u.ok) {
          const c = await u.json();
          if (c.detail && c.detail.includes("already exists")) {
            throw new Error(`Dataset ${t} already exists`);
          }
          throw new Error(`Failed to upload CSV: ${u.status} ${u.statusText}`);
        }
        const l = await u.json();
        return l;
      }
      async createDataset(e, { description: t } = {}) {
        const n = await this.caller.call(fetch, `${this.apiUrl}/datasets`, {
          method: "POST",
          headers: { ...this.headers, "Content-Type": "application/json" },
          body: JSON.stringify({
            name: e,
            description: t
          }),
          signal: AbortSignal.timeout(this.timeout_ms)
        });
        if (!n.ok) {
          const s = await n.json();
          if (s.detail && s.detail.includes("already exists")) {
            throw new Error(`Dataset ${e} already exists`);
          }
          throw new Error(`Failed to create dataset ${n.status} ${n.statusText}`);
        }
        const i = await n.json();
        return i;
      }
      async readDataset({ datasetId: e, datasetName: t }) {
        let n = "/datasets";
        const i = new URLSearchParams({ limit: "1" });
        if (e !== void 0 && t !== void 0) {
          throw new Error("Must provide either datasetName or datasetId, not both");
        } else if (e !== void 0) {
          n += `/${e}`;
        } else if (t !== void 0) {
          i.append("name", t);
        } else {
          throw new Error("Must provide datasetName or datasetId");
        }
        const s = await this._get(n, i);
        let a;
        if (Array.isArray(s)) {
          if (s.length === 0) {
            throw new Error(`Dataset[id=${e}, name=${t}] not found`);
          }
          a = s[0];
        } else {
          a = s;
        }
        return a;
      }
      async listDatasets({ limit: e = 100 } = {}) {
        const t = "/datasets";
        const n = new URLSearchParams({ limit: e.toString() });
        const i = await this._get(t, n);
        if (!Array.isArray(i)) {
          throw new Error(`Expected ${t} to return an array, but got ${i}`);
        }
        return i;
      }
      async deleteDataset({ datasetId: e, datasetName: t }) {
        let n = "/datasets";
        let i = e;
        if (e !== void 0 && t !== void 0) {
          throw new Error("Must provide either datasetName or datasetId, not both");
        } else if (t !== void 0) {
          const o = await this.readDataset({ datasetName: t });
          i = o.id;
        }
        if (i !== void 0) {
          n += `/${i}`;
        } else {
          throw new Error("Must provide datasetName or datasetId");
        }
        const s = await this.caller.call(fetch, this.apiUrl + n, {
          method: "DELETE",
          headers: this.headers,
          signal: AbortSignal.timeout(this.timeout_ms)
        });
        if (!s.ok) {
          throw new Error(`Failed to delete ${n}: ${s.status} ${s.statusText}`);
        }
        const a = await s.json();
        return a;
      }
      async createExample(e, t, { datasetId: n, datasetName: i, createdAt: s }) {
        let a = n;
        if (a === void 0 && i === void 0) {
          throw new Error("Must provide either datasetName or datasetId");
        } else if (a !== void 0 && i !== void 0) {
          throw new Error("Must provide either datasetName or datasetId, not both");
        } else if (a === void 0) {
          const b = await this.readDataset({ datasetName: i });
          a = b.id;
        }
        const o = s || /* @__PURE__ */ new Date();
        const u = {
          dataset_id: a,
          inputs: e,
          outputs: t,
          created_at: o.toISOString()
        };
        const l = await this.caller.call(fetch, `${this.apiUrl}/examples`, {
          method: "POST",
          headers: { ...this.headers, "Content-Type": "application/json" },
          body: JSON.stringify(u),
          signal: AbortSignal.timeout(this.timeout_ms)
        });
        if (!l.ok) {
          throw new Error(`Failed to create example: ${l.status} ${l.statusText}`);
        }
        const c = await l.json();
        return c;
      }
      async readExample(e) {
        const t = `/examples/${e}`;
        return await this._get(t);
      }
      async listExamples({ datasetId: e, datasetName: t } = {}) {
        let n;
        if (e !== void 0 && t !== void 0) {
          throw new Error("Must provide either datasetName or datasetId, not both");
        } else if (e !== void 0) {
          n = e;
        } else if (t !== void 0) {
          const s = await this.readDataset({ datasetName: t });
          n = s.id;
        } else {
          throw new Error("Must provide a datasetName or datasetId");
        }
        const i = await this._get("/examples", new URLSearchParams({ dataset: n }));
        if (!Array.isArray(i)) {
          throw new Error(`Expected /examples to return an array, but got ${i}`);
        }
        return i;
      }
      async deleteExample(e) {
        const t = `/examples/${e}`;
        const n = await this.caller.call(fetch, this.apiUrl + t, {
          method: "DELETE",
          headers: this.headers,
          signal: AbortSignal.timeout(this.timeout_ms)
        });
        if (!n.ok) {
          throw new Error(`Failed to delete ${t}: ${n.status} ${n.statusText}`);
        }
        const i = await n.json();
        return i;
      }
      async updateExample(e, t) {
        const n = await this.caller.call(fetch, `${this.apiUrl}/examples/${e}`, {
          method: "PATCH",
          headers: { ...this.headers, "Content-Type": "application/json" },
          body: JSON.stringify(t),
          signal: AbortSignal.timeout(this.timeout_ms)
        });
        if (!n.ok) {
          throw new Error(`Failed to update example ${e}: ${n.status} ${n.statusText}`);
        }
        const i = await n.json();
        return i;
      }
      async evaluateRun(e, t, { sourceInfo: n } = {}) {
        let i;
        if (typeof e === "string") {
          i = await this.readRun(e);
        } else if (typeof e === "object" && "id" in e) {
          i = e;
        } else {
          throw new Error(`Invalid run type: ${typeof e}`);
        }
        let s = void 0;
        if (i.reference_example_id !== null && i.reference_example_id !== void 0) {
          s = await this.readExample(i.reference_example_id);
        }
        const a = await t.evaluateRun(i, s);
        let o = n ?? {};
        if (a.evaluatorInfo) {
          o = { ...o, ...a.evaluatorInfo };
        }
        return await this.createFeedback(i.id, a.key, {
          score: a.score,
          value: a.value,
          comment: a.comment,
          correction: a.correction,
          sourceInfo: o,
          feedbackSourceType: "MODEL"
        });
      }
      async createFeedback(e, t, { score: n, value: i, correction: s, comment: a, sourceInfo: o, feedbackSourceType: u = "API" }) {
        let l;
        if (u === "API") {
          l = { type: "api", metadata: o ?? {} };
        } else if (u === "MODEL") {
          l = { type: "model", metadata: o ?? {} };
        } else {
          throw new Error(`Unknown feedback source type ${u}`);
        }
        const c = {
          id: nt(),
          run_id: e,
          key: t,
          score: n,
          value: i,
          correction: s,
          comment: a,
          feedback_source: l
        };
        const b = await this.caller.call(fetch, `${this.apiUrl}/feedback`, {
          method: "POST",
          headers: { ...this.headers, "Content-Type": "application/json" },
          body: JSON.stringify(c),
          signal: AbortSignal.timeout(this.timeout_ms)
        });
        if (!b.ok) {
          throw new Error(`Failed to create feedback for run ${e}: ${b.status} ${b.statusText}`);
        }
        const _ = await b.json();
        return _;
      }
      async readFeedback(e) {
        const t = `/feedback/${e}`;
        const n = await this._get(t);
        return n;
      }
      async deleteFeedback(e) {
        const t = `/feedback/${e}`;
        const n = await this.caller.call(fetch, this.apiUrl + t, {
          method: "DELETE",
          headers: this.headers,
          signal: AbortSignal.timeout(this.timeout_ms)
        });
        if (!n.ok) {
          throw new Error(`Failed to delete ${t}: ${n.status} ${n.statusText}`);
        }
        const i = await n.json();
        return i;
      }
      async listFeedback({ runIds: e } = {}) {
        const t = new URLSearchParams();
        if (e) {
          t.append("run", e.join(","));
        }
        const n = await this._get("/feedback", t);
        return n;
      }
    };
  });

  // node_modules/.pnpm/langchainplus-sdk@0.0.11/node_modules/langchainplus-sdk/dist/run_trees.js
  var Op = j(() => {
    Bo();
    Zo();
  });

  // node_modules/.pnpm/langchainplus-sdk@0.0.11/node_modules/langchainplus-sdk/dist/index.js
  var Pp = j(() => {
    Zo();
    Op();
  });

  // node_modules/.pnpm/langchainplus-sdk@0.0.11/node_modules/langchainplus-sdk/index.js
  var Ap = j(() => {
    Pp();
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/callbacks/handlers/tracer_langchain.js
  var Dn;
  var Ho = j(() => {
    Ap();
    _t();
    Qi();
    Dn = class extends zt {
      constructor(e = {}) {
        super(e);
        Object.defineProperty(this, "name", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "langchain_tracer"
        });
        Object.defineProperty(this, "sessionName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "exampleId", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "client", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        const { exampleId: t, sessionName: n, client: i } = e;
        this.sessionName = n ?? G("LANGCHAIN_SESSION");
        this.exampleId = t;
        this.client = i ?? new Kt({});
      }
      async _convertToCreate(e, t = void 0) {
        return {
          ...e,
          extra: {
            ...e.extra,
            runtime: await sc()
          },
          child_runs: void 0,
          session_name: this.sessionName,
          reference_example_id: e.parent_run_id ? void 0 : t
        };
      }
      async persistRun(e) {
      }
      async _persistRunSingle(e) {
        const t = await this._convertToCreate(e, this.exampleId);
        await this.client.createRun(t);
      }
      async _updateRunSingle(e) {
        const t = {
          end_time: e.end_time,
          error: e.error,
          outputs: e.outputs,
          events: e.events
        };
        await this.client.updateRun(e.id, t);
      }
      async onLLMStart(e) {
        await this._persistRunSingle(e);
      }
      async onLLMEnd(e) {
        await this._updateRunSingle(e);
      }
      async onLLMError(e) {
        await this._updateRunSingle(e);
      }
      async onChainStart(e) {
        await this._persistRunSingle(e);
      }
      async onChainEnd(e) {
        await this._updateRunSingle(e);
      }
      async onChainError(e) {
        await this._updateRunSingle(e);
      }
      async onToolStart(e) {
        await this._persistRunSingle(e);
      }
      async onToolEnd(e) {
        await this._updateRunSingle(e);
      }
      async onToolError(e) {
        await this._updateRunSingle(e);
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/memory/base.js
  function sr(r, e = "Human", t = "AI") {
    const n = [];
    for (const i of r) {
      let s;
      if (i._getType() === "human") {
        s = e;
      } else if (i._getType() === "ai") {
        s = t;
      } else if (i._getType() === "system") {
        s = "System";
      } else if (i._getType() === "generic") {
        s = i.role;
      } else {
        throw new Error(`Got unsupported message type: ${i}`);
      }
      n.push(`${s}: ${i.text}`);
    }
    return n.join("\n");
  }
  var Kr = j(() => {
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/callbacks/handlers/tracer_langchain_v1.js
  var Gi;
  var Ep = j(() => {
    Kr();
    _t();
    Qi();
    Gi = class extends zt {
      constructor() {
        super();
        Object.defineProperty(this, "name", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "langchain_tracer"
        });
        Object.defineProperty(this, "endpoint", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: G("LANGCHAIN_ENDPOINT") || "http://localhost:1984"
        });
        Object.defineProperty(this, "headers", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: {
            "Content-Type": "application/json"
          }
        });
        Object.defineProperty(this, "session", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        const e = G("LANGCHAIN_API_KEY");
        if (e) {
          this.headers["x-api-key"] = e;
        }
      }
      async newSession(e) {
        const t = {
          start_time: Date.now(),
          name: e
        };
        const n = await this.persistSession(t);
        this.session = n;
        return n;
      }
      async loadSession(e) {
        const t = `${this.endpoint}/sessions?name=${e}`;
        return this._handleSessionResponse(t);
      }
      async loadDefaultSession() {
        const e = `${this.endpoint}/sessions?name=default`;
        return this._handleSessionResponse(e);
      }
      async convertV2RunToRun(e) {
        const t = this.session ?? await this.loadDefaultSession();
        const n = e.serialized;
        let i;
        if (e.run_type === "llm") {
          const s = e.inputs.prompts ? e.inputs.prompts : e.inputs.messages.map((o) => sr(o));
          const a = {
            uuid: e.id,
            start_time: e.start_time,
            end_time: e.end_time,
            execution_order: e.execution_order,
            child_execution_order: e.child_execution_order,
            serialized: n,
            type: e.run_type,
            session_id: t.id,
            prompts: s,
            response: e.outputs
          };
          i = a;
        } else if (e.run_type === "chain") {
          const s = await Promise.all(e.child_runs.map((o) => this.convertV2RunToRun(o)));
          const a = {
            uuid: e.id,
            start_time: e.start_time,
            end_time: e.end_time,
            execution_order: e.execution_order,
            child_execution_order: e.child_execution_order,
            serialized: n,
            type: e.run_type,
            session_id: t.id,
            inputs: e.inputs,
            outputs: e.outputs,
            child_llm_runs: s.filter((o) => o.type === "llm"),
            child_chain_runs: s.filter((o) => o.type === "chain"),
            child_tool_runs: s.filter((o) => o.type === "tool")
          };
          i = a;
        } else if (e.run_type === "tool") {
          const s = await Promise.all(e.child_runs.map((o) => this.convertV2RunToRun(o)));
          const a = {
            uuid: e.id,
            start_time: e.start_time,
            end_time: e.end_time,
            execution_order: e.execution_order,
            child_execution_order: e.child_execution_order,
            serialized: n,
            type: e.run_type,
            session_id: t.id,
            tool_input: e.inputs.input,
            output: e.outputs?.output,
            action: JSON.stringify(n),
            child_llm_runs: s.filter((o) => o.type === "llm"),
            child_chain_runs: s.filter((o) => o.type === "chain"),
            child_tool_runs: s.filter((o) => o.type === "tool")
          };
          i = a;
        } else {
          throw new Error(`Unknown run type: ${e.run_type}`);
        }
        return i;
      }
      async persistRun(e) {
        let t;
        let n;
        if (e.run_type !== void 0) {
          n = await this.convertV2RunToRun(e);
        } else {
          n = e;
        }
        if (n.type === "llm") {
          t = `${this.endpoint}/llm-runs`;
        } else if (n.type === "chain") {
          t = `${this.endpoint}/chain-runs`;
        } else {
          t = `${this.endpoint}/tool-runs`;
        }
        const i = await fetch(t, {
          method: "POST",
          headers: this.headers,
          body: JSON.stringify(n)
        });
        if (!i.ok) {
          console.error(`Failed to persist run: ${i.status} ${i.statusText}`);
        }
      }
      async persistSession(e) {
        const t = `${this.endpoint}/sessions`;
        const n = await fetch(t, {
          method: "POST",
          headers: this.headers,
          body: JSON.stringify(e)
        });
        if (!n.ok) {
          console.error(`Failed to persist session: ${n.status} ${n.statusText}, using default session.`);
          return {
            id: 1,
            ...e
          };
        }
        return {
          id: (await n.json()).id,
          ...e
        };
      }
      async _handleSessionResponse(e) {
        const t = await fetch(e, {
          method: "GET",
          headers: this.headers
        });
        let n;
        if (!t.ok) {
          console.error(`Failed to load session: ${t.status} ${t.statusText}`);
          n = {
            id: 1,
            start_time: Date.now()
          };
          this.session = n;
          return n;
        }
        const i = await t.json();
        if (i.length === 0) {
          n = {
            id: 1,
            start_time: Date.now()
          };
          this.session = n;
          return n;
        }
        [n] = i;
        this.session = n;
        return n;
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/callbacks/handlers/initialize.js
  async function Tp(r) {
    const e = new Gi();
    if (r) {
      await e.loadSession(r);
    } else {
      await e.loadDefaultSession();
    }
    return e;
  }
  async function Ip() {
    return new Dn();
  }
  var Cp = j(() => {
    Ho();
    Ep();
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/callbacks/promises.js
  function Bb() {
    const r = "default" in Xi.default ? Xi.default.default : Xi.default;
    return new r({
      autoStart: true,
      concurrency: 1
    });
  }
  async function Re(r, e) {
    if (e === true) {
      await r();
    } else {
      if (typeof Qo === "undefined") {
        Qo = Bb();
      }
      void Qo.add(r);
    }
  }
  var Xi, Qo;
  var Sp = j(() => {
    Xi = be(qi(), 1);
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/callbacks/manager.js
  function jp(r) {
    if ("name" in r) {
      return r;
    }
    return At.fromMethods(r);
  }
  var Jo, qn, es, Yo, Wo, qe;
  var ts = j(() => {
    Hi();
    Vo();
    wp();
    Cp();
    Kr();
    _t();
    Ho();
    Sp();
    Jo = class {
      setHandler(e) {
        return this.setHandlers([e]);
      }
    };
    qn = class {
      constructor(e, t, n, i, s, a) {
        Object.defineProperty(this, "runId", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: e
        });
        Object.defineProperty(this, "handlers", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: t
        });
        Object.defineProperty(this, "inheritableHandlers", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: n
        });
        Object.defineProperty(this, "tags", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: i
        });
        Object.defineProperty(this, "inheritableTags", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: s
        });
        Object.defineProperty(this, "_parentRunId", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: a
        });
      }
      async handleText(e) {
        await Promise.all(this.handlers.map((t) => Re(async () => {
          try {
            await t.handleText?.(e, this.runId, this._parentRunId);
          } catch (n) {
            console.error(`Error in handler ${t.constructor.name}, handleText: ${n}`);
          }
        }, t.awaitHandlers)));
      }
    };
    es = class extends qn {
      async handleLLMNewToken(e) {
        await Promise.all(this.handlers.map((t) => Re(async () => {
          if (!t.ignoreLLM) {
            try {
              await t.handleLLMNewToken?.(e, this.runId, this._parentRunId);
            } catch (n) {
              console.error(`Error in handler ${t.constructor.name}, handleLLMNewToken: ${n}`);
            }
          }
        }, t.awaitHandlers)));
      }
      async handleLLMError(e) {
        await Promise.all(this.handlers.map((t) => Re(async () => {
          if (!t.ignoreLLM) {
            try {
              await t.handleLLMError?.(e, this.runId, this._parentRunId);
            } catch (n) {
              console.error(`Error in handler ${t.constructor.name}, handleLLMError: ${n}`);
            }
          }
        }, t.awaitHandlers)));
      }
      async handleLLMEnd(e) {
        await Promise.all(this.handlers.map((t) => Re(async () => {
          if (!t.ignoreLLM) {
            try {
              await t.handleLLMEnd?.(e, this.runId, this._parentRunId);
            } catch (n) {
              console.error(`Error in handler ${t.constructor.name}, handleLLMEnd: ${n}`);
            }
          }
        }, t.awaitHandlers)));
      }
    };
    Yo = class extends qn {
      getChild(e) {
        const t = new qe(this.runId);
        t.setHandlers(this.inheritableHandlers);
        t.addTags(this.inheritableTags);
        if (e) {
          t.addTags([e], false);
        }
        return t;
      }
      async handleChainError(e) {
        await Promise.all(this.handlers.map((t) => Re(async () => {
          if (!t.ignoreChain) {
            try {
              await t.handleChainError?.(e, this.runId, this._parentRunId);
            } catch (n) {
              console.error(`Error in handler ${t.constructor.name}, handleChainError: ${n}`);
            }
          }
        }, t.awaitHandlers)));
      }
      async handleChainEnd(e) {
        await Promise.all(this.handlers.map((t) => Re(async () => {
          if (!t.ignoreChain) {
            try {
              await t.handleChainEnd?.(e, this.runId, this._parentRunId);
            } catch (n) {
              console.error(`Error in handler ${t.constructor.name}, handleChainEnd: ${n}`);
            }
          }
        }, t.awaitHandlers)));
      }
      async handleAgentAction(e) {
        await Promise.all(this.handlers.map((t) => Re(async () => {
          if (!t.ignoreAgent) {
            try {
              await t.handleAgentAction?.(e, this.runId, this._parentRunId);
            } catch (n) {
              console.error(`Error in handler ${t.constructor.name}, handleAgentAction: ${n}`);
            }
          }
        }, t.awaitHandlers)));
      }
      async handleAgentEnd(e) {
        await Promise.all(this.handlers.map((t) => Re(async () => {
          if (!t.ignoreAgent) {
            try {
              await t.handleAgentEnd?.(e, this.runId, this._parentRunId);
            } catch (n) {
              console.error(`Error in handler ${t.constructor.name}, handleAgentEnd: ${n}`);
            }
          }
        }, t.awaitHandlers)));
      }
    };
    Wo = class extends qn {
      getChild(e) {
        const t = new qe(this.runId);
        t.setHandlers(this.inheritableHandlers);
        t.addTags(this.inheritableTags);
        if (e) {
          t.addTags([e], false);
        }
        return t;
      }
      async handleToolError(e) {
        await Promise.all(this.handlers.map((t) => Re(async () => {
          if (!t.ignoreAgent) {
            try {
              await t.handleToolError?.(e, this.runId, this._parentRunId);
            } catch (n) {
              console.error(`Error in handler ${t.constructor.name}, handleToolError: ${n}`);
            }
          }
        }, t.awaitHandlers)));
      }
      async handleToolEnd(e) {
        await Promise.all(this.handlers.map((t) => Re(async () => {
          if (!t.ignoreAgent) {
            try {
              await t.handleToolEnd?.(e, this.runId, this._parentRunId);
            } catch (n) {
              console.error(`Error in handler ${t.constructor.name}, handleToolEnd: ${n}`);
            }
          }
        }, t.awaitHandlers)));
      }
    };
    qe = class extends Jo {
      constructor(e) {
        super();
        Object.defineProperty(this, "handlers", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "inheritableHandlers", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "tags", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: []
        });
        Object.defineProperty(this, "inheritableTags", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: []
        });
        Object.defineProperty(this, "name", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "callback_manager"
        });
        Object.defineProperty(this, "_parentRunId", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.handlers = [];
        this.inheritableHandlers = [];
        this._parentRunId = e;
      }
      async handleLLMStart(e, t, n = nt(), i = void 0, s = void 0) {
        await Promise.all(this.handlers.map((a) => Re(async () => {
          if (!a.ignoreLLM) {
            try {
              await a.handleLLMStart?.(e, t, n, this._parentRunId, s, this.tags);
            } catch (o) {
              console.error(`Error in handler ${a.constructor.name}, handleLLMStart: ${o}`);
            }
          }
        }, a.awaitHandlers)));
        return new es(n, this.handlers, this.inheritableHandlers, this.tags, this.inheritableTags, this._parentRunId);
      }
      async handleChatModelStart(e, t, n = nt(), i = void 0, s = void 0) {
        let a;
        await Promise.all(this.handlers.map((o) => Re(async () => {
          if (!o.ignoreLLM) {
            try {
              if (o.handleChatModelStart)
                await o.handleChatModelStart?.(e, t, n, this._parentRunId, s, this.tags);
              else if (o.handleLLMStart) {
                a = t.map((u) => sr(u));
                await o.handleLLMStart?.(e, a, n, this._parentRunId, s, this.tags);
              }
            } catch (u) {
              console.error(`Error in handler ${o.constructor.name}, handleLLMStart: ${u}`);
            }
          }
        }, o.awaitHandlers)));
        return new es(n, this.handlers, this.inheritableHandlers, this.tags, this.inheritableTags, this._parentRunId);
      }
      async handleChainStart(e, t, n = nt()) {
        await Promise.all(this.handlers.map((i) => Re(async () => {
          if (!i.ignoreChain) {
            try {
              await i.handleChainStart?.(e, t, n, this._parentRunId, this.tags);
            } catch (s) {
              console.error(`Error in handler ${i.constructor.name}, handleChainStart: ${s}`);
            }
          }
        }, i.awaitHandlers)));
        return new Yo(n, this.handlers, this.inheritableHandlers, this.tags, this.inheritableTags, this._parentRunId);
      }
      async handleToolStart(e, t, n = nt()) {
        await Promise.all(this.handlers.map((i) => Re(async () => {
          if (!i.ignoreAgent) {
            try {
              await i.handleToolStart?.(e, t, n, this._parentRunId, this.tags);
            } catch (s) {
              console.error(`Error in handler ${i.constructor.name}, handleToolStart: ${s}`);
            }
          }
        }, i.awaitHandlers)));
        return new Wo(n, this.handlers, this.inheritableHandlers, this.tags, this.inheritableTags, this._parentRunId);
      }
      addHandler(e, t = true) {
        this.handlers.push(e);
        if (t) {
          this.inheritableHandlers.push(e);
        }
      }
      removeHandler(e) {
        this.handlers = this.handlers.filter((t) => t !== e);
        this.inheritableHandlers = this.inheritableHandlers.filter((t) => t !== e);
      }
      setHandlers(e, t = true) {
        this.handlers = [];
        this.inheritableHandlers = [];
        for (const n of e) {
          this.addHandler(n, t);
        }
      }
      addTags(e, t = true) {
        this.removeTags(e);
        this.tags.push(...e);
        if (t) {
          this.inheritableTags.push(...e);
        }
      }
      removeTags(e) {
        this.tags = this.tags.filter((t) => !e.includes(t));
        this.inheritableTags = this.inheritableTags.filter((t) => !e.includes(t));
      }
      copy(e = [], t = true) {
        const n = new qe(this._parentRunId);
        for (const i of this.handlers) {
          const s = this.inheritableHandlers.includes(i);
          n.addHandler(i, s);
        }
        for (const i of this.tags) {
          const s = this.inheritableTags.includes(i);
          n.addTags([i], s);
        }
        for (const i of e) {
          if (
            // Prevent multiple copies of console_callback_handler
            n.handlers.filter((s) => s.name === "console_callback_handler").some((s) => s.name === i.name)
          ) {
            continue;
          }
          n.addHandler(i, t);
        }
        return n;
      }
      static fromHandlers(e) {
        class t extends At {
          constructor() {
            super();
            Object.defineProperty(this, "name", {
              enumerable: true,
              configurable: true,
              writable: true,
              value: nt()
            });
            Object.assign(this, e);
          }
        }
        const n = new this();
        n.addHandler(new t());
        return n;
      }
      static async configure(e, t, n, i, s) {
        let a;
        if (e || t) {
          if (Array.isArray(e) || !e) {
            a = new qe();
            a.setHandlers(e?.map(jp) ?? [], true);
          } else {
            a = e;
          }
          a = a.copy(Array.isArray(t) ? t.map(jp) : t?.handlers, false);
        }
        const o = G("LANGCHAIN_VERBOSE") || s?.verbose;
        const u = G("LANGCHAIN_TRACING_V2") ?? false;
        const l = u || (G("LANGCHAIN_TRACING") ?? false);
        if (o || l) {
          if (!a) {
            a = new qe();
          }
          if (o && !a.handlers.some((c) => c.name === Ln.prototype.name)) {
            const c = new Ln();
            a.addHandler(c, true);
          }
          if (l && !a.handlers.some((c) => c.name === "langchain_tracer")) {
            if (u) {
              a.addHandler(await Ip(), true);
            } else {
              const c = G("LANGCHAIN_SESSION");
              a.addHandler(await Tp(c), true);
            }
          }
        }
        if (n || i) {
          if (a) {
            a.addTags(n ?? []);
            a.addTags(i ?? [], false);
          }
        }
        return a;
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chat_models/base.js
  var rs;
  var kp = j(() => {
    ct();
    Br();
    ts();
    rs = class extends Et {
      constructor(e) {
        super(e);
        Object.defineProperty(this, "lc_namespace", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: ["langchain", "chat_models", this._llmType()]
        });
      }
      async generate(e, t, n) {
        const i = [];
        const s = [];
        let a;
        if (Array.isArray(t)) {
          a = { stop: t };
        } else if (t?.timeout && !t.signal) {
          a = {
            ...t,
            signal: AbortSignal.timeout(t.timeout)
          };
        } else {
          a = t ?? {};
        }
        const o = await qe.configure(n, this.callbacks, a.tags, this.tags, { verbose: this.verbose });
        const u = {
          options: a,
          invocation_params: this?.invocationParams()
        };
        const l = await o?.handleChatModelStart(this.toJSON(), e, void 0, void 0, u);
        try {
          const b = await Promise.all(e.map((_) => this._generate(_, a, l)));
          for (const _ of b) {
            if (_.llmOutput) {
              s.push(_.llmOutput);
            }
            i.push(_.generations);
          }
        } catch (b) {
          await l?.handleLLMError(b);
          throw b;
        }
        const c = {
          generations: i,
          llmOutput: s.length ? this._combineLLMOutput?.(...s) : void 0
        };
        await l?.handleLLMEnd(c);
        Object.defineProperty(c, qr, {
          value: l ? { runId: l?.runId } : void 0,
          configurable: true
        });
        return c;
      }
      /**
       * Get the parameters used to invoke the model
       */
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      invocationParams() {
        return {};
      }
      _modelType() {
        return "base_chat_model";
      }
      async generatePrompt(e, t, n) {
        const i = e.map((s) => s.toChatMessages());
        return this.generate(i, t, n);
      }
      async call(e, t, n) {
        const i = await this.generate([e], t, n);
        const s = i.generations;
        return s[0][0].message;
      }
      async callPrompt(e, t, n) {
        const i = e.toChatMessages();
        return this.call(i, t, n);
      }
      async predictMessages(e, t, n) {
        return this.call(e, t, n);
      }
      async predict(e, t, n) {
        const i = new lt(e);
        const s = await this.call([i], t, n);
        return s.text;
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/util/prompt-layer.js
  var $r;
  var ns = j(() => {
    $r = async (r, e, t, n, i, s, a, o, u) => {
      const l = await r.call(fetch, "https://api.promptlayer.com/track-request", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json"
        },
        body: JSON.stringify({
          function_name: e,
          provider: "langchain",
          args: t,
          kwargs: n,
          tags: i,
          request_response: s,
          request_start_time: Math.floor(a / 1e3),
          request_end_time: Math.floor(o / 1e3),
          api_key: u
        })
      });
      return l.json();
    };
  });

  // node_modules/.pnpm/zod@3.21.4/node_modules/zod/lib/helpers/util.js
  var Un = N((oe) => {
    "use strict";
    Object.defineProperty(oe, "__esModule", { value: true });
    oe.getParsedType = oe.ZodParsedType = oe.objectUtil = oe.util = void 0;
    var Rp;
    (function(r) {
      r.assertEqual = (i) => i;
      function e(i) {
      }
      r.assertIs = e;
      function t(i) {
        throw new Error();
      }
      r.assertNever = t;
      r.arrayToEnum = (i) => {
        const s = {};
        for (const a of i) {
          s[a] = a;
        }
        return s;
      };
      r.getValidEnumValues = (i) => {
        const s = r.objectKeys(i).filter((o) => typeof i[i[o]] !== "number");
        const a = {};
        for (const o of s) {
          a[o] = i[o];
        }
        return r.objectValues(a);
      };
      r.objectValues = (i) => {
        return r.objectKeys(i).map(function(s) {
          return i[s];
        });
      };
      r.objectKeys = typeof Object.keys === "function" ? (i) => Object.keys(i) : (i) => {
        const s = [];
        for (const a in i) {
          if (Object.prototype.hasOwnProperty.call(i, a)) {
            s.push(a);
          }
        }
        return s;
      };
      r.find = (i, s) => {
        for (const a of i) {
          if (s(a))
            return a;
        }
        return void 0;
      };
      r.isInteger = typeof Number.isInteger === "function" ? (i) => Number.isInteger(i) : (i) => typeof i === "number" && isFinite(i) && Math.floor(i) === i;
      function n(i, s = " | ") {
        return i.map((a) => typeof a === "string" ? `'${a}'` : a).join(s);
      }
      r.joinValues = n;
      r.jsonStringifyReplacer = (i, s) => {
        if (typeof s === "bigint") {
          return s.toString();
        }
        return s;
      };
    })(Rp = oe.util || (oe.util = {}));
    var $b;
    (function(r) {
      r.mergeShapes = (e, t) => {
        return {
          ...e,
          ...t
        };
      };
    })($b = oe.objectUtil || (oe.objectUtil = {}));
    oe.ZodParsedType = Rp.arrayToEnum([
      "string",
      "nan",
      "number",
      "integer",
      "float",
      "boolean",
      "date",
      "bigint",
      "symbol",
      "function",
      "undefined",
      "null",
      "array",
      "object",
      "unknown",
      "promise",
      "void",
      "never",
      "map",
      "set"
    ]);
    var Zb = (r) => {
      const e = typeof r;
      switch (e) {
        case "undefined":
          return oe.ZodParsedType.undefined;
        case "string":
          return oe.ZodParsedType.string;
        case "number":
          return isNaN(r) ? oe.ZodParsedType.nan : oe.ZodParsedType.number;
        case "boolean":
          return oe.ZodParsedType.boolean;
        case "function":
          return oe.ZodParsedType.function;
        case "bigint":
          return oe.ZodParsedType.bigint;
        case "symbol":
          return oe.ZodParsedType.symbol;
        case "object":
          if (Array.isArray(r)) {
            return oe.ZodParsedType.array;
          }
          if (r === null) {
            return oe.ZodParsedType.null;
          }
          if (r.then && typeof r.then === "function" && r.catch && typeof r.catch === "function") {
            return oe.ZodParsedType.promise;
          }
          if (typeof Map !== "undefined" && r instanceof Map) {
            return oe.ZodParsedType.map;
          }
          if (typeof Set !== "undefined" && r instanceof Set) {
            return oe.ZodParsedType.set;
          }
          if (typeof Date !== "undefined" && r instanceof Date) {
            return oe.ZodParsedType.date;
          }
          return oe.ZodParsedType.object;
        default:
          return oe.ZodParsedType.unknown;
      }
    };
    oe.getParsedType = Zb;
  });

  // node_modules/.pnpm/zod@3.21.4/node_modules/zod/lib/ZodError.js
  var is = N((Bt) => {
    "use strict";
    Object.defineProperty(Bt, "__esModule", { value: true });
    Bt.ZodError = Bt.quotelessJson = Bt.ZodIssueCode = void 0;
    var Np = Un();
    Bt.ZodIssueCode = Np.util.arrayToEnum([
      "invalid_type",
      "invalid_literal",
      "custom",
      "invalid_union",
      "invalid_union_discriminator",
      "invalid_enum_value",
      "unrecognized_keys",
      "invalid_arguments",
      "invalid_return_type",
      "invalid_date",
      "invalid_string",
      "too_small",
      "too_big",
      "invalid_intersection_types",
      "not_multiple_of",
      "not_finite"
    ]);
    var Hb = (r) => {
      const e = JSON.stringify(r, null, 2);
      return e.replace(/"([^"]+)":/g, "$1:");
    };
    Bt.quotelessJson = Hb;
    var Vn = class extends Error {
      constructor(e) {
        super();
        this.issues = [];
        this.addIssue = (n) => {
          this.issues = [...this.issues, n];
        };
        this.addIssues = (n = []) => {
          this.issues = [...this.issues, ...n];
        };
        const t = new.target.prototype;
        if (Object.setPrototypeOf) {
          Object.setPrototypeOf(this, t);
        } else {
          this.__proto__ = t;
        }
        this.name = "ZodError";
        this.issues = e;
      }
      get errors() {
        return this.issues;
      }
      format(e) {
        const t = e || function(s) {
          return s.message;
        };
        const n = { _errors: [] };
        const i = (s) => {
          for (const a of s.issues) {
            if (a.code === "invalid_union") {
              a.unionErrors.map(i);
            } else if (a.code === "invalid_return_type") {
              i(a.returnTypeError);
            } else if (a.code === "invalid_arguments") {
              i(a.argumentsError);
            } else if (a.path.length === 0) {
              n._errors.push(t(a));
            } else {
              let o = n;
              let u = 0;
              while (u < a.path.length) {
                const l = a.path[u];
                const c = u === a.path.length - 1;
                if (!c) {
                  o[l] = o[l] || { _errors: [] };
                } else {
                  o[l] = o[l] || { _errors: [] };
                  o[l]._errors.push(t(a));
                }
                o = o[l];
                u++;
              }
            }
          }
        };
        i(this);
        return n;
      }
      toString() {
        return this.message;
      }
      get message() {
        return JSON.stringify(this.issues, Np.util.jsonStringifyReplacer, 2);
      }
      get isEmpty() {
        return this.issues.length === 0;
      }
      flatten(e = (t) => t.message) {
        const t = {};
        const n = [];
        for (const i of this.issues) {
          if (i.path.length > 0) {
            t[i.path[0]] = t[i.path[0]] || [];
            t[i.path[0]].push(e(i));
          } else {
            n.push(e(i));
          }
        }
        return { formErrors: n, fieldErrors: t };
      }
      get formErrors() {
        return this.flatten();
      }
    };
    Bt.ZodError = Vn;
    Vn.create = (r) => {
      const e = new Vn(r);
      return e;
    };
  });

  // node_modules/.pnpm/zod@3.21.4/node_modules/zod/lib/locales/en.js
  var Xo = N((Go) => {
    "use strict";
    Object.defineProperty(Go, "__esModule", { value: true });
    var ar = Un();
    var Ce = is();
    var Qb = (r, e) => {
      let t;
      switch (r.code) {
        case Ce.ZodIssueCode.invalid_type:
          if (r.received === ar.ZodParsedType.undefined) {
            t = "Required";
          } else {
            t = `Expected ${r.expected}, received ${r.received}`;
          }
          break;
        case Ce.ZodIssueCode.invalid_literal:
          t = `Invalid literal value, expected ${JSON.stringify(r.expected, ar.util.jsonStringifyReplacer)}`;
          break;
        case Ce.ZodIssueCode.unrecognized_keys:
          t = `Unrecognized key(s) in object: ${ar.util.joinValues(r.keys, ", ")}`;
          break;
        case Ce.ZodIssueCode.invalid_union:
          t = `Invalid input`;
          break;
        case Ce.ZodIssueCode.invalid_union_discriminator:
          t = `Invalid discriminator value. Expected ${ar.util.joinValues(r.options)}`;
          break;
        case Ce.ZodIssueCode.invalid_enum_value:
          t = `Invalid enum value. Expected ${ar.util.joinValues(r.options)}, received '${r.received}'`;
          break;
        case Ce.ZodIssueCode.invalid_arguments:
          t = `Invalid function arguments`;
          break;
        case Ce.ZodIssueCode.invalid_return_type:
          t = `Invalid function return type`;
          break;
        case Ce.ZodIssueCode.invalid_date:
          t = `Invalid date`;
          break;
        case Ce.ZodIssueCode.invalid_string:
          if (typeof r.validation === "object") {
            if ("includes" in r.validation) {
              t = `Invalid input: must include "${r.validation.includes}"`;
              if (typeof r.validation.position === "number") {
                t = `${t} at one or more positions greater than or equal to ${r.validation.position}`;
              }
            } else if ("startsWith" in r.validation) {
              t = `Invalid input: must start with "${r.validation.startsWith}"`;
            } else if ("endsWith" in r.validation) {
              t = `Invalid input: must end with "${r.validation.endsWith}"`;
            } else {
              ar.util.assertNever(r.validation);
            }
          } else if (r.validation !== "regex") {
            t = `Invalid ${r.validation}`;
          } else {
            t = "Invalid";
          }
          break;
        case Ce.ZodIssueCode.too_small:
          if (r.type === "array")
            t = `Array must contain ${r.exact ? "exactly" : r.inclusive ? `at least` : `more than`} ${r.minimum} element(s)`;
          else if (r.type === "string")
            t = `String must contain ${r.exact ? "exactly" : r.inclusive ? `at least` : `over`} ${r.minimum} character(s)`;
          else if (r.type === "number")
            t = `Number must be ${r.exact ? `exactly equal to ` : r.inclusive ? `greater than or equal to ` : `greater than `}${r.minimum}`;
          else if (r.type === "date")
            t = `Date must be ${r.exact ? `exactly equal to ` : r.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(r.minimum))}`;
          else
            t = "Invalid input";
          break;
        case Ce.ZodIssueCode.too_big:
          if (r.type === "array")
            t = `Array must contain ${r.exact ? `exactly` : r.inclusive ? `at most` : `less than`} ${r.maximum} element(s)`;
          else if (r.type === "string")
            t = `String must contain ${r.exact ? `exactly` : r.inclusive ? `at most` : `under`} ${r.maximum} character(s)`;
          else if (r.type === "number")
            t = `Number must be ${r.exact ? `exactly` : r.inclusive ? `less than or equal to` : `less than`} ${r.maximum}`;
          else if (r.type === "bigint")
            t = `BigInt must be ${r.exact ? `exactly` : r.inclusive ? `less than or equal to` : `less than`} ${r.maximum}`;
          else if (r.type === "date")
            t = `Date must be ${r.exact ? `exactly` : r.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(r.maximum))}`;
          else
            t = "Invalid input";
          break;
        case Ce.ZodIssueCode.custom:
          t = `Invalid input`;
          break;
        case Ce.ZodIssueCode.invalid_intersection_types:
          t = `Intersection results could not be merged`;
          break;
        case Ce.ZodIssueCode.not_multiple_of:
          t = `Number must be a multiple of ${r.multipleOf}`;
          break;
        case Ce.ZodIssueCode.not_finite:
          t = "Number must be finite";
          break;
        default:
          t = e.defaultError;
          ar.util.assertNever(r);
      }
      return { message: t };
    };
    Go.default = Qb;
  });

  // node_modules/.pnpm/zod@3.21.4/node_modules/zod/lib/errors.js
  var ss = N((pt) => {
    "use strict";
    var Jb = pt && pt.__importDefault || function(r) {
      return r && r.__esModule ? r : { "default": r };
    };
    Object.defineProperty(pt, "__esModule", { value: true });
    pt.getErrorMap = pt.setErrorMap = pt.defaultErrorMap = void 0;
    var Mp = Jb(Xo());
    pt.defaultErrorMap = Mp.default;
    var Lp = Mp.default;
    function Yb(r) {
      Lp = r;
    }
    pt.setErrorMap = Yb;
    function Wb() {
      return Lp;
    }
    pt.getErrorMap = Wb;
  });

  // node_modules/.pnpm/zod@3.21.4/node_modules/zod/lib/helpers/parseUtil.js
  var eu = N((ie) => {
    "use strict";
    var Gb = ie && ie.__importDefault || function(r) {
      return r && r.__esModule ? r : { "default": r };
    };
    Object.defineProperty(ie, "__esModule", { value: true });
    ie.isAsync = ie.isValid = ie.isDirty = ie.isAborted = ie.OK = ie.DIRTY = ie.INVALID = ie.ParseStatus = ie.addIssueToContext = ie.EMPTY_PATH = ie.makeIssue = void 0;
    var Xb = ss();
    var eg = Gb(Xo());
    var tg = (r) => {
      const { data: e, path: t, errorMaps: n, issueData: i } = r;
      const s = [...t, ...i.path || []];
      const a = {
        ...i,
        path: s
      };
      let o = "";
      const u = n.filter((l) => !!l).slice().reverse();
      for (const l of u) {
        o = l(a, { data: e, defaultError: o }).message;
      }
      return {
        ...i,
        path: s,
        message: i.message || o
      };
    };
    ie.makeIssue = tg;
    ie.EMPTY_PATH = [];
    function rg(r, e) {
      const t = (0, ie.makeIssue)({
        issueData: e,
        data: r.data,
        path: r.path,
        errorMaps: [
          r.common.contextualErrorMap,
          r.schemaErrorMap,
          (0, Xb.getErrorMap)(),
          eg.default
        ].filter((n) => !!n)
      });
      r.common.issues.push(t);
    }
    ie.addIssueToContext = rg;
    var zn = class {
      constructor() {
        this.value = "valid";
      }
      dirty() {
        if (this.value === "valid")
          this.value = "dirty";
      }
      abort() {
        if (this.value !== "aborted")
          this.value = "aborted";
      }
      static mergeArray(e, t) {
        const n = [];
        for (const i of t) {
          if (i.status === "aborted")
            return ie.INVALID;
          if (i.status === "dirty")
            e.dirty();
          n.push(i.value);
        }
        return { status: e.value, value: n };
      }
      static async mergeObjectAsync(e, t) {
        const n = [];
        for (const i of t) {
          n.push({
            key: await i.key,
            value: await i.value
          });
        }
        return zn.mergeObjectSync(e, n);
      }
      static mergeObjectSync(e, t) {
        const n = {};
        for (const i of t) {
          const { key: s, value: a } = i;
          if (s.status === "aborted")
            return ie.INVALID;
          if (a.status === "aborted")
            return ie.INVALID;
          if (s.status === "dirty")
            e.dirty();
          if (a.status === "dirty")
            e.dirty();
          if (typeof a.value !== "undefined" || i.alwaysSet) {
            n[s.value] = a.value;
          }
        }
        return { status: e.value, value: n };
      }
    };
    ie.ParseStatus = zn;
    ie.INVALID = Object.freeze({
      status: "aborted"
    });
    var ng = (r) => ({ status: "dirty", value: r });
    ie.DIRTY = ng;
    var ig = (r) => ({ status: "valid", value: r });
    ie.OK = ig;
    var sg = (r) => r.status === "aborted";
    ie.isAborted = sg;
    var ag = (r) => r.status === "dirty";
    ie.isDirty = ag;
    var og = (r) => r.status === "valid";
    ie.isValid = og;
    var ug = (r) => typeof Promise !== "undefined" && r instanceof Promise;
    ie.isAsync = ug;
  });

  // node_modules/.pnpm/zod@3.21.4/node_modules/zod/lib/helpers/typeAliases.js
  var qp = N((Dp) => {
    "use strict";
    Object.defineProperty(Dp, "__esModule", { value: true });
  });

  // node_modules/.pnpm/zod@3.21.4/node_modules/zod/lib/helpers/errorUtil.js
  var Up = N((Fn) => {
    "use strict";
    Object.defineProperty(Fn, "__esModule", { value: true });
    Fn.errorUtil = void 0;
    var lg;
    (function(r) {
      r.errToObj = (e) => typeof e === "string" ? { message: e } : e || {};
      r.toString = (e) => typeof e === "string" ? e : e === null || e === void 0 ? void 0 : e.message;
    })(lg = Fn.errorUtil || (Fn.errorUtil = {}));
  });

  // node_modules/.pnpm/zod@3.21.4/node_modules/zod/lib/types.js
  var Zp = N((v) => {
    "use strict";
    Object.defineProperty(v, "__esModule", { value: true });
    v.discriminatedUnion = v.date = v.boolean = v.bigint = v.array = v.any = v.coerce = v.ZodFirstPartyTypeKind = v.late = v.ZodSchema = v.Schema = v.custom = v.ZodPipeline = v.ZodBranded = v.BRAND = v.ZodNaN = v.ZodCatch = v.ZodDefault = v.ZodNullable = v.ZodOptional = v.ZodTransformer = v.ZodEffects = v.ZodPromise = v.ZodNativeEnum = v.ZodEnum = v.ZodLiteral = v.ZodLazy = v.ZodFunction = v.ZodSet = v.ZodMap = v.ZodRecord = v.ZodTuple = v.ZodIntersection = v.ZodDiscriminatedUnion = v.ZodUnion = v.ZodObject = v.ZodArray = v.ZodVoid = v.ZodNever = v.ZodUnknown = v.ZodAny = v.ZodNull = v.ZodUndefined = v.ZodSymbol = v.ZodDate = v.ZodBoolean = v.ZodBigInt = v.ZodNumber = v.ZodString = v.ZodType = void 0;
    v.NEVER = v.void = v.unknown = v.union = v.undefined = v.tuple = v.transformer = v.symbol = v.string = v.strictObject = v.set = v.record = v.promise = v.preprocess = v.pipeline = v.ostring = v.optional = v.onumber = v.oboolean = v.object = v.number = v.nullable = v.null = v.never = v.nativeEnum = v.nan = v.map = v.literal = v.lazy = v.intersection = v.instanceof = v.function = v.enum = v.effect = void 0;
    var as = ss();
    var B = Up();
    var E = eu();
    var q = Un();
    var D = is();
    var Ye = class {
      constructor(e, t, n, i) {
        this._cachedPath = [];
        this.parent = e;
        this.data = t;
        this._path = n;
        this._key = i;
      }
      get path() {
        if (!this._cachedPath.length) {
          if (this._key instanceof Array) {
            this._cachedPath.push(...this._path, ...this._key);
          } else {
            this._cachedPath.push(...this._path, this._key);
          }
        }
        return this._cachedPath;
      }
    };
    var Vp = (r, e) => {
      if ((0, E.isValid)(e)) {
        return { success: true, data: e.value };
      } else {
        if (!r.common.issues.length) {
          throw new Error("Validation failed but no issues detected.");
        }
        return {
          success: false,
          get error() {
            if (this._error)
              return this._error;
            const t = new D.ZodError(r.common.issues);
            this._error = t;
            return this._error;
          }
        };
      }
    };
    function Y(r) {
      if (!r)
        return {};
      const { errorMap: e, invalid_type_error: t, required_error: n, description: i } = r;
      if (e && (t || n)) {
        throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
      }
      if (e)
        return { errorMap: e, description: i };
      const s = (a, o) => {
        if (a.code !== "invalid_type")
          return { message: o.defaultError };
        if (typeof o.data === "undefined") {
          return { message: n !== null && n !== void 0 ? n : o.defaultError };
        }
        return { message: t !== null && t !== void 0 ? t : o.defaultError };
      };
      return { errorMap: s, description: i };
    }
    var W = class {
      constructor(e) {
        this.spa = this.safeParseAsync;
        this._def = e;
        this.parse = this.parse.bind(this);
        this.safeParse = this.safeParse.bind(this);
        this.parseAsync = this.parseAsync.bind(this);
        this.safeParseAsync = this.safeParseAsync.bind(this);
        this.spa = this.spa.bind(this);
        this.refine = this.refine.bind(this);
        this.refinement = this.refinement.bind(this);
        this.superRefine = this.superRefine.bind(this);
        this.optional = this.optional.bind(this);
        this.nullable = this.nullable.bind(this);
        this.nullish = this.nullish.bind(this);
        this.array = this.array.bind(this);
        this.promise = this.promise.bind(this);
        this.or = this.or.bind(this);
        this.and = this.and.bind(this);
        this.transform = this.transform.bind(this);
        this.brand = this.brand.bind(this);
        this.default = this.default.bind(this);
        this.catch = this.catch.bind(this);
        this.describe = this.describe.bind(this);
        this.pipe = this.pipe.bind(this);
        this.isNullable = this.isNullable.bind(this);
        this.isOptional = this.isOptional.bind(this);
      }
      get description() {
        return this._def.description;
      }
      _getType(e) {
        return (0, q.getParsedType)(e.data);
      }
      _getOrReturnCtx(e, t) {
        return t || {
          common: e.parent.common,
          data: e.data,
          parsedType: (0, q.getParsedType)(e.data),
          schemaErrorMap: this._def.errorMap,
          path: e.path,
          parent: e.parent
        };
      }
      _processInputParams(e) {
        return {
          status: new E.ParseStatus(),
          ctx: {
            common: e.parent.common,
            data: e.data,
            parsedType: (0, q.getParsedType)(e.data),
            schemaErrorMap: this._def.errorMap,
            path: e.path,
            parent: e.parent
          }
        };
      }
      _parseSync(e) {
        const t = this._parse(e);
        if ((0, E.isAsync)(t)) {
          throw new Error("Synchronous parse encountered promise.");
        }
        return t;
      }
      _parseAsync(e) {
        const t = this._parse(e);
        return Promise.resolve(t);
      }
      parse(e, t) {
        const n = this.safeParse(e, t);
        if (n.success)
          return n.data;
        throw n.error;
      }
      safeParse(e, t) {
        var n;
        const i = {
          common: {
            issues: [],
            async: (n = t === null || t === void 0 ? void 0 : t.async) !== null && n !== void 0 ? n : false,
            contextualErrorMap: t === null || t === void 0 ? void 0 : t.errorMap
          },
          path: (t === null || t === void 0 ? void 0 : t.path) || [],
          schemaErrorMap: this._def.errorMap,
          parent: null,
          data: e,
          parsedType: (0, q.getParsedType)(e)
        };
        const s = this._parseSync({ data: e, path: i.path, parent: i });
        return Vp(i, s);
      }
      async parseAsync(e, t) {
        const n = await this.safeParseAsync(e, t);
        if (n.success)
          return n.data;
        throw n.error;
      }
      async safeParseAsync(e, t) {
        const n = {
          common: {
            issues: [],
            contextualErrorMap: t === null || t === void 0 ? void 0 : t.errorMap,
            async: true
          },
          path: (t === null || t === void 0 ? void 0 : t.path) || [],
          schemaErrorMap: this._def.errorMap,
          parent: null,
          data: e,
          parsedType: (0, q.getParsedType)(e)
        };
        const i = this._parse({ data: e, path: n.path, parent: n });
        const s = await ((0, E.isAsync)(i) ? i : Promise.resolve(i));
        return Vp(n, s);
      }
      refine(e, t) {
        const n = (i) => {
          if (typeof t === "string" || typeof t === "undefined") {
            return { message: t };
          } else if (typeof t === "function") {
            return t(i);
          } else {
            return t;
          }
        };
        return this._refinement((i, s) => {
          const a = e(i);
          const o = () => s.addIssue({
            code: D.ZodIssueCode.custom,
            ...n(i)
          });
          if (typeof Promise !== "undefined" && a instanceof Promise) {
            return a.then((u) => {
              if (!u) {
                o();
                return false;
              } else {
                return true;
              }
            });
          }
          if (!a) {
            o();
            return false;
          } else {
            return true;
          }
        });
      }
      refinement(e, t) {
        return this._refinement((n, i) => {
          if (!e(n)) {
            i.addIssue(typeof t === "function" ? t(n, i) : t);
            return false;
          } else {
            return true;
          }
        });
      }
      _refinement(e) {
        return new $e({
          schema: this,
          typeName: H.ZodEffects,
          effect: { type: "refinement", refinement: e }
        });
      }
      superRefine(e) {
        return this._refinement(e);
      }
      optional() {
        return st.create(this, this._def);
      }
      nullable() {
        return St.create(this, this._def);
      }
      nullish() {
        return this.nullable().optional();
      }
      array() {
        return Be.create(this, this._def);
      }
      promise() {
        return Ht.create(this, this._def);
      }
      or(e) {
        return cr.create([this, e], this._def);
      }
      and(e) {
        return dr.create(this, e, this._def);
      }
      transform(e) {
        return new $e({
          ...Y(this._def),
          schema: this,
          typeName: H.ZodEffects,
          effect: { type: "transform", transform: e }
        });
      }
      default(e) {
        const t = typeof e === "function" ? e : () => e;
        return new yr({
          ...Y(this._def),
          innerType: this,
          defaultValue: t,
          typeName: H.ZodDefault
        });
      }
      brand() {
        return new us({
          typeName: H.ZodBranded,
          type: this,
          ...Y(this._def)
        });
      }
      catch(e) {
        const t = typeof e === "function" ? e : () => e;
        return new Wr({
          ...Y(this._def),
          innerType: this,
          catchValue: t,
          typeName: H.ZodCatch
        });
      }
      describe(e) {
        const t = this.constructor;
        return new t({
          ...this._def,
          description: e
        });
      }
      pipe(e) {
        return br.create(this, e);
      }
      isOptional() {
        return this.safeParse(void 0).success;
      }
      isNullable() {
        return this.safeParse(null).success;
      }
    };
    v.ZodType = W;
    v.Schema = W;
    v.ZodSchema = W;
    var cg = /^c[^\s-]{8,}$/i;
    var dg = /^[a-z][a-z0-9]*$/;
    var pg = /[0-9A-HJKMNP-TV-Z]{26}/;
    var hg = /^([a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[a-f0-9]{4}-[a-f0-9]{12}|00000000-0000-0000-0000-000000000000)$/i;
    var fg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\])|(\[IPv6:(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))\])|([A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])*(\.[A-Za-z]{2,})+))$/;
    var mg = /^(\p{Extended_Pictographic}|\p{Emoji_Component})+$/u;
    var yg = /^(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))$/;
    var bg = /^(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))$/;
    var gg = (r) => {
      if (r.precision) {
        if (r.offset) {
          return new RegExp(`^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{${r.precision}}(([+-]\\d{2}(:?\\d{2})?)|Z)$`);
        } else {
          return new RegExp(`^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{${r.precision}}Z$`);
        }
      } else if (r.precision === 0) {
        if (r.offset) {
          return new RegExp(`^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(([+-]\\d{2}(:?\\d{2})?)|Z)$`);
        } else {
          return new RegExp(`^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}Z$`);
        }
      } else {
        if (r.offset) {
          return new RegExp(`^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?(([+-]\\d{2}(:?\\d{2})?)|Z)$`);
        } else {
          return new RegExp(`^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?Z$`);
        }
      }
    };
    function wg(r, e) {
      if ((e === "v4" || !e) && yg.test(r)) {
        return true;
      }
      if ((e === "v6" || !e) && bg.test(r)) {
        return true;
      }
      return false;
    }
    var Ke = class extends W {
      constructor() {
        super(...arguments);
        this._regex = (e, t, n) => this.refinement((i) => e.test(i), {
          validation: t,
          code: D.ZodIssueCode.invalid_string,
          ...B.errorUtil.errToObj(n)
        });
        this.nonempty = (e) => this.min(1, B.errorUtil.errToObj(e));
        this.trim = () => new Ke({
          ...this._def,
          checks: [...this._def.checks, { kind: "trim" }]
        });
        this.toLowerCase = () => new Ke({
          ...this._def,
          checks: [...this._def.checks, { kind: "toLowerCase" }]
        });
        this.toUpperCase = () => new Ke({
          ...this._def,
          checks: [...this._def.checks, { kind: "toUpperCase" }]
        });
      }
      _parse(e) {
        if (this._def.coerce) {
          e.data = String(e.data);
        }
        const t = this._getType(e);
        if (t !== q.ZodParsedType.string) {
          const s = this._getOrReturnCtx(e);
          (0, E.addIssueToContext)(s, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.string,
            received: s.parsedType
          });
          return E.INVALID;
        }
        const n = new E.ParseStatus();
        let i = void 0;
        for (const s of this._def.checks) {
          if (s.kind === "min") {
            if (e.data.length < s.value) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                code: D.ZodIssueCode.too_small,
                minimum: s.value,
                type: "string",
                inclusive: true,
                exact: false,
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "max") {
            if (e.data.length > s.value) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                code: D.ZodIssueCode.too_big,
                maximum: s.value,
                type: "string",
                inclusive: true,
                exact: false,
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "length") {
            const a = e.data.length > s.value;
            const o = e.data.length < s.value;
            if (a || o) {
              i = this._getOrReturnCtx(e, i);
              if (a) {
                (0, E.addIssueToContext)(i, {
                  code: D.ZodIssueCode.too_big,
                  maximum: s.value,
                  type: "string",
                  inclusive: true,
                  exact: true,
                  message: s.message
                });
              } else if (o) {
                (0, E.addIssueToContext)(i, {
                  code: D.ZodIssueCode.too_small,
                  minimum: s.value,
                  type: "string",
                  inclusive: true,
                  exact: true,
                  message: s.message
                });
              }
              n.dirty();
            }
          } else if (s.kind === "email") {
            if (!fg.test(e.data)) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                validation: "email",
                code: D.ZodIssueCode.invalid_string,
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "emoji") {
            if (!mg.test(e.data)) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                validation: "emoji",
                code: D.ZodIssueCode.invalid_string,
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "uuid") {
            if (!hg.test(e.data)) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                validation: "uuid",
                code: D.ZodIssueCode.invalid_string,
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "cuid") {
            if (!cg.test(e.data)) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                validation: "cuid",
                code: D.ZodIssueCode.invalid_string,
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "cuid2") {
            if (!dg.test(e.data)) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                validation: "cuid2",
                code: D.ZodIssueCode.invalid_string,
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "ulid") {
            if (!pg.test(e.data)) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                validation: "ulid",
                code: D.ZodIssueCode.invalid_string,
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "url") {
            try {
              new URL(e.data);
            } catch (a) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                validation: "url",
                code: D.ZodIssueCode.invalid_string,
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "regex") {
            s.regex.lastIndex = 0;
            const a = s.regex.test(e.data);
            if (!a) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                validation: "regex",
                code: D.ZodIssueCode.invalid_string,
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "trim") {
            e.data = e.data.trim();
          } else if (s.kind === "includes") {
            if (!e.data.includes(s.value, s.position)) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                code: D.ZodIssueCode.invalid_string,
                validation: { includes: s.value, position: s.position },
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "toLowerCase") {
            e.data = e.data.toLowerCase();
          } else if (s.kind === "toUpperCase") {
            e.data = e.data.toUpperCase();
          } else if (s.kind === "startsWith") {
            if (!e.data.startsWith(s.value)) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                code: D.ZodIssueCode.invalid_string,
                validation: { startsWith: s.value },
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "endsWith") {
            if (!e.data.endsWith(s.value)) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                code: D.ZodIssueCode.invalid_string,
                validation: { endsWith: s.value },
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "datetime") {
            const a = gg(s);
            if (!a.test(e.data)) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                code: D.ZodIssueCode.invalid_string,
                validation: "datetime",
                message: s.message
              });
              n.dirty();
            }
          } else if (s.kind === "ip") {
            if (!wg(e.data, s.version)) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                validation: "ip",
                code: D.ZodIssueCode.invalid_string,
                message: s.message
              });
              n.dirty();
            }
          } else {
            q.util.assertNever(s);
          }
        }
        return { status: n.value, value: e.data };
      }
      _addCheck(e) {
        return new Ke({
          ...this._def,
          checks: [...this._def.checks, e]
        });
      }
      email(e) {
        return this._addCheck({ kind: "email", ...B.errorUtil.errToObj(e) });
      }
      url(e) {
        return this._addCheck({ kind: "url", ...B.errorUtil.errToObj(e) });
      }
      emoji(e) {
        return this._addCheck({ kind: "emoji", ...B.errorUtil.errToObj(e) });
      }
      uuid(e) {
        return this._addCheck({ kind: "uuid", ...B.errorUtil.errToObj(e) });
      }
      cuid(e) {
        return this._addCheck({ kind: "cuid", ...B.errorUtil.errToObj(e) });
      }
      cuid2(e) {
        return this._addCheck({ kind: "cuid2", ...B.errorUtil.errToObj(e) });
      }
      ulid(e) {
        return this._addCheck({ kind: "ulid", ...B.errorUtil.errToObj(e) });
      }
      ip(e) {
        return this._addCheck({ kind: "ip", ...B.errorUtil.errToObj(e) });
      }
      datetime(e) {
        var t;
        if (typeof e === "string") {
          return this._addCheck({
            kind: "datetime",
            precision: null,
            offset: false,
            message: e
          });
        }
        return this._addCheck({
          kind: "datetime",
          precision: typeof (e === null || e === void 0 ? void 0 : e.precision) === "undefined" ? null : e === null || e === void 0 ? void 0 : e.precision,
          offset: (t = e === null || e === void 0 ? void 0 : e.offset) !== null && t !== void 0 ? t : false,
          ...B.errorUtil.errToObj(e === null || e === void 0 ? void 0 : e.message)
        });
      }
      regex(e, t) {
        return this._addCheck({
          kind: "regex",
          regex: e,
          ...B.errorUtil.errToObj(t)
        });
      }
      includes(e, t) {
        return this._addCheck({
          kind: "includes",
          value: e,
          position: t === null || t === void 0 ? void 0 : t.position,
          ...B.errorUtil.errToObj(t === null || t === void 0 ? void 0 : t.message)
        });
      }
      startsWith(e, t) {
        return this._addCheck({
          kind: "startsWith",
          value: e,
          ...B.errorUtil.errToObj(t)
        });
      }
      endsWith(e, t) {
        return this._addCheck({
          kind: "endsWith",
          value: e,
          ...B.errorUtil.errToObj(t)
        });
      }
      min(e, t) {
        return this._addCheck({
          kind: "min",
          value: e,
          ...B.errorUtil.errToObj(t)
        });
      }
      max(e, t) {
        return this._addCheck({
          kind: "max",
          value: e,
          ...B.errorUtil.errToObj(t)
        });
      }
      length(e, t) {
        return this._addCheck({
          kind: "length",
          value: e,
          ...B.errorUtil.errToObj(t)
        });
      }
      get isDatetime() {
        return !!this._def.checks.find((e) => e.kind === "datetime");
      }
      get isEmail() {
        return !!this._def.checks.find((e) => e.kind === "email");
      }
      get isURL() {
        return !!this._def.checks.find((e) => e.kind === "url");
      }
      get isEmoji() {
        return !!this._def.checks.find((e) => e.kind === "emoji");
      }
      get isUUID() {
        return !!this._def.checks.find((e) => e.kind === "uuid");
      }
      get isCUID() {
        return !!this._def.checks.find((e) => e.kind === "cuid");
      }
      get isCUID2() {
        return !!this._def.checks.find((e) => e.kind === "cuid2");
      }
      get isULID() {
        return !!this._def.checks.find((e) => e.kind === "ulid");
      }
      get isIP() {
        return !!this._def.checks.find((e) => e.kind === "ip");
      }
      get minLength() {
        let e = null;
        for (const t of this._def.checks) {
          if (t.kind === "min") {
            if (e === null || t.value > e)
              e = t.value;
          }
        }
        return e;
      }
      get maxLength() {
        let e = null;
        for (const t of this._def.checks) {
          if (t.kind === "max") {
            if (e === null || t.value < e)
              e = t.value;
          }
        }
        return e;
      }
    };
    v.ZodString = Ke;
    Ke.create = (r) => {
      var e;
      return new Ke({
        checks: [],
        typeName: H.ZodString,
        coerce: (e = r === null || r === void 0 ? void 0 : r.coerce) !== null && e !== void 0 ? e : false,
        ...Y(r)
      });
    };
    function _g(r, e) {
      const t = (r.toString().split(".")[1] || "").length;
      const n = (e.toString().split(".")[1] || "").length;
      const i = t > n ? t : n;
      const s = parseInt(r.toFixed(i).replace(".", ""));
      const a = parseInt(e.toFixed(i).replace(".", ""));
      return s % a / Math.pow(10, i);
    }
    var ht = class extends W {
      constructor() {
        super(...arguments);
        this.min = this.gte;
        this.max = this.lte;
        this.step = this.multipleOf;
      }
      _parse(e) {
        if (this._def.coerce) {
          e.data = Number(e.data);
        }
        const t = this._getType(e);
        if (t !== q.ZodParsedType.number) {
          const s = this._getOrReturnCtx(e);
          (0, E.addIssueToContext)(s, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.number,
            received: s.parsedType
          });
          return E.INVALID;
        }
        let n = void 0;
        const i = new E.ParseStatus();
        for (const s of this._def.checks) {
          if (s.kind === "int") {
            if (!q.util.isInteger(e.data)) {
              n = this._getOrReturnCtx(e, n);
              (0, E.addIssueToContext)(n, {
                code: D.ZodIssueCode.invalid_type,
                expected: "integer",
                received: "float",
                message: s.message
              });
              i.dirty();
            }
          } else if (s.kind === "min") {
            const a = s.inclusive ? e.data < s.value : e.data <= s.value;
            if (a) {
              n = this._getOrReturnCtx(e, n);
              (0, E.addIssueToContext)(n, {
                code: D.ZodIssueCode.too_small,
                minimum: s.value,
                type: "number",
                inclusive: s.inclusive,
                exact: false,
                message: s.message
              });
              i.dirty();
            }
          } else if (s.kind === "max") {
            const a = s.inclusive ? e.data > s.value : e.data >= s.value;
            if (a) {
              n = this._getOrReturnCtx(e, n);
              (0, E.addIssueToContext)(n, {
                code: D.ZodIssueCode.too_big,
                maximum: s.value,
                type: "number",
                inclusive: s.inclusive,
                exact: false,
                message: s.message
              });
              i.dirty();
            }
          } else if (s.kind === "multipleOf") {
            if (_g(e.data, s.value) !== 0) {
              n = this._getOrReturnCtx(e, n);
              (0, E.addIssueToContext)(n, {
                code: D.ZodIssueCode.not_multiple_of,
                multipleOf: s.value,
                message: s.message
              });
              i.dirty();
            }
          } else if (s.kind === "finite") {
            if (!Number.isFinite(e.data)) {
              n = this._getOrReturnCtx(e, n);
              (0, E.addIssueToContext)(n, {
                code: D.ZodIssueCode.not_finite,
                message: s.message
              });
              i.dirty();
            }
          } else {
            q.util.assertNever(s);
          }
        }
        return { status: i.value, value: e.data };
      }
      gte(e, t) {
        return this.setLimit("min", e, true, B.errorUtil.toString(t));
      }
      gt(e, t) {
        return this.setLimit("min", e, false, B.errorUtil.toString(t));
      }
      lte(e, t) {
        return this.setLimit("max", e, true, B.errorUtil.toString(t));
      }
      lt(e, t) {
        return this.setLimit("max", e, false, B.errorUtil.toString(t));
      }
      setLimit(e, t, n, i) {
        return new ht({
          ...this._def,
          checks: [
            ...this._def.checks,
            {
              kind: e,
              value: t,
              inclusive: n,
              message: B.errorUtil.toString(i)
            }
          ]
        });
      }
      _addCheck(e) {
        return new ht({
          ...this._def,
          checks: [...this._def.checks, e]
        });
      }
      int(e) {
        return this._addCheck({
          kind: "int",
          message: B.errorUtil.toString(e)
        });
      }
      positive(e) {
        return this._addCheck({
          kind: "min",
          value: 0,
          inclusive: false,
          message: B.errorUtil.toString(e)
        });
      }
      negative(e) {
        return this._addCheck({
          kind: "max",
          value: 0,
          inclusive: false,
          message: B.errorUtil.toString(e)
        });
      }
      nonpositive(e) {
        return this._addCheck({
          kind: "max",
          value: 0,
          inclusive: true,
          message: B.errorUtil.toString(e)
        });
      }
      nonnegative(e) {
        return this._addCheck({
          kind: "min",
          value: 0,
          inclusive: true,
          message: B.errorUtil.toString(e)
        });
      }
      multipleOf(e, t) {
        return this._addCheck({
          kind: "multipleOf",
          value: e,
          message: B.errorUtil.toString(t)
        });
      }
      finite(e) {
        return this._addCheck({
          kind: "finite",
          message: B.errorUtil.toString(e)
        });
      }
      safe(e) {
        return this._addCheck({
          kind: "min",
          inclusive: true,
          value: Number.MIN_SAFE_INTEGER,
          message: B.errorUtil.toString(e)
        })._addCheck({
          kind: "max",
          inclusive: true,
          value: Number.MAX_SAFE_INTEGER,
          message: B.errorUtil.toString(e)
        });
      }
      get minValue() {
        let e = null;
        for (const t of this._def.checks) {
          if (t.kind === "min") {
            if (e === null || t.value > e)
              e = t.value;
          }
        }
        return e;
      }
      get maxValue() {
        let e = null;
        for (const t of this._def.checks) {
          if (t.kind === "max") {
            if (e === null || t.value < e)
              e = t.value;
          }
        }
        return e;
      }
      get isInt() {
        return !!this._def.checks.find((e) => e.kind === "int" || e.kind === "multipleOf" && q.util.isInteger(e.value));
      }
      get isFinite() {
        let e = null, t = null;
        for (const n of this._def.checks) {
          if (n.kind === "finite" || n.kind === "int" || n.kind === "multipleOf") {
            return true;
          } else if (n.kind === "min") {
            if (t === null || n.value > t)
              t = n.value;
          } else if (n.kind === "max") {
            if (e === null || n.value < e)
              e = n.value;
          }
        }
        return Number.isFinite(t) && Number.isFinite(e);
      }
    };
    v.ZodNumber = ht;
    ht.create = (r) => {
      return new ht({
        checks: [],
        typeName: H.ZodNumber,
        coerce: (r === null || r === void 0 ? void 0 : r.coerce) || false,
        ...Y(r)
      });
    };
    var ft = class extends W {
      constructor() {
        super(...arguments);
        this.min = this.gte;
        this.max = this.lte;
      }
      _parse(e) {
        if (this._def.coerce) {
          e.data = BigInt(e.data);
        }
        const t = this._getType(e);
        if (t !== q.ZodParsedType.bigint) {
          const s = this._getOrReturnCtx(e);
          (0, E.addIssueToContext)(s, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.bigint,
            received: s.parsedType
          });
          return E.INVALID;
        }
        let n = void 0;
        const i = new E.ParseStatus();
        for (const s of this._def.checks) {
          if (s.kind === "min") {
            const a = s.inclusive ? e.data < s.value : e.data <= s.value;
            if (a) {
              n = this._getOrReturnCtx(e, n);
              (0, E.addIssueToContext)(n, {
                code: D.ZodIssueCode.too_small,
                type: "bigint",
                minimum: s.value,
                inclusive: s.inclusive,
                message: s.message
              });
              i.dirty();
            }
          } else if (s.kind === "max") {
            const a = s.inclusive ? e.data > s.value : e.data >= s.value;
            if (a) {
              n = this._getOrReturnCtx(e, n);
              (0, E.addIssueToContext)(n, {
                code: D.ZodIssueCode.too_big,
                type: "bigint",
                maximum: s.value,
                inclusive: s.inclusive,
                message: s.message
              });
              i.dirty();
            }
          } else if (s.kind === "multipleOf") {
            if (e.data % s.value !== BigInt(0)) {
              n = this._getOrReturnCtx(e, n);
              (0, E.addIssueToContext)(n, {
                code: D.ZodIssueCode.not_multiple_of,
                multipleOf: s.value,
                message: s.message
              });
              i.dirty();
            }
          } else {
            q.util.assertNever(s);
          }
        }
        return { status: i.value, value: e.data };
      }
      gte(e, t) {
        return this.setLimit("min", e, true, B.errorUtil.toString(t));
      }
      gt(e, t) {
        return this.setLimit("min", e, false, B.errorUtil.toString(t));
      }
      lte(e, t) {
        return this.setLimit("max", e, true, B.errorUtil.toString(t));
      }
      lt(e, t) {
        return this.setLimit("max", e, false, B.errorUtil.toString(t));
      }
      setLimit(e, t, n, i) {
        return new ft({
          ...this._def,
          checks: [
            ...this._def.checks,
            {
              kind: e,
              value: t,
              inclusive: n,
              message: B.errorUtil.toString(i)
            }
          ]
        });
      }
      _addCheck(e) {
        return new ft({
          ...this._def,
          checks: [...this._def.checks, e]
        });
      }
      positive(e) {
        return this._addCheck({
          kind: "min",
          value: BigInt(0),
          inclusive: false,
          message: B.errorUtil.toString(e)
        });
      }
      negative(e) {
        return this._addCheck({
          kind: "max",
          value: BigInt(0),
          inclusive: false,
          message: B.errorUtil.toString(e)
        });
      }
      nonpositive(e) {
        return this._addCheck({
          kind: "max",
          value: BigInt(0),
          inclusive: true,
          message: B.errorUtil.toString(e)
        });
      }
      nonnegative(e) {
        return this._addCheck({
          kind: "min",
          value: BigInt(0),
          inclusive: true,
          message: B.errorUtil.toString(e)
        });
      }
      multipleOf(e, t) {
        return this._addCheck({
          kind: "multipleOf",
          value: e,
          message: B.errorUtil.toString(t)
        });
      }
      get minValue() {
        let e = null;
        for (const t of this._def.checks) {
          if (t.kind === "min") {
            if (e === null || t.value > e)
              e = t.value;
          }
        }
        return e;
      }
      get maxValue() {
        let e = null;
        for (const t of this._def.checks) {
          if (t.kind === "max") {
            if (e === null || t.value < e)
              e = t.value;
          }
        }
        return e;
      }
    };
    v.ZodBigInt = ft;
    ft.create = (r) => {
      var e;
      return new ft({
        checks: [],
        typeName: H.ZodBigInt,
        coerce: (e = r === null || r === void 0 ? void 0 : r.coerce) !== null && e !== void 0 ? e : false,
        ...Y(r)
      });
    };
    var or = class extends W {
      _parse(e) {
        if (this._def.coerce) {
          e.data = Boolean(e.data);
        }
        const t = this._getType(e);
        if (t !== q.ZodParsedType.boolean) {
          const n = this._getOrReturnCtx(e);
          (0, E.addIssueToContext)(n, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.boolean,
            received: n.parsedType
          });
          return E.INVALID;
        }
        return (0, E.OK)(e.data);
      }
    };
    v.ZodBoolean = or;
    or.create = (r) => {
      return new or({
        typeName: H.ZodBoolean,
        coerce: (r === null || r === void 0 ? void 0 : r.coerce) || false,
        ...Y(r)
      });
    };
    var It = class extends W {
      _parse(e) {
        if (this._def.coerce) {
          e.data = new Date(e.data);
        }
        const t = this._getType(e);
        if (t !== q.ZodParsedType.date) {
          const s = this._getOrReturnCtx(e);
          (0, E.addIssueToContext)(s, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.date,
            received: s.parsedType
          });
          return E.INVALID;
        }
        if (isNaN(e.data.getTime())) {
          const s = this._getOrReturnCtx(e);
          (0, E.addIssueToContext)(s, {
            code: D.ZodIssueCode.invalid_date
          });
          return E.INVALID;
        }
        const n = new E.ParseStatus();
        let i = void 0;
        for (const s of this._def.checks) {
          if (s.kind === "min") {
            if (e.data.getTime() < s.value) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                code: D.ZodIssueCode.too_small,
                message: s.message,
                inclusive: true,
                exact: false,
                minimum: s.value,
                type: "date"
              });
              n.dirty();
            }
          } else if (s.kind === "max") {
            if (e.data.getTime() > s.value) {
              i = this._getOrReturnCtx(e, i);
              (0, E.addIssueToContext)(i, {
                code: D.ZodIssueCode.too_big,
                message: s.message,
                inclusive: true,
                exact: false,
                maximum: s.value,
                type: "date"
              });
              n.dirty();
            }
          } else {
            q.util.assertNever(s);
          }
        }
        return {
          status: n.value,
          value: new Date(e.data.getTime())
        };
      }
      _addCheck(e) {
        return new It({
          ...this._def,
          checks: [...this._def.checks, e]
        });
      }
      min(e, t) {
        return this._addCheck({
          kind: "min",
          value: e.getTime(),
          message: B.errorUtil.toString(t)
        });
      }
      max(e, t) {
        return this._addCheck({
          kind: "max",
          value: e.getTime(),
          message: B.errorUtil.toString(t)
        });
      }
      get minDate() {
        let e = null;
        for (const t of this._def.checks) {
          if (t.kind === "min") {
            if (e === null || t.value > e)
              e = t.value;
          }
        }
        return e != null ? new Date(e) : null;
      }
      get maxDate() {
        let e = null;
        for (const t of this._def.checks) {
          if (t.kind === "max") {
            if (e === null || t.value < e)
              e = t.value;
          }
        }
        return e != null ? new Date(e) : null;
      }
    };
    v.ZodDate = It;
    It.create = (r) => {
      return new It({
        checks: [],
        coerce: (r === null || r === void 0 ? void 0 : r.coerce) || false,
        typeName: H.ZodDate,
        ...Y(r)
      });
    };
    var Hr = class extends W {
      _parse(e) {
        const t = this._getType(e);
        if (t !== q.ZodParsedType.symbol) {
          const n = this._getOrReturnCtx(e);
          (0, E.addIssueToContext)(n, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.symbol,
            received: n.parsedType
          });
          return E.INVALID;
        }
        return (0, E.OK)(e.data);
      }
    };
    v.ZodSymbol = Hr;
    Hr.create = (r) => {
      return new Hr({
        typeName: H.ZodSymbol,
        ...Y(r)
      });
    };
    var ur = class extends W {
      _parse(e) {
        const t = this._getType(e);
        if (t !== q.ZodParsedType.undefined) {
          const n = this._getOrReturnCtx(e);
          (0, E.addIssueToContext)(n, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.undefined,
            received: n.parsedType
          });
          return E.INVALID;
        }
        return (0, E.OK)(e.data);
      }
    };
    v.ZodUndefined = ur;
    ur.create = (r) => {
      return new ur({
        typeName: H.ZodUndefined,
        ...Y(r)
      });
    };
    var lr = class extends W {
      _parse(e) {
        const t = this._getType(e);
        if (t !== q.ZodParsedType.null) {
          const n = this._getOrReturnCtx(e);
          (0, E.addIssueToContext)(n, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.null,
            received: n.parsedType
          });
          return E.INVALID;
        }
        return (0, E.OK)(e.data);
      }
    };
    v.ZodNull = lr;
    lr.create = (r) => {
      return new lr({
        typeName: H.ZodNull,
        ...Y(r)
      });
    };
    var Zt = class extends W {
      constructor() {
        super(...arguments);
        this._any = true;
      }
      _parse(e) {
        return (0, E.OK)(e.data);
      }
    };
    v.ZodAny = Zt;
    Zt.create = (r) => {
      return new Zt({
        typeName: H.ZodAny,
        ...Y(r)
      });
    };
    var Tt = class extends W {
      constructor() {
        super(...arguments);
        this._unknown = true;
      }
      _parse(e) {
        return (0, E.OK)(e.data);
      }
    };
    v.ZodUnknown = Tt;
    Tt.create = (r) => {
      return new Tt({
        typeName: H.ZodUnknown,
        ...Y(r)
      });
    };
    var at = class extends W {
      _parse(e) {
        const t = this._getOrReturnCtx(e);
        (0, E.addIssueToContext)(t, {
          code: D.ZodIssueCode.invalid_type,
          expected: q.ZodParsedType.never,
          received: t.parsedType
        });
        return E.INVALID;
      }
    };
    v.ZodNever = at;
    at.create = (r) => {
      return new at({
        typeName: H.ZodNever,
        ...Y(r)
      });
    };
    var Qr = class extends W {
      _parse(e) {
        const t = this._getType(e);
        if (t !== q.ZodParsedType.undefined) {
          const n = this._getOrReturnCtx(e);
          (0, E.addIssueToContext)(n, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.void,
            received: n.parsedType
          });
          return E.INVALID;
        }
        return (0, E.OK)(e.data);
      }
    };
    v.ZodVoid = Qr;
    Qr.create = (r) => {
      return new Qr({
        typeName: H.ZodVoid,
        ...Y(r)
      });
    };
    var Be = class extends W {
      _parse(e) {
        const { ctx: t, status: n } = this._processInputParams(e);
        const i = this._def;
        if (t.parsedType !== q.ZodParsedType.array) {
          (0, E.addIssueToContext)(t, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.array,
            received: t.parsedType
          });
          return E.INVALID;
        }
        if (i.exactLength !== null) {
          const a = t.data.length > i.exactLength.value;
          const o = t.data.length < i.exactLength.value;
          if (a || o) {
            (0, E.addIssueToContext)(t, {
              code: a ? D.ZodIssueCode.too_big : D.ZodIssueCode.too_small,
              minimum: o ? i.exactLength.value : void 0,
              maximum: a ? i.exactLength.value : void 0,
              type: "array",
              inclusive: true,
              exact: true,
              message: i.exactLength.message
            });
            n.dirty();
          }
        }
        if (i.minLength !== null) {
          if (t.data.length < i.minLength.value) {
            (0, E.addIssueToContext)(t, {
              code: D.ZodIssueCode.too_small,
              minimum: i.minLength.value,
              type: "array",
              inclusive: true,
              exact: false,
              message: i.minLength.message
            });
            n.dirty();
          }
        }
        if (i.maxLength !== null) {
          if (t.data.length > i.maxLength.value) {
            (0, E.addIssueToContext)(t, {
              code: D.ZodIssueCode.too_big,
              maximum: i.maxLength.value,
              type: "array",
              inclusive: true,
              exact: false,
              message: i.maxLength.message
            });
            n.dirty();
          }
        }
        if (t.common.async) {
          return Promise.all([...t.data].map((a, o) => {
            return i.type._parseAsync(new Ye(t, a, t.path, o));
          })).then((a) => {
            return E.ParseStatus.mergeArray(n, a);
          });
        }
        const s = [...t.data].map((a, o) => {
          return i.type._parseSync(new Ye(t, a, t.path, o));
        });
        return E.ParseStatus.mergeArray(n, s);
      }
      get element() {
        return this._def.type;
      }
      min(e, t) {
        return new Be({
          ...this._def,
          minLength: { value: e, message: B.errorUtil.toString(t) }
        });
      }
      max(e, t) {
        return new Be({
          ...this._def,
          maxLength: { value: e, message: B.errorUtil.toString(t) }
        });
      }
      length(e, t) {
        return new Be({
          ...this._def,
          exactLength: { value: e, message: B.errorUtil.toString(t) }
        });
      }
      nonempty(e) {
        return this.min(1, e);
      }
    };
    v.ZodArray = Be;
    Be.create = (r, e) => {
      return new Be({
        type: r,
        minLength: null,
        maxLength: null,
        exactLength: null,
        typeName: H.ZodArray,
        ...Y(e)
      });
    };
    function Zr(r) {
      if (r instanceof ce) {
        const e = {};
        for (const t in r.shape) {
          const n = r.shape[t];
          e[t] = st.create(Zr(n));
        }
        return new ce({
          ...r._def,
          shape: () => e
        });
      } else if (r instanceof Be) {
        return new Be({
          ...r._def,
          type: Zr(r.element)
        });
      } else if (r instanceof st) {
        return st.create(Zr(r.unwrap()));
      } else if (r instanceof St) {
        return St.create(Zr(r.unwrap()));
      } else if (r instanceof We) {
        return We.create(r.items.map((e) => Zr(e)));
      } else {
        return r;
      }
    }
    var ce = class extends W {
      constructor() {
        super(...arguments);
        this._cached = null;
        this.nonstrict = this.passthrough;
        this.augment = this.extend;
      }
      _getCached() {
        if (this._cached !== null)
          return this._cached;
        const e = this._def.shape();
        const t = q.util.objectKeys(e);
        return this._cached = { shape: e, keys: t };
      }
      _parse(e) {
        const t = this._getType(e);
        if (t !== q.ZodParsedType.object) {
          const l = this._getOrReturnCtx(e);
          (0, E.addIssueToContext)(l, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.object,
            received: l.parsedType
          });
          return E.INVALID;
        }
        const { status: n, ctx: i } = this._processInputParams(e);
        const { shape: s, keys: a } = this._getCached();
        const o = [];
        if (!(this._def.catchall instanceof at && this._def.unknownKeys === "strip")) {
          for (const l in i.data) {
            if (!a.includes(l)) {
              o.push(l);
            }
          }
        }
        const u = [];
        for (const l of a) {
          const c = s[l];
          const b = i.data[l];
          u.push({
            key: { status: "valid", value: l },
            value: c._parse(new Ye(i, b, i.path, l)),
            alwaysSet: l in i.data
          });
        }
        if (this._def.catchall instanceof at) {
          const l = this._def.unknownKeys;
          if (l === "passthrough") {
            for (const c of o) {
              u.push({
                key: { status: "valid", value: c },
                value: { status: "valid", value: i.data[c] }
              });
            }
          } else if (l === "strict") {
            if (o.length > 0) {
              (0, E.addIssueToContext)(i, {
                code: D.ZodIssueCode.unrecognized_keys,
                keys: o
              });
              n.dirty();
            }
          } else if (l === "strip") {
          } else {
            throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
          }
        } else {
          const l = this._def.catchall;
          for (const c of o) {
            const b = i.data[c];
            u.push({
              key: { status: "valid", value: c },
              value: l._parse(new Ye(i, b, i.path, c)),
              alwaysSet: c in i.data
            });
          }
        }
        if (i.common.async) {
          return Promise.resolve().then(async () => {
            const l = [];
            for (const c of u) {
              const b = await c.key;
              l.push({
                key: b,
                value: await c.value,
                alwaysSet: c.alwaysSet
              });
            }
            return l;
          }).then((l) => {
            return E.ParseStatus.mergeObjectSync(n, l);
          });
        } else {
          return E.ParseStatus.mergeObjectSync(n, u);
        }
      }
      get shape() {
        return this._def.shape();
      }
      strict(e) {
        B.errorUtil.errToObj;
        return new ce({
          ...this._def,
          unknownKeys: "strict",
          ...e !== void 0 ? {
            errorMap: (t, n) => {
              var i, s, a, o;
              const u = (a = (s = (i = this._def).errorMap) === null || s === void 0 ? void 0 : s.call(i, t, n).message) !== null && a !== void 0 ? a : n.defaultError;
              if (t.code === "unrecognized_keys")
                return {
                  message: (o = B.errorUtil.errToObj(e).message) !== null && o !== void 0 ? o : u
                };
              return {
                message: u
              };
            }
          } : {}
        });
      }
      strip() {
        return new ce({
          ...this._def,
          unknownKeys: "strip"
        });
      }
      passthrough() {
        return new ce({
          ...this._def,
          unknownKeys: "passthrough"
        });
      }
      extend(e) {
        return new ce({
          ...this._def,
          shape: () => ({
            ...this._def.shape(),
            ...e
          })
        });
      }
      merge(e) {
        const t = new ce({
          unknownKeys: e._def.unknownKeys,
          catchall: e._def.catchall,
          shape: () => ({
            ...this._def.shape(),
            ...e._def.shape()
          }),
          typeName: H.ZodObject
        });
        return t;
      }
      setKey(e, t) {
        return this.augment({ [e]: t });
      }
      catchall(e) {
        return new ce({
          ...this._def,
          catchall: e
        });
      }
      pick(e) {
        const t = {};
        q.util.objectKeys(e).forEach((n) => {
          if (e[n] && this.shape[n]) {
            t[n] = this.shape[n];
          }
        });
        return new ce({
          ...this._def,
          shape: () => t
        });
      }
      omit(e) {
        const t = {};
        q.util.objectKeys(this.shape).forEach((n) => {
          if (!e[n]) {
            t[n] = this.shape[n];
          }
        });
        return new ce({
          ...this._def,
          shape: () => t
        });
      }
      deepPartial() {
        return Zr(this);
      }
      partial(e) {
        const t = {};
        q.util.objectKeys(this.shape).forEach((n) => {
          const i = this.shape[n];
          if (e && !e[n]) {
            t[n] = i;
          } else {
            t[n] = i.optional();
          }
        });
        return new ce({
          ...this._def,
          shape: () => t
        });
      }
      required(e) {
        const t = {};
        q.util.objectKeys(this.shape).forEach((n) => {
          if (e && !e[n]) {
            t[n] = this.shape[n];
          } else {
            const i = this.shape[n];
            let s = i;
            while (s instanceof st) {
              s = s._def.innerType;
            }
            t[n] = s;
          }
        });
        return new ce({
          ...this._def,
          shape: () => t
        });
      }
      keyof() {
        return zp(q.util.objectKeys(this.shape));
      }
    };
    v.ZodObject = ce;
    ce.create = (r, e) => {
      return new ce({
        shape: () => r,
        unknownKeys: "strip",
        catchall: at.create(),
        typeName: H.ZodObject,
        ...Y(e)
      });
    };
    ce.strictCreate = (r, e) => {
      return new ce({
        shape: () => r,
        unknownKeys: "strict",
        catchall: at.create(),
        typeName: H.ZodObject,
        ...Y(e)
      });
    };
    ce.lazycreate = (r, e) => {
      return new ce({
        shape: r,
        unknownKeys: "strip",
        catchall: at.create(),
        typeName: H.ZodObject,
        ...Y(e)
      });
    };
    var cr = class extends W {
      _parse(e) {
        const { ctx: t } = this._processInputParams(e);
        const n = this._def.options;
        function i(s) {
          for (const o of s) {
            if (o.result.status === "valid") {
              return o.result;
            }
          }
          for (const o of s) {
            if (o.result.status === "dirty") {
              t.common.issues.push(...o.ctx.common.issues);
              return o.result;
            }
          }
          const a = s.map((o) => new D.ZodError(o.ctx.common.issues));
          (0, E.addIssueToContext)(t, {
            code: D.ZodIssueCode.invalid_union,
            unionErrors: a
          });
          return E.INVALID;
        }
        if (t.common.async) {
          return Promise.all(n.map(async (s) => {
            const a = {
              ...t,
              common: {
                ...t.common,
                issues: []
              },
              parent: null
            };
            return {
              result: await s._parseAsync({
                data: t.data,
                path: t.path,
                parent: a
              }),
              ctx: a
            };
          })).then(i);
        } else {
          let s = void 0;
          const a = [];
          for (const u of n) {
            const l = {
              ...t,
              common: {
                ...t.common,
                issues: []
              },
              parent: null
            };
            const c = u._parseSync({
              data: t.data,
              path: t.path,
              parent: l
            });
            if (c.status === "valid") {
              return c;
            } else if (c.status === "dirty" && !s) {
              s = { result: c, ctx: l };
            }
            if (l.common.issues.length) {
              a.push(l.common.issues);
            }
          }
          if (s) {
            t.common.issues.push(...s.ctx.common.issues);
            return s.result;
          }
          const o = a.map((u) => new D.ZodError(u));
          (0, E.addIssueToContext)(t, {
            code: D.ZodIssueCode.invalid_union,
            unionErrors: o
          });
          return E.INVALID;
        }
      }
      get options() {
        return this._def.options;
      }
    };
    v.ZodUnion = cr;
    cr.create = (r, e) => {
      return new cr({
        options: r,
        typeName: H.ZodUnion,
        ...Y(e)
      });
    };
    var os = (r) => {
      if (r instanceof hr) {
        return os(r.schema);
      } else if (r instanceof $e) {
        return os(r.innerType());
      } else if (r instanceof fr) {
        return [r.value];
      } else if (r instanceof mt) {
        return r.options;
      } else if (r instanceof mr) {
        return Object.keys(r.enum);
      } else if (r instanceof yr) {
        return os(r._def.innerType);
      } else if (r instanceof ur) {
        return [void 0];
      } else if (r instanceof lr) {
        return [null];
      } else {
        return null;
      }
    };
    var Jr = class extends W {
      _parse(e) {
        const { ctx: t } = this._processInputParams(e);
        if (t.parsedType !== q.ZodParsedType.object) {
          (0, E.addIssueToContext)(t, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.object,
            received: t.parsedType
          });
          return E.INVALID;
        }
        const n = this.discriminator;
        const i = t.data[n];
        const s = this.optionsMap.get(i);
        if (!s) {
          (0, E.addIssueToContext)(t, {
            code: D.ZodIssueCode.invalid_union_discriminator,
            options: Array.from(this.optionsMap.keys()),
            path: [n]
          });
          return E.INVALID;
        }
        if (t.common.async) {
          return s._parseAsync({
            data: t.data,
            path: t.path,
            parent: t
          });
        } else {
          return s._parseSync({
            data: t.data,
            path: t.path,
            parent: t
          });
        }
      }
      get discriminator() {
        return this._def.discriminator;
      }
      get options() {
        return this._def.options;
      }
      get optionsMap() {
        return this._def.optionsMap;
      }
      static create(e, t, n) {
        const i = /* @__PURE__ */ new Map();
        for (const s of t) {
          const a = os(s.shape[e]);
          if (!a) {
            throw new Error(`A discriminator value for key \`${e}\` could not be extracted from all schema options`);
          }
          for (const o of a) {
            if (i.has(o)) {
              throw new Error(`Discriminator property ${String(e)} has duplicate value ${String(o)}`);
            }
            i.set(o, s);
          }
        }
        return new Jr({
          typeName: H.ZodDiscriminatedUnion,
          discriminator: e,
          options: t,
          optionsMap: i,
          ...Y(n)
        });
      }
    };
    v.ZodDiscriminatedUnion = Jr;
    function tu(r, e) {
      const t = (0, q.getParsedType)(r);
      const n = (0, q.getParsedType)(e);
      if (r === e) {
        return { valid: true, data: r };
      } else if (t === q.ZodParsedType.object && n === q.ZodParsedType.object) {
        const i = q.util.objectKeys(e);
        const s = q.util.objectKeys(r).filter((o) => i.indexOf(o) !== -1);
        const a = { ...r, ...e };
        for (const o of s) {
          const u = tu(r[o], e[o]);
          if (!u.valid) {
            return { valid: false };
          }
          a[o] = u.data;
        }
        return { valid: true, data: a };
      } else if (t === q.ZodParsedType.array && n === q.ZodParsedType.array) {
        if (r.length !== e.length) {
          return { valid: false };
        }
        const i = [];
        for (let s = 0; s < r.length; s++) {
          const a = r[s];
          const o = e[s];
          const u = tu(a, o);
          if (!u.valid) {
            return { valid: false };
          }
          i.push(u.data);
        }
        return { valid: true, data: i };
      } else if (t === q.ZodParsedType.date && n === q.ZodParsedType.date && +r === +e) {
        return { valid: true, data: r };
      } else {
        return { valid: false };
      }
    }
    var dr = class extends W {
      _parse(e) {
        const { status: t, ctx: n } = this._processInputParams(e);
        const i = (s, a) => {
          if ((0, E.isAborted)(s) || (0, E.isAborted)(a)) {
            return E.INVALID;
          }
          const o = tu(s.value, a.value);
          if (!o.valid) {
            (0, E.addIssueToContext)(n, {
              code: D.ZodIssueCode.invalid_intersection_types
            });
            return E.INVALID;
          }
          if ((0, E.isDirty)(s) || (0, E.isDirty)(a)) {
            t.dirty();
          }
          return { status: t.value, value: o.data };
        };
        if (n.common.async) {
          return Promise.all([
            this._def.left._parseAsync({
              data: n.data,
              path: n.path,
              parent: n
            }),
            this._def.right._parseAsync({
              data: n.data,
              path: n.path,
              parent: n
            })
          ]).then(([s, a]) => i(s, a));
        } else {
          return i(this._def.left._parseSync({
            data: n.data,
            path: n.path,
            parent: n
          }), this._def.right._parseSync({
            data: n.data,
            path: n.path,
            parent: n
          }));
        }
      }
    };
    v.ZodIntersection = dr;
    dr.create = (r, e, t) => {
      return new dr({
        left: r,
        right: e,
        typeName: H.ZodIntersection,
        ...Y(t)
      });
    };
    var We = class extends W {
      _parse(e) {
        const { status: t, ctx: n } = this._processInputParams(e);
        if (n.parsedType !== q.ZodParsedType.array) {
          (0, E.addIssueToContext)(n, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.array,
            received: n.parsedType
          });
          return E.INVALID;
        }
        if (n.data.length < this._def.items.length) {
          (0, E.addIssueToContext)(n, {
            code: D.ZodIssueCode.too_small,
            minimum: this._def.items.length,
            inclusive: true,
            exact: false,
            type: "array"
          });
          return E.INVALID;
        }
        const i = this._def.rest;
        if (!i && n.data.length > this._def.items.length) {
          (0, E.addIssueToContext)(n, {
            code: D.ZodIssueCode.too_big,
            maximum: this._def.items.length,
            inclusive: true,
            exact: false,
            type: "array"
          });
          t.dirty();
        }
        const s = [...n.data].map((a, o) => {
          const u = this._def.items[o] || this._def.rest;
          if (!u)
            return null;
          return u._parse(new Ye(n, a, n.path, o));
        }).filter((a) => !!a);
        if (n.common.async) {
          return Promise.all(s).then((a) => {
            return E.ParseStatus.mergeArray(t, a);
          });
        } else {
          return E.ParseStatus.mergeArray(t, s);
        }
      }
      get items() {
        return this._def.items;
      }
      rest(e) {
        return new We({
          ...this._def,
          rest: e
        });
      }
    };
    v.ZodTuple = We;
    We.create = (r, e) => {
      if (!Array.isArray(r)) {
        throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
      }
      return new We({
        items: r,
        typeName: H.ZodTuple,
        rest: null,
        ...Y(e)
      });
    };
    var pr = class extends W {
      get keySchema() {
        return this._def.keyType;
      }
      get valueSchema() {
        return this._def.valueType;
      }
      _parse(e) {
        const { status: t, ctx: n } = this._processInputParams(e);
        if (n.parsedType !== q.ZodParsedType.object) {
          (0, E.addIssueToContext)(n, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.object,
            received: n.parsedType
          });
          return E.INVALID;
        }
        const i = [];
        const s = this._def.keyType;
        const a = this._def.valueType;
        for (const o in n.data) {
          i.push({
            key: s._parse(new Ye(n, o, n.path, o)),
            value: a._parse(new Ye(n, n.data[o], n.path, o))
          });
        }
        if (n.common.async) {
          return E.ParseStatus.mergeObjectAsync(t, i);
        } else {
          return E.ParseStatus.mergeObjectSync(t, i);
        }
      }
      get element() {
        return this._def.valueType;
      }
      static create(e, t, n) {
        if (t instanceof W) {
          return new pr({
            keyType: e,
            valueType: t,
            typeName: H.ZodRecord,
            ...Y(n)
          });
        }
        return new pr({
          keyType: Ke.create(),
          valueType: e,
          typeName: H.ZodRecord,
          ...Y(t)
        });
      }
    };
    v.ZodRecord = pr;
    var Yr = class extends W {
      _parse(e) {
        const { status: t, ctx: n } = this._processInputParams(e);
        if (n.parsedType !== q.ZodParsedType.map) {
          (0, E.addIssueToContext)(n, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.map,
            received: n.parsedType
          });
          return E.INVALID;
        }
        const i = this._def.keyType;
        const s = this._def.valueType;
        const a = [...n.data.entries()].map(([o, u], l) => {
          return {
            key: i._parse(new Ye(n, o, n.path, [l, "key"])),
            value: s._parse(new Ye(n, u, n.path, [l, "value"]))
          };
        });
        if (n.common.async) {
          const o = /* @__PURE__ */ new Map();
          return Promise.resolve().then(async () => {
            for (const u of a) {
              const l = await u.key;
              const c = await u.value;
              if (l.status === "aborted" || c.status === "aborted") {
                return E.INVALID;
              }
              if (l.status === "dirty" || c.status === "dirty") {
                t.dirty();
              }
              o.set(l.value, c.value);
            }
            return { status: t.value, value: o };
          });
        } else {
          const o = /* @__PURE__ */ new Map();
          for (const u of a) {
            const l = u.key;
            const c = u.value;
            if (l.status === "aborted" || c.status === "aborted") {
              return E.INVALID;
            }
            if (l.status === "dirty" || c.status === "dirty") {
              t.dirty();
            }
            o.set(l.value, c.value);
          }
          return { status: t.value, value: o };
        }
      }
    };
    v.ZodMap = Yr;
    Yr.create = (r, e, t) => {
      return new Yr({
        valueType: e,
        keyType: r,
        typeName: H.ZodMap,
        ...Y(t)
      });
    };
    var Ct = class extends W {
      _parse(e) {
        const { status: t, ctx: n } = this._processInputParams(e);
        if (n.parsedType !== q.ZodParsedType.set) {
          (0, E.addIssueToContext)(n, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.set,
            received: n.parsedType
          });
          return E.INVALID;
        }
        const i = this._def;
        if (i.minSize !== null) {
          if (n.data.size < i.minSize.value) {
            (0, E.addIssueToContext)(n, {
              code: D.ZodIssueCode.too_small,
              minimum: i.minSize.value,
              type: "set",
              inclusive: true,
              exact: false,
              message: i.minSize.message
            });
            t.dirty();
          }
        }
        if (i.maxSize !== null) {
          if (n.data.size > i.maxSize.value) {
            (0, E.addIssueToContext)(n, {
              code: D.ZodIssueCode.too_big,
              maximum: i.maxSize.value,
              type: "set",
              inclusive: true,
              exact: false,
              message: i.maxSize.message
            });
            t.dirty();
          }
        }
        const s = this._def.valueType;
        function a(u) {
          const l = /* @__PURE__ */ new Set();
          for (const c of u) {
            if (c.status === "aborted")
              return E.INVALID;
            if (c.status === "dirty")
              t.dirty();
            l.add(c.value);
          }
          return { status: t.value, value: l };
        }
        const o = [...n.data.values()].map((u, l) => s._parse(new Ye(n, u, n.path, l)));
        if (n.common.async) {
          return Promise.all(o).then((u) => a(u));
        } else {
          return a(o);
        }
      }
      min(e, t) {
        return new Ct({
          ...this._def,
          minSize: { value: e, message: B.errorUtil.toString(t) }
        });
      }
      max(e, t) {
        return new Ct({
          ...this._def,
          maxSize: { value: e, message: B.errorUtil.toString(t) }
        });
      }
      size(e, t) {
        return this.min(e, t).max(e, t);
      }
      nonempty(e) {
        return this.min(1, e);
      }
    };
    v.ZodSet = Ct;
    Ct.create = (r, e) => {
      return new Ct({
        valueType: r,
        minSize: null,
        maxSize: null,
        typeName: H.ZodSet,
        ...Y(e)
      });
    };
    var $t = class extends W {
      constructor() {
        super(...arguments);
        this.validate = this.implement;
      }
      _parse(e) {
        const { ctx: t } = this._processInputParams(e);
        if (t.parsedType !== q.ZodParsedType.function) {
          (0, E.addIssueToContext)(t, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.function,
            received: t.parsedType
          });
          return E.INVALID;
        }
        function n(o, u) {
          return (0, E.makeIssue)({
            data: o,
            path: t.path,
            errorMaps: [
              t.common.contextualErrorMap,
              t.schemaErrorMap,
              (0, as.getErrorMap)(),
              as.defaultErrorMap
            ].filter((l) => !!l),
            issueData: {
              code: D.ZodIssueCode.invalid_arguments,
              argumentsError: u
            }
          });
        }
        function i(o, u) {
          return (0, E.makeIssue)({
            data: o,
            path: t.path,
            errorMaps: [
              t.common.contextualErrorMap,
              t.schemaErrorMap,
              (0, as.getErrorMap)(),
              as.defaultErrorMap
            ].filter((l) => !!l),
            issueData: {
              code: D.ZodIssueCode.invalid_return_type,
              returnTypeError: u
            }
          });
        }
        const s = { errorMap: t.common.contextualErrorMap };
        const a = t.data;
        if (this._def.returns instanceof Ht) {
          return (0, E.OK)(async (...o) => {
            const u = new D.ZodError([]);
            const l = await this._def.args.parseAsync(o, s).catch((_) => {
              u.addIssue(n(o, _));
              throw u;
            });
            const c = await a(...l);
            const b = await this._def.returns._def.type.parseAsync(c, s).catch((_) => {
              u.addIssue(i(c, _));
              throw u;
            });
            return b;
          });
        } else {
          return (0, E.OK)((...o) => {
            const u = this._def.args.safeParse(o, s);
            if (!u.success) {
              throw new D.ZodError([n(o, u.error)]);
            }
            const l = a(...u.data);
            const c = this._def.returns.safeParse(l, s);
            if (!c.success) {
              throw new D.ZodError([i(l, c.error)]);
            }
            return c.data;
          });
        }
      }
      parameters() {
        return this._def.args;
      }
      returnType() {
        return this._def.returns;
      }
      args(...e) {
        return new $t({
          ...this._def,
          args: We.create(e).rest(Tt.create())
        });
      }
      returns(e) {
        return new $t({
          ...this._def,
          returns: e
        });
      }
      implement(e) {
        const t = this.parse(e);
        return t;
      }
      strictImplement(e) {
        const t = this.parse(e);
        return t;
      }
      static create(e, t, n) {
        return new $t({
          args: e ? e : We.create([]).rest(Tt.create()),
          returns: t || Tt.create(),
          typeName: H.ZodFunction,
          ...Y(n)
        });
      }
    };
    v.ZodFunction = $t;
    var hr = class extends W {
      get schema() {
        return this._def.getter();
      }
      _parse(e) {
        const { ctx: t } = this._processInputParams(e);
        const n = this._def.getter();
        return n._parse({ data: t.data, path: t.path, parent: t });
      }
    };
    v.ZodLazy = hr;
    hr.create = (r, e) => {
      return new hr({
        getter: r,
        typeName: H.ZodLazy,
        ...Y(e)
      });
    };
    var fr = class extends W {
      _parse(e) {
        if (e.data !== this._def.value) {
          const t = this._getOrReturnCtx(e);
          (0, E.addIssueToContext)(t, {
            received: t.data,
            code: D.ZodIssueCode.invalid_literal,
            expected: this._def.value
          });
          return E.INVALID;
        }
        return { status: "valid", value: e.data };
      }
      get value() {
        return this._def.value;
      }
    };
    v.ZodLiteral = fr;
    fr.create = (r, e) => {
      return new fr({
        value: r,
        typeName: H.ZodLiteral,
        ...Y(e)
      });
    };
    function zp(r, e) {
      return new mt({
        values: r,
        typeName: H.ZodEnum,
        ...Y(e)
      });
    }
    var mt = class extends W {
      _parse(e) {
        if (typeof e.data !== "string") {
          const t = this._getOrReturnCtx(e);
          const n = this._def.values;
          (0, E.addIssueToContext)(t, {
            expected: q.util.joinValues(n),
            received: t.parsedType,
            code: D.ZodIssueCode.invalid_type
          });
          return E.INVALID;
        }
        if (this._def.values.indexOf(e.data) === -1) {
          const t = this._getOrReturnCtx(e);
          const n = this._def.values;
          (0, E.addIssueToContext)(t, {
            received: t.data,
            code: D.ZodIssueCode.invalid_enum_value,
            options: n
          });
          return E.INVALID;
        }
        return (0, E.OK)(e.data);
      }
      get options() {
        return this._def.values;
      }
      get enum() {
        const e = {};
        for (const t of this._def.values) {
          e[t] = t;
        }
        return e;
      }
      get Values() {
        const e = {};
        for (const t of this._def.values) {
          e[t] = t;
        }
        return e;
      }
      get Enum() {
        const e = {};
        for (const t of this._def.values) {
          e[t] = t;
        }
        return e;
      }
      extract(e) {
        return mt.create(e);
      }
      exclude(e) {
        return mt.create(this.options.filter((t) => !e.includes(t)));
      }
    };
    v.ZodEnum = mt;
    mt.create = zp;
    var mr = class extends W {
      _parse(e) {
        const t = q.util.getValidEnumValues(this._def.values);
        const n = this._getOrReturnCtx(e);
        if (n.parsedType !== q.ZodParsedType.string && n.parsedType !== q.ZodParsedType.number) {
          const i = q.util.objectValues(t);
          (0, E.addIssueToContext)(n, {
            expected: q.util.joinValues(i),
            received: n.parsedType,
            code: D.ZodIssueCode.invalid_type
          });
          return E.INVALID;
        }
        if (t.indexOf(e.data) === -1) {
          const i = q.util.objectValues(t);
          (0, E.addIssueToContext)(n, {
            received: n.data,
            code: D.ZodIssueCode.invalid_enum_value,
            options: i
          });
          return E.INVALID;
        }
        return (0, E.OK)(e.data);
      }
      get enum() {
        return this._def.values;
      }
    };
    v.ZodNativeEnum = mr;
    mr.create = (r, e) => {
      return new mr({
        values: r,
        typeName: H.ZodNativeEnum,
        ...Y(e)
      });
    };
    var Ht = class extends W {
      unwrap() {
        return this._def.type;
      }
      _parse(e) {
        const { ctx: t } = this._processInputParams(e);
        if (t.parsedType !== q.ZodParsedType.promise && t.common.async === false) {
          (0, E.addIssueToContext)(t, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.promise,
            received: t.parsedType
          });
          return E.INVALID;
        }
        const n = t.parsedType === q.ZodParsedType.promise ? t.data : Promise.resolve(t.data);
        return (0, E.OK)(n.then((i) => {
          return this._def.type.parseAsync(i, {
            path: t.path,
            errorMap: t.common.contextualErrorMap
          });
        }));
      }
    };
    v.ZodPromise = Ht;
    Ht.create = (r, e) => {
      return new Ht({
        type: r,
        typeName: H.ZodPromise,
        ...Y(e)
      });
    };
    var $e = class extends W {
      innerType() {
        return this._def.schema;
      }
      sourceType() {
        return this._def.schema._def.typeName === H.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
      }
      _parse(e) {
        const { status: t, ctx: n } = this._processInputParams(e);
        const i = this._def.effect || null;
        if (i.type === "preprocess") {
          const a = i.transform(n.data);
          if (n.common.async) {
            return Promise.resolve(a).then((o) => {
              return this._def.schema._parseAsync({
                data: o,
                path: n.path,
                parent: n
              });
            });
          } else {
            return this._def.schema._parseSync({
              data: a,
              path: n.path,
              parent: n
            });
          }
        }
        const s = {
          addIssue: (a) => {
            (0, E.addIssueToContext)(n, a);
            if (a.fatal) {
              t.abort();
            } else {
              t.dirty();
            }
          },
          get path() {
            return n.path;
          }
        };
        s.addIssue = s.addIssue.bind(s);
        if (i.type === "refinement") {
          const a = (o) => {
            const u = i.refinement(o, s);
            if (n.common.async) {
              return Promise.resolve(u);
            }
            if (u instanceof Promise) {
              throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
            }
            return o;
          };
          if (n.common.async === false) {
            const o = this._def.schema._parseSync({
              data: n.data,
              path: n.path,
              parent: n
            });
            if (o.status === "aborted")
              return E.INVALID;
            if (o.status === "dirty")
              t.dirty();
            a(o.value);
            return { status: t.value, value: o.value };
          } else {
            return this._def.schema._parseAsync({ data: n.data, path: n.path, parent: n }).then((o) => {
              if (o.status === "aborted")
                return E.INVALID;
              if (o.status === "dirty")
                t.dirty();
              return a(o.value).then(() => {
                return { status: t.value, value: o.value };
              });
            });
          }
        }
        if (i.type === "transform") {
          if (n.common.async === false) {
            const a = this._def.schema._parseSync({
              data: n.data,
              path: n.path,
              parent: n
            });
            if (!(0, E.isValid)(a))
              return a;
            const o = i.transform(a.value, s);
            if (o instanceof Promise) {
              throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
            }
            return { status: t.value, value: o };
          } else {
            return this._def.schema._parseAsync({ data: n.data, path: n.path, parent: n }).then((a) => {
              if (!(0, E.isValid)(a))
                return a;
              return Promise.resolve(i.transform(a.value, s)).then((o) => ({ status: t.value, value: o }));
            });
          }
        }
        q.util.assertNever(i);
      }
    };
    v.ZodEffects = $e;
    v.ZodTransformer = $e;
    $e.create = (r, e, t) => {
      return new $e({
        schema: r,
        typeName: H.ZodEffects,
        effect: e,
        ...Y(t)
      });
    };
    $e.createWithPreprocess = (r, e, t) => {
      return new $e({
        schema: e,
        effect: { type: "preprocess", transform: r },
        typeName: H.ZodEffects,
        ...Y(t)
      });
    };
    var st = class extends W {
      _parse(e) {
        const t = this._getType(e);
        if (t === q.ZodParsedType.undefined) {
          return (0, E.OK)(void 0);
        }
        return this._def.innerType._parse(e);
      }
      unwrap() {
        return this._def.innerType;
      }
    };
    v.ZodOptional = st;
    st.create = (r, e) => {
      return new st({
        innerType: r,
        typeName: H.ZodOptional,
        ...Y(e)
      });
    };
    var St = class extends W {
      _parse(e) {
        const t = this._getType(e);
        if (t === q.ZodParsedType.null) {
          return (0, E.OK)(null);
        }
        return this._def.innerType._parse(e);
      }
      unwrap() {
        return this._def.innerType;
      }
    };
    v.ZodNullable = St;
    St.create = (r, e) => {
      return new St({
        innerType: r,
        typeName: H.ZodNullable,
        ...Y(e)
      });
    };
    var yr = class extends W {
      _parse(e) {
        const { ctx: t } = this._processInputParams(e);
        let n = t.data;
        if (t.parsedType === q.ZodParsedType.undefined) {
          n = this._def.defaultValue();
        }
        return this._def.innerType._parse({
          data: n,
          path: t.path,
          parent: t
        });
      }
      removeDefault() {
        return this._def.innerType;
      }
    };
    v.ZodDefault = yr;
    yr.create = (r, e) => {
      return new yr({
        innerType: r,
        typeName: H.ZodDefault,
        defaultValue: typeof e.default === "function" ? e.default : () => e.default,
        ...Y(e)
      });
    };
    var Wr = class extends W {
      _parse(e) {
        const { ctx: t } = this._processInputParams(e);
        const n = {
          ...t,
          common: {
            ...t.common,
            issues: []
          }
        };
        const i = this._def.innerType._parse({
          data: n.data,
          path: n.path,
          parent: {
            ...n
          }
        });
        if ((0, E.isAsync)(i)) {
          return i.then((s) => {
            return {
              status: "valid",
              value: s.status === "valid" ? s.value : this._def.catchValue({
                get error() {
                  return new D.ZodError(n.common.issues);
                },
                input: n.data
              })
            };
          });
        } else {
          return {
            status: "valid",
            value: i.status === "valid" ? i.value : this._def.catchValue({
              get error() {
                return new D.ZodError(n.common.issues);
              },
              input: n.data
            })
          };
        }
      }
      removeCatch() {
        return this._def.innerType;
      }
    };
    v.ZodCatch = Wr;
    Wr.create = (r, e) => {
      return new Wr({
        innerType: r,
        typeName: H.ZodCatch,
        catchValue: typeof e.catch === "function" ? e.catch : () => e.catch,
        ...Y(e)
      });
    };
    var Gr = class extends W {
      _parse(e) {
        const t = this._getType(e);
        if (t !== q.ZodParsedType.nan) {
          const n = this._getOrReturnCtx(e);
          (0, E.addIssueToContext)(n, {
            code: D.ZodIssueCode.invalid_type,
            expected: q.ZodParsedType.nan,
            received: n.parsedType
          });
          return E.INVALID;
        }
        return { status: "valid", value: e.data };
      }
    };
    v.ZodNaN = Gr;
    Gr.create = (r) => {
      return new Gr({
        typeName: H.ZodNaN,
        ...Y(r)
      });
    };
    v.BRAND = Symbol("zod_brand");
    var us = class extends W {
      _parse(e) {
        const { ctx: t } = this._processInputParams(e);
        const n = t.data;
        return this._def.type._parse({
          data: n,
          path: t.path,
          parent: t
        });
      }
      unwrap() {
        return this._def.type;
      }
    };
    v.ZodBranded = us;
    var br = class extends W {
      _parse(e) {
        const { status: t, ctx: n } = this._processInputParams(e);
        if (n.common.async) {
          const i = async () => {
            const s = await this._def.in._parseAsync({
              data: n.data,
              path: n.path,
              parent: n
            });
            if (s.status === "aborted")
              return E.INVALID;
            if (s.status === "dirty") {
              t.dirty();
              return (0, E.DIRTY)(s.value);
            } else {
              return this._def.out._parseAsync({
                data: s.value,
                path: n.path,
                parent: n
              });
            }
          };
          return i();
        } else {
          const i = this._def.in._parseSync({
            data: n.data,
            path: n.path,
            parent: n
          });
          if (i.status === "aborted")
            return E.INVALID;
          if (i.status === "dirty") {
            t.dirty();
            return {
              status: "dirty",
              value: i.value
            };
          } else {
            return this._def.out._parseSync({
              data: i.value,
              path: n.path,
              parent: n
            });
          }
        }
      }
      static create(e, t) {
        return new br({
          in: e,
          out: t,
          typeName: H.ZodPipeline
        });
      }
    };
    v.ZodPipeline = br;
    var vg = (r, e = {}, t) => {
      if (r)
        return Zt.create().superRefine((n, i) => {
          var s, a;
          if (!r(n)) {
            const o = typeof e === "function" ? e(n) : typeof e === "string" ? { message: e } : e;
            const u = (a = (s = o.fatal) !== null && s !== void 0 ? s : t) !== null && a !== void 0 ? a : true;
            const l = typeof o === "string" ? { message: o } : o;
            i.addIssue({ code: "custom", ...l, fatal: u });
          }
        });
      return Zt.create();
    };
    v.custom = vg;
    v.late = {
      object: ce.lazycreate
    };
    var H;
    (function(r) {
      r["ZodString"] = "ZodString";
      r["ZodNumber"] = "ZodNumber";
      r["ZodNaN"] = "ZodNaN";
      r["ZodBigInt"] = "ZodBigInt";
      r["ZodBoolean"] = "ZodBoolean";
      r["ZodDate"] = "ZodDate";
      r["ZodSymbol"] = "ZodSymbol";
      r["ZodUndefined"] = "ZodUndefined";
      r["ZodNull"] = "ZodNull";
      r["ZodAny"] = "ZodAny";
      r["ZodUnknown"] = "ZodUnknown";
      r["ZodNever"] = "ZodNever";
      r["ZodVoid"] = "ZodVoid";
      r["ZodArray"] = "ZodArray";
      r["ZodObject"] = "ZodObject";
      r["ZodUnion"] = "ZodUnion";
      r["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
      r["ZodIntersection"] = "ZodIntersection";
      r["ZodTuple"] = "ZodTuple";
      r["ZodRecord"] = "ZodRecord";
      r["ZodMap"] = "ZodMap";
      r["ZodSet"] = "ZodSet";
      r["ZodFunction"] = "ZodFunction";
      r["ZodLazy"] = "ZodLazy";
      r["ZodLiteral"] = "ZodLiteral";
      r["ZodEnum"] = "ZodEnum";
      r["ZodEffects"] = "ZodEffects";
      r["ZodNativeEnum"] = "ZodNativeEnum";
      r["ZodOptional"] = "ZodOptional";
      r["ZodNullable"] = "ZodNullable";
      r["ZodDefault"] = "ZodDefault";
      r["ZodCatch"] = "ZodCatch";
      r["ZodPromise"] = "ZodPromise";
      r["ZodBranded"] = "ZodBranded";
      r["ZodPipeline"] = "ZodPipeline";
    })(H = v.ZodFirstPartyTypeKind || (v.ZodFirstPartyTypeKind = {}));
    var xg = (r, e = {
      message: `Input not instance of ${r.name}`
    }) => (0, v.custom)((t) => t instanceof r, e);
    v.instanceof = xg;
    var Fp = Ke.create;
    v.string = Fp;
    var Kp = ht.create;
    v.number = Kp;
    var Og = Gr.create;
    v.nan = Og;
    var Pg = ft.create;
    v.bigint = Pg;
    var Bp = or.create;
    v.boolean = Bp;
    var Ag = It.create;
    v.date = Ag;
    var Eg = Hr.create;
    v.symbol = Eg;
    var Tg = ur.create;
    v.undefined = Tg;
    var Ig = lr.create;
    v.null = Ig;
    var Cg = Zt.create;
    v.any = Cg;
    var Sg = Tt.create;
    v.unknown = Sg;
    var jg = at.create;
    v.never = jg;
    var kg = Qr.create;
    v.void = kg;
    var Rg = Be.create;
    v.array = Rg;
    var Ng = ce.create;
    v.object = Ng;
    var Mg = ce.strictCreate;
    v.strictObject = Mg;
    var Lg = cr.create;
    v.union = Lg;
    var Dg = Jr.create;
    v.discriminatedUnion = Dg;
    var qg = dr.create;
    v.intersection = qg;
    var Ug = We.create;
    v.tuple = Ug;
    var Vg = pr.create;
    v.record = Vg;
    var zg = Yr.create;
    v.map = zg;
    var Fg = Ct.create;
    v.set = Fg;
    var Kg = $t.create;
    v.function = Kg;
    var Bg = hr.create;
    v.lazy = Bg;
    var $g = fr.create;
    v.literal = $g;
    var Zg = mt.create;
    v.enum = Zg;
    var Hg = mr.create;
    v.nativeEnum = Hg;
    var Qg = Ht.create;
    v.promise = Qg;
    var $p = $e.create;
    v.effect = $p;
    v.transformer = $p;
    var Jg = st.create;
    v.optional = Jg;
    var Yg = St.create;
    v.nullable = Yg;
    var Wg = $e.createWithPreprocess;
    v.preprocess = Wg;
    var Gg = br.create;
    v.pipeline = Gg;
    var Xg = () => Fp().optional();
    v.ostring = Xg;
    var ew = () => Kp().optional();
    v.onumber = ew;
    var tw = () => Bp().optional();
    v.oboolean = tw;
    v.coerce = {
      string: (r) => Ke.create({ ...r, coerce: true }),
      number: (r) => ht.create({ ...r, coerce: true }),
      boolean: (r) => or.create({
        ...r,
        coerce: true
      }),
      bigint: (r) => ft.create({ ...r, coerce: true }),
      date: (r) => It.create({ ...r, coerce: true })
    };
    v.NEVER = E.INVALID;
  });

  // node_modules/.pnpm/zod@3.21.4/node_modules/zod/lib/external.js
  var ru = N((Ge) => {
    "use strict";
    var rw = Ge && Ge.__createBinding || (Object.create ? function(r, e, t, n) {
      if (n === void 0)
        n = t;
      Object.defineProperty(r, n, { enumerable: true, get: function() {
        return e[t];
      } });
    } : function(r, e, t, n) {
      if (n === void 0)
        n = t;
      r[n] = e[t];
    });
    var Xr = Ge && Ge.__exportStar || function(r, e) {
      for (var t in r)
        if (t !== "default" && !Object.prototype.hasOwnProperty.call(e, t))
          rw(e, r, t);
    };
    Object.defineProperty(Ge, "__esModule", { value: true });
    Xr(ss(), Ge);
    Xr(eu(), Ge);
    Xr(qp(), Ge);
    Xr(Un(), Ge);
    Xr(Zp(), Ge);
    Xr(is(), Ge);
  });

  // node_modules/.pnpm/zod@3.21.4/node_modules/zod/lib/index.js
  var ls = N((Ue) => {
    "use strict";
    var Hp = Ue && Ue.__createBinding || (Object.create ? function(r, e, t, n) {
      if (n === void 0)
        n = t;
      Object.defineProperty(r, n, { enumerable: true, get: function() {
        return e[t];
      } });
    } : function(r, e, t, n) {
      if (n === void 0)
        n = t;
      r[n] = e[t];
    });
    var nw = Ue && Ue.__setModuleDefault || (Object.create ? function(r, e) {
      Object.defineProperty(r, "default", { enumerable: true, value: e });
    } : function(r, e) {
      r["default"] = e;
    });
    var iw = Ue && Ue.__importStar || function(r) {
      if (r && r.__esModule)
        return r;
      var e = {};
      if (r != null) {
        for (var t in r)
          if (t !== "default" && Object.prototype.hasOwnProperty.call(r, t))
            Hp(e, r, t);
      }
      nw(e, r);
      return e;
    };
    var sw = Ue && Ue.__exportStar || function(r, e) {
      for (var t in r)
        if (t !== "default" && !Object.prototype.hasOwnProperty.call(e, t))
          Hp(e, r, t);
    };
    Object.defineProperty(Ue, "__esModule", { value: true });
    Ue.z = void 0;
    var Qp = iw(ru());
    Ue.z = Qp;
    sw(ru(), Ue);
    Ue.default = Qp;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/any.js
  var Jp = N((cs) => {
    "use strict";
    Object.defineProperty(cs, "__esModule", { value: true });
    cs.parseAnyDef = void 0;
    function aw() {
      return {};
    }
    cs.parseAnyDef = aw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/errorMessages.js
  var tn = N((en) => {
    "use strict";
    Object.defineProperty(en, "__esModule", { value: true });
    en.setResponseValueAndErrors = en.addErrorMessage = void 0;
    function Yp(r, e, t, n) {
      if (!(n === null || n === void 0 ? void 0 : n.errorMessages))
        return;
      if (t) {
        r.errorMessage = Object.assign(Object.assign({}, r.errorMessage), { [e]: t });
      }
    }
    en.addErrorMessage = Yp;
    function ow(r, e, t, n, i) {
      r[e] = t;
      Yp(r, e, n, i);
    }
    en.setResponseValueAndErrors = ow;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/array.js
  var Gp = N((ds) => {
    "use strict";
    Object.defineProperty(ds, "__esModule", { value: true });
    ds.parseArrayDef = void 0;
    var uw = ls();
    var Wp = tn();
    var lw = xe();
    function cw(r, e) {
      var t, n;
      const i = {
        type: "array"
      };
      if (((n = (t = r.type) === null || t === void 0 ? void 0 : t._def) === null || n === void 0 ? void 0 : n.typeName) !== uw.ZodFirstPartyTypeKind.ZodAny) {
        i.items = (0, lw.parseDef)(r.type._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "items"] }));
      }
      if (r.minLength) {
        (0, Wp.setResponseValueAndErrors)(i, "minItems", r.minLength.value, r.minLength.message, e);
      }
      if (r.maxLength) {
        (0, Wp.setResponseValueAndErrors)(i, "maxItems", r.maxLength.value, r.maxLength.message, e);
      }
      return i;
    }
    ds.parseArrayDef = cw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/bigint.js
  var Xp = N((ps) => {
    "use strict";
    Object.defineProperty(ps, "__esModule", { value: true });
    ps.parseBigintDef = void 0;
    var gr = tn();
    function dw(r, e) {
      const t = {
        type: "integer",
        format: "int64"
      };
      if (!r.checks)
        return t;
      for (const n of r.checks) {
        switch (n.kind) {
          case "min":
            if (e.target === "jsonSchema7") {
              if (n.inclusive) {
                (0, gr.setResponseValueAndErrors)(t, "minimum", n.value, n.message, e);
              } else {
                (0, gr.setResponseValueAndErrors)(t, "exclusiveMinimum", n.value, n.message, e);
              }
            } else {
              if (!n.inclusive) {
                t.exclusiveMinimum = true;
              }
              (0, gr.setResponseValueAndErrors)(t, "minimum", n.value, n.message, e);
            }
            break;
          case "max":
            if (e.target === "jsonSchema7") {
              if (n.inclusive) {
                (0, gr.setResponseValueAndErrors)(t, "maximum", n.value, n.message, e);
              } else {
                (0, gr.setResponseValueAndErrors)(t, "exclusiveMaximum", n.value, n.message, e);
              }
            } else {
              if (!n.inclusive) {
                t.exclusiveMaximum = true;
              }
              (0, gr.setResponseValueAndErrors)(t, "maximum", n.value, n.message, e);
            }
            break;
          case "multipleOf":
            (0, gr.setResponseValueAndErrors)(t, "multipleOf", n.value, n.message, e);
            break;
        }
      }
      return t;
    }
    ps.parseBigintDef = dw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/boolean.js
  var eh = N((hs) => {
    "use strict";
    Object.defineProperty(hs, "__esModule", { value: true });
    hs.parseBooleanDef = void 0;
    function pw() {
      return {
        type: "boolean"
      };
    }
    hs.parseBooleanDef = pw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/branded.js
  var th = N((fs) => {
    "use strict";
    Object.defineProperty(fs, "__esModule", { value: true });
    fs.parseBrandedDef = void 0;
    var hw = xe();
    function fw(r, e) {
      return (0, hw.parseDef)(r.type._def, e);
    }
    fs.parseBrandedDef = fw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/catch.js
  var rh = N((ms) => {
    "use strict";
    Object.defineProperty(ms, "__esModule", { value: true });
    ms.parseCatchDef = void 0;
    var mw = xe();
    var yw = (r, e) => {
      return (0, mw.parseDef)(r.innerType._def, e);
    };
    ms.parseCatchDef = yw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/date.js
  var nh = N((ys) => {
    "use strict";
    Object.defineProperty(ys, "__esModule", { value: true });
    ys.parseDateDef = void 0;
    function bw() {
      return {
        type: "string",
        format: "date-time"
      };
    }
    ys.parseDateDef = bw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/default.js
  var ih = N((bs) => {
    "use strict";
    Object.defineProperty(bs, "__esModule", { value: true });
    bs.parseDefaultDef = void 0;
    var gw = xe();
    function ww(r, e) {
      return Object.assign(Object.assign({}, (0, gw.parseDef)(r.innerType._def, e)), { default: r.defaultValue() });
    }
    bs.parseDefaultDef = ww;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/effects.js
  var sh = N((gs) => {
    "use strict";
    Object.defineProperty(gs, "__esModule", { value: true });
    gs.parseEffectsDef = void 0;
    var _w = xe();
    function vw(r, e) {
      return e.effectStrategy === "input" ? (0, _w.parseDef)(r.schema._def, e) : {};
    }
    gs.parseEffectsDef = vw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/enum.js
  var ah = N((ws) => {
    "use strict";
    Object.defineProperty(ws, "__esModule", { value: true });
    ws.parseEnumDef = void 0;
    function xw(r) {
      return {
        type: "string",
        enum: r.values
      };
    }
    ws.parseEnumDef = xw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/intersection.js
  var uh = N((rn) => {
    "use strict";
    var Ow = rn && rn.__rest || function(r, e) {
      var t = {};
      for (var n in r)
        if (Object.prototype.hasOwnProperty.call(r, n) && e.indexOf(n) < 0)
          t[n] = r[n];
      if (r != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, n = Object.getOwnPropertySymbols(r); i < n.length; i++) {
          if (e.indexOf(n[i]) < 0 && Object.prototype.propertyIsEnumerable.call(r, n[i]))
            t[n[i]] = r[n[i]];
        }
      return t;
    };
    Object.defineProperty(rn, "__esModule", { value: true });
    rn.parseIntersectionDef = void 0;
    var oh = xe();
    var Pw = (r) => {
      if ("type" in r && r.type === "string")
        return false;
      return "allOf" in r;
    };
    function Aw(r, e) {
      const t = [
        (0, oh.parseDef)(r.left._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "allOf", "0"] })),
        (0, oh.parseDef)(r.right._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "allOf", "1"] }))
      ].filter((s) => !!s);
      let n = e.target === "jsonSchema2019-09" ? { unevaluatedProperties: false } : void 0;
      const i = [];
      t.forEach((s) => {
        if (Pw(s)) {
          i.push(...s.allOf);
          if (s.unevaluatedProperties === void 0) {
            n = void 0;
          }
        } else {
          let a = s;
          if ("additionalProperties" in s && s.additionalProperties === false) {
            const { additionalProperties: o } = s, u = Ow(s, ["additionalProperties"]);
            a = u;
          } else {
            n = void 0;
          }
          i.push(a);
        }
      });
      return i.length ? Object.assign({ allOf: i }, n) : void 0;
    }
    rn.parseIntersectionDef = Aw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/literal.js
  var lh = N((_s) => {
    "use strict";
    Object.defineProperty(_s, "__esModule", { value: true });
    _s.parseLiteralDef = void 0;
    function Ew(r, e) {
      const t = typeof r.value;
      if (t !== "bigint" && t !== "number" && t !== "boolean" && t !== "string") {
        return {
          type: Array.isArray(r.value) ? "array" : "object"
        };
      }
      if (e.target === "openApi3") {
        return {
          type: t === "bigint" ? "integer" : t,
          enum: [r.value]
        };
      }
      return {
        type: t === "bigint" ? "integer" : t,
        const: r.value
      };
    }
    _s.parseLiteralDef = Ew;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/map.js
  var dh = N((vs) => {
    "use strict";
    Object.defineProperty(vs, "__esModule", { value: true });
    vs.parseMapDef = void 0;
    var ch = xe();
    function Tw(r, e) {
      const t = (0, ch.parseDef)(r.keyType._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "items", "items", "0"] })) || {};
      const n = (0, ch.parseDef)(r.valueType._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "items", "items", "1"] })) || {};
      return {
        type: "array",
        maxItems: 125,
        items: {
          type: "array",
          items: [t, n],
          minItems: 2,
          maxItems: 2
        }
      };
    }
    vs.parseMapDef = Tw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/nativeEnum.js
  var ph = N((xs) => {
    "use strict";
    Object.defineProperty(xs, "__esModule", { value: true });
    xs.parseNativeEnumDef = void 0;
    function Iw(r) {
      const e = r.values;
      const t = Object.keys(r.values).filter((s) => {
        return typeof e[e[s]] !== "number";
      });
      const n = t.map((s) => e[s]);
      const i = Array.from(new Set(n.map((s) => typeof s)));
      return {
        type: i.length === 1 ? i[0] === "string" ? "string" : "number" : ["string", "number"],
        enum: n
      };
    }
    xs.parseNativeEnumDef = Iw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/never.js
  var hh = N((Os) => {
    "use strict";
    Object.defineProperty(Os, "__esModule", { value: true });
    Os.parseNeverDef = void 0;
    function Cw() {
      return {
        not: {}
      };
    }
    Os.parseNeverDef = Cw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/null.js
  var fh = N((Ps) => {
    "use strict";
    Object.defineProperty(Ps, "__esModule", { value: true });
    Ps.parseNullDef = void 0;
    function Sw(r) {
      return r.target === "openApi3" ? {
        enum: ["null"],
        nullable: true
      } : {
        type: "null"
      };
    }
    Ps.parseNullDef = Sw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/union.js
  var nu = N((Qt) => {
    "use strict";
    Object.defineProperty(Qt, "__esModule", { value: true });
    Qt.parseUnionDef = Qt.primitiveMappings = void 0;
    var jw = xe();
    Qt.primitiveMappings = {
      ZodString: "string",
      ZodNumber: "number",
      ZodBigInt: "integer",
      ZodBoolean: "boolean",
      ZodNull: "null"
    };
    function kw(r, e) {
      if (e.target === "openApi3")
        return mh(r, e);
      const t = r.options instanceof Map ? Array.from(r.options.values()) : r.options;
      if (t.every((n) => n._def.typeName in Qt.primitiveMappings && (!n._def.checks || !n._def.checks.length))) {
        const n = t.reduce((i, s) => {
          const a = Qt.primitiveMappings[s._def.typeName];
          return a && !i.includes(a) ? [...i, a] : i;
        }, []);
        return {
          type: n.length > 1 ? n : n[0]
        };
      } else if (t.every((n) => n._def.typeName === "ZodLiteral" && !n.description)) {
        const n = t.reduce((i, s) => {
          const a = typeof s._def.value;
          switch (a) {
            case "string":
            case "number":
            case "boolean":
              return [...i, a];
            case "bigint":
              return [...i, "integer"];
            case "object":
              if (s._def.value === null)
                return [...i, "null"];
            case "symbol":
            case "undefined":
            case "function":
            default:
              return i;
          }
        }, []);
        if (n.length === t.length) {
          const i = n.filter((s, a, o) => o.indexOf(s) === a);
          return {
            type: i.length > 1 ? i : i[0],
            enum: t.reduce((s, a) => {
              return s.includes(a._def.value) ? s : [...s, a._def.value];
            }, [])
          };
        }
      } else if (t.every((n) => n._def.typeName === "ZodEnum")) {
        return {
          type: "string",
          enum: t.reduce((n, i) => [
            ...n,
            ...i._def.values.filter((s) => !n.includes(s))
          ], [])
        };
      }
      return mh(r, e);
    }
    Qt.parseUnionDef = kw;
    var mh = (r, e) => {
      const t = (r.options instanceof Map ? Array.from(r.options.values()) : r.options).map((n, i) => (0, jw.parseDef)(n._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "anyOf", `${i}`] }))).filter((n) => !!n && (!e.strictUnions || typeof n === "object" && Object.keys(n).length > 0));
      return t.length ? { anyOf: t } : void 0;
    };
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/nullable.js
  var bh = N((As) => {
    "use strict";
    Object.defineProperty(As, "__esModule", { value: true });
    As.parseNullableDef = void 0;
    var Rw = xe();
    var yh = nu();
    function Nw(r, e) {
      if (["ZodString", "ZodNumber", "ZodBigInt", "ZodBoolean", "ZodNull"].includes(r.innerType._def.typeName) && (!r.innerType._def.checks || !r.innerType._def.checks.length)) {
        if (e.target === "openApi3") {
          return {
            type: yh.primitiveMappings[r.innerType._def.typeName],
            nullable: true
          };
        }
        return {
          type: [
            yh.primitiveMappings[r.innerType._def.typeName],
            "null"
          ]
        };
      }
      const t = (0, Rw.parseDef)(r.innerType._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "anyOf", "0"] }));
      return t ? e.target === "openApi3" ? Object.assign(Object.assign({}, t), { nullable: true }) : {
        anyOf: [
          t,
          {
            type: "null"
          }
        ]
      } : void 0;
    }
    As.parseNullableDef = Nw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/number.js
  var gh = N((Es) => {
    "use strict";
    Object.defineProperty(Es, "__esModule", { value: true });
    Es.parseNumberDef = void 0;
    var Jt = tn();
    function Mw(r, e) {
      const t = {
        type: "number"
      };
      if (!r.checks)
        return t;
      for (const n of r.checks) {
        switch (n.kind) {
          case "int":
            t.type = "integer";
            (0, Jt.addErrorMessage)(t, "type", n.message, e);
            break;
          case "min":
            if (e.target === "jsonSchema7") {
              if (n.inclusive) {
                (0, Jt.setResponseValueAndErrors)(t, "minimum", n.value, n.message, e);
              } else {
                (0, Jt.setResponseValueAndErrors)(t, "exclusiveMinimum", n.value, n.message, e);
              }
            } else {
              if (!n.inclusive) {
                t.exclusiveMinimum = true;
              }
              (0, Jt.setResponseValueAndErrors)(t, "minimum", n.value, n.message, e);
            }
            break;
          case "max":
            if (e.target === "jsonSchema7") {
              if (n.inclusive) {
                (0, Jt.setResponseValueAndErrors)(t, "maximum", n.value, n.message, e);
              } else {
                (0, Jt.setResponseValueAndErrors)(t, "exclusiveMaximum", n.value, n.message, e);
              }
            } else {
              if (!n.inclusive) {
                t.exclusiveMaximum = true;
              }
              (0, Jt.setResponseValueAndErrors)(t, "maximum", n.value, n.message, e);
            }
            break;
          case "multipleOf":
            (0, Jt.setResponseValueAndErrors)(t, "multipleOf", n.value, n.message, e);
            break;
        }
      }
      return t;
    }
    Es.parseNumberDef = Mw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/object.js
  var _h = N((Ts) => {
    "use strict";
    Object.defineProperty(Ts, "__esModule", { value: true });
    Ts.parseObjectDef = void 0;
    var wh = xe();
    function Lw(r, e) {
      var t;
      const n = Object.assign(Object.assign({ type: "object" }, Object.entries(r.shape()).reduce((i, [s, a]) => {
        if (a === void 0 || a._def === void 0)
          return i;
        const o = (0, wh.parseDef)(a._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "properties", s], propertyPath: [...e.currentPath, "properties", s] }));
        if (o === void 0)
          return i;
        return {
          properties: Object.assign(Object.assign({}, i.properties), { [s]: o }),
          required: a.isOptional() ? i.required : [...i.required, s]
        };
      }, { properties: {}, required: [] })), { additionalProperties: r.catchall._def.typeName === "ZodNever" ? r.unknownKeys === "passthrough" : (t = (0, wh.parseDef)(r.catchall._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "additionalProperties"] }))) !== null && t !== void 0 ? t : true });
      if (!n.required.length)
        delete n.required;
      return n;
    }
    Ts.parseObjectDef = Lw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/optional.js
  var xh = N((Is) => {
    "use strict";
    Object.defineProperty(Is, "__esModule", { value: true });
    Is.parseOptionalDef = void 0;
    var vh = xe();
    var Dw = (r, e) => {
      var t;
      if (e.currentPath.toString() === ((t = e.propertyPath) === null || t === void 0 ? void 0 : t.toString())) {
        return (0, vh.parseDef)(r.innerType._def, e);
      }
      const n = (0, vh.parseDef)(r.innerType._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "anyOf", "1"] }));
      return n ? {
        anyOf: [
          {
            not: {}
          },
          n
        ]
      } : {};
    };
    Is.parseOptionalDef = Dw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/pipeline.js
  var Oh = N((Cs) => {
    "use strict";
    Object.defineProperty(Cs, "__esModule", { value: true });
    Cs.parsePipelineDef = void 0;
    var iu = xe();
    var qw = (r, e) => {
      if (e.pipeStrategy === "input") {
        return (0, iu.parseDef)(r.in._def, e);
      }
      const t = (0, iu.parseDef)(r.in._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "allOf", "0"] }));
      const n = (0, iu.parseDef)(r.out._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "allOf", t ? "1" : "0"] }));
      return {
        allOf: [t, n].filter((i) => i !== void 0)
      };
    };
    Cs.parsePipelineDef = qw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/promise.js
  var Ph = N((Ss) => {
    "use strict";
    Object.defineProperty(Ss, "__esModule", { value: true });
    Ss.parsePromiseDef = void 0;
    var Uw = xe();
    function Vw(r, e) {
      return (0, Uw.parseDef)(r.type._def, e);
    }
    Ss.parsePromiseDef = Vw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/string.js
  var au = N((js) => {
    "use strict";
    Object.defineProperty(js, "__esModule", { value: true });
    js.parseStringDef = void 0;
    var sn = tn();
    function zw(r, e) {
      const t = {
        type: "string"
      };
      if (r.checks) {
        for (const n of r.checks) {
          switch (n.kind) {
            case "min":
              (0, sn.setResponseValueAndErrors)(t, "minLength", typeof t.minLength === "number" ? Math.max(t.minLength, n.value) : n.value, n.message, e);
              break;
            case "max":
              (0, sn.setResponseValueAndErrors)(t, "maxLength", typeof t.maxLength === "number" ? Math.min(t.maxLength, n.value) : n.value, n.message, e);
              break;
            case "email":
              nn(t, "email", n.message, e);
              break;
            case "url":
              nn(t, "uri", n.message, e);
              break;
            case "uuid":
              nn(t, "uuid", n.message, e);
              break;
            case "regex":
              Yt(t, n.regex.source, n.message, e);
              break;
            case "cuid":
              Yt(t, "^c[^\\s-]{8,}$", n.message, e);
              break;
            case "cuid2":
              Yt(t, "^[a-z][a-z0-9]*$", n.message, e);
              break;
            case "startsWith":
              Yt(t, "^" + su(n.value), n.message, e);
              break;
            case "endsWith":
              Yt(t, su(n.value) + "$", n.message, e);
              break;
            case "datetime":
              nn(t, "date-time", n.message, e);
              break;
            case "length":
              (0, sn.setResponseValueAndErrors)(t, "minLength", typeof t.minLength === "number" ? Math.max(t.minLength, n.value) : n.value, n.message, e);
              (0, sn.setResponseValueAndErrors)(t, "maxLength", typeof t.maxLength === "number" ? Math.min(t.maxLength, n.value) : n.value, n.message, e);
              break;
            case "includes": {
              Yt(t, su(n.value), n.message, e);
              break;
            }
            case "ip": {
              if (n.version !== "v6") {
                nn(t, "ipv4", n.message, e);
              }
              if (n.version !== "v4") {
                nn(t, "ipv6", n.message, e);
              }
              break;
            }
            case "emoji":
              Yt(t, "/^(p{Extended_Pictographic}|p{Emoji_Component})+$/u", n.message, e);
              break;
            case "ulid": {
              Yt(t, "/[0-9A-HJKMNP-TV-Z]{26}/", n.message, e);
              break;
            }
            case "toLowerCase":
            case "toUpperCase":
            case "trim":
              break;
            default:
              ((i) => {
              })(n);
          }
        }
      }
      return t;
    }
    js.parseStringDef = zw;
    var su = (r) => Array.from(r).map((e) => /[a-zA-Z0-9]/.test(e) ? e : `\\${e}`).join("");
    var nn = (r, e, t, n) => {
      var i;
      if (r.format || ((i = r.anyOf) === null || i === void 0 ? void 0 : i.some((s) => s.format))) {
        if (!r.anyOf) {
          r.anyOf = [];
        }
        if (r.format) {
          r.anyOf.push(Object.assign({ format: r.format }, r.errorMessage && n.errorMessages && {
            errorMessage: { format: r.errorMessage.format }
          }));
          delete r.format;
          if (r.errorMessage) {
            delete r.errorMessage.format;
            if (Object.keys(r.errorMessage).length === 0) {
              delete r.errorMessage;
            }
          }
        }
        r.anyOf.push(Object.assign({ format: e }, t && n.errorMessages && { errorMessage: { format: t } }));
      } else {
        (0, sn.setResponseValueAndErrors)(r, "format", e, t, n);
      }
    };
    var Yt = (r, e, t, n) => {
      var i;
      if (r.pattern || ((i = r.allOf) === null || i === void 0 ? void 0 : i.some((s) => s.pattern))) {
        if (!r.allOf) {
          r.allOf = [];
        }
        if (r.pattern) {
          r.allOf.push(Object.assign({ pattern: r.pattern }, r.errorMessage && n.errorMessages && {
            errorMessage: { pattern: r.errorMessage.pattern }
          }));
          delete r.pattern;
          if (r.errorMessage) {
            delete r.errorMessage.pattern;
            if (Object.keys(r.errorMessage).length === 0) {
              delete r.errorMessage;
            }
          }
        }
        r.allOf.push(Object.assign({ pattern: e }, t && n.errorMessages && { errorMessage: { pattern: t } }));
      } else {
        (0, sn.setResponseValueAndErrors)(r, "pattern", e, t, n);
      }
    };
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/record.js
  var Eh = N((ks) => {
    "use strict";
    Object.defineProperty(ks, "__esModule", { value: true });
    ks.parseRecordDef = void 0;
    var ou = ls();
    var Ah = xe();
    var Fw = au();
    function Kw(r, e) {
      var t, n, i, s, a;
      if (e.target === "openApi3" && ((t = r.keyType) === null || t === void 0 ? void 0 : t._def.typeName) === ou.ZodFirstPartyTypeKind.ZodEnum) {
        return {
          type: "object",
          required: r.keyType._def.values,
          properties: r.keyType._def.values.reduce((u, l) => {
            var c;
            return Object.assign(Object.assign({}, u), { [l]: (c = (0, Ah.parseDef)(r.valueType._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "properties", l] }))) !== null && c !== void 0 ? c : {} });
          }, {}),
          additionalProperties: false
        };
      }
      const o = {
        type: "object",
        additionalProperties: (n = (0, Ah.parseDef)(r.valueType._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "additionalProperties"] }))) !== null && n !== void 0 ? n : {}
      };
      if (e.target === "openApi3") {
        return o;
      }
      if (((i = r.keyType) === null || i === void 0 ? void 0 : i._def.typeName) === ou.ZodFirstPartyTypeKind.ZodString && ((s = r.keyType._def.checks) === null || s === void 0 ? void 0 : s.length)) {
        const u = Object.entries((0, Fw.parseStringDef)(r.keyType._def, e)).reduce((l, [c, b]) => c === "type" ? l : Object.assign(Object.assign({}, l), { [c]: b }), {});
        return Object.assign(Object.assign({}, o), { propertyNames: u });
      } else if (((a = r.keyType) === null || a === void 0 ? void 0 : a._def.typeName) === ou.ZodFirstPartyTypeKind.ZodEnum) {
        return Object.assign(Object.assign({}, o), { propertyNames: {
          enum: r.keyType._def.values
        } });
      }
      return o;
    }
    ks.parseRecordDef = Kw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/set.js
  var Ih = N((Rs) => {
    "use strict";
    Object.defineProperty(Rs, "__esModule", { value: true });
    Rs.parseSetDef = void 0;
    var Th = tn();
    var Bw = xe();
    function $w(r, e) {
      const t = (0, Bw.parseDef)(r.valueType._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "items"] }));
      const n = {
        type: "array",
        uniqueItems: true,
        items: t
      };
      if (r.minSize) {
        (0, Th.setResponseValueAndErrors)(n, "minItems", r.minSize.value, r.minSize.message, e);
      }
      if (r.maxSize) {
        (0, Th.setResponseValueAndErrors)(n, "maxItems", r.maxSize.value, r.maxSize.message, e);
      }
      return n;
    }
    Rs.parseSetDef = $w;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/tuple.js
  var Ch = N((Ns) => {
    "use strict";
    Object.defineProperty(Ns, "__esModule", { value: true });
    Ns.parseTupleDef = void 0;
    var uu = xe();
    function Zw(r, e) {
      if (r.rest) {
        return {
          type: "array",
          minItems: r.items.length,
          items: r.items.map((t, n) => (0, uu.parseDef)(t._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "items", `${n}`] }))).reduce((t, n) => n === void 0 ? t : [...t, n], []),
          additionalItems: (0, uu.parseDef)(r.rest._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "additionalItems"] }))
        };
      } else {
        return {
          type: "array",
          minItems: r.items.length,
          maxItems: r.items.length,
          items: r.items.map((t, n) => (0, uu.parseDef)(t._def, Object.assign(Object.assign({}, e), { currentPath: [...e.currentPath, "items", `${n}`] }))).reduce((t, n) => n === void 0 ? t : [...t, n], [])
        };
      }
    }
    Ns.parseTupleDef = Zw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/undefined.js
  var Sh = N((Ms) => {
    "use strict";
    Object.defineProperty(Ms, "__esModule", { value: true });
    Ms.parseUndefinedDef = void 0;
    function Hw() {
      return {
        not: {}
      };
    }
    Ms.parseUndefinedDef = Hw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parsers/unknown.js
  var jh = N((Ls) => {
    "use strict";
    Object.defineProperty(Ls, "__esModule", { value: true });
    Ls.parseUnknownDef = void 0;
    function Qw() {
      return {};
    }
    Ls.parseUnknownDef = Qw;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/parseDef.js
  var xe = N((Ds) => {
    "use strict";
    Object.defineProperty(Ds, "__esModule", { value: true });
    Ds.parseDef = void 0;
    var re = ls();
    var Jw = Jp();
    var Yw = Gp();
    var Ww = Xp();
    var Gw = eh();
    var Xw = th();
    var e_ = rh();
    var t_ = nh();
    var r_ = ih();
    var n_ = sh();
    var i_ = ah();
    var s_ = uh();
    var a_ = lh();
    var o_ = dh();
    var u_ = ph();
    var l_ = hh();
    var c_ = fh();
    var d_ = bh();
    var p_ = gh();
    var h_ = _h();
    var f_ = xh();
    var m_ = Oh();
    var y_ = Ph();
    var b_ = Eh();
    var g_ = Ih();
    var w_ = au();
    var __ = Ch();
    var v_ = Sh();
    var x_ = nu();
    var O_ = jh();
    function kh(r, e, t = false) {
      const n = e.seen.get(r);
      if (n && !t) {
        return P_(n, e);
      }
      const i = { def: r, path: e.currentPath, jsonSchema: void 0 };
      e.seen.set(r, i);
      const s = E_(r, r.typeName, e);
      if (s) {
        T_(r, s);
      }
      i.jsonSchema = s;
      return s;
    }
    Ds.parseDef = kh;
    var P_ = (r, e) => {
      switch (e.$refStrategy) {
        case "root":
          return {
            $ref: r.path.length === 0 ? "" : r.path.length === 1 ? `${r.path[0]}/` : r.path.join("/")
          };
        case "relative":
          return { $ref: A_(e.currentPath, r.path) };
        case "none": {
          if (r.path.length < e.currentPath.length && r.path.every((t, n) => e.currentPath[n] === t)) {
            console.warn(`Recursive reference detected at ${e.currentPath.join("/")}! Defaulting to any`);
            return {};
          } else {
            return r.jsonSchema;
          }
        }
      }
    };
    var A_ = (r, e) => {
      let t = 0;
      for (; t < r.length && t < e.length; t++) {
        if (r[t] !== e[t])
          break;
      }
      return [(r.length - t).toString(), ...e.slice(t)].join("/");
    };
    var E_ = (r, e, t) => {
      switch (e) {
        case re.ZodFirstPartyTypeKind.ZodString:
          return (0, w_.parseStringDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodNumber:
          return (0, p_.parseNumberDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodObject:
          return (0, h_.parseObjectDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodBigInt:
          return (0, Ww.parseBigintDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodBoolean:
          return (0, Gw.parseBooleanDef)();
        case re.ZodFirstPartyTypeKind.ZodDate:
          return (0, t_.parseDateDef)();
        case re.ZodFirstPartyTypeKind.ZodUndefined:
          return (0, v_.parseUndefinedDef)();
        case re.ZodFirstPartyTypeKind.ZodNull:
          return (0, c_.parseNullDef)(t);
        case re.ZodFirstPartyTypeKind.ZodArray:
          return (0, Yw.parseArrayDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodUnion:
        case re.ZodFirstPartyTypeKind.ZodDiscriminatedUnion:
          return (0, x_.parseUnionDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodIntersection:
          return (0, s_.parseIntersectionDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodTuple:
          return (0, __.parseTupleDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodRecord:
          return (0, b_.parseRecordDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodLiteral:
          return (0, a_.parseLiteralDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodEnum:
          return (0, i_.parseEnumDef)(r);
        case re.ZodFirstPartyTypeKind.ZodNativeEnum:
          return (0, u_.parseNativeEnumDef)(r);
        case re.ZodFirstPartyTypeKind.ZodNullable:
          return (0, d_.parseNullableDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodOptional:
          return (0, f_.parseOptionalDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodMap:
          return (0, o_.parseMapDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodSet:
          return (0, g_.parseSetDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodLazy:
          return kh(r.getter()._def, t);
        case re.ZodFirstPartyTypeKind.ZodPromise:
          return (0, y_.parsePromiseDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodNaN:
        case re.ZodFirstPartyTypeKind.ZodNever:
          return (0, l_.parseNeverDef)();
        case re.ZodFirstPartyTypeKind.ZodEffects:
          return (0, n_.parseEffectsDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodAny:
          return (0, Jw.parseAnyDef)();
        case re.ZodFirstPartyTypeKind.ZodUnknown:
          return (0, O_.parseUnknownDef)();
        case re.ZodFirstPartyTypeKind.ZodDefault:
          return (0, r_.parseDefaultDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodBranded:
          return (0, Xw.parseBrandedDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodCatch:
          return (0, e_.parseCatchDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodPipeline:
          return (0, m_.parsePipelineDef)(r, t);
        case re.ZodFirstPartyTypeKind.ZodFunction:
        case re.ZodFirstPartyTypeKind.ZodVoid:
        case re.ZodFirstPartyTypeKind.ZodSymbol:
          return void 0;
        default:
          return ((n) => void 0)(e);
      }
    };
    var T_ = (r, e) => {
      if (r.description)
        e.description = r.description;
      return e;
    };
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/Options.js
  var Rh = N((Wt) => {
    "use strict";
    Object.defineProperty(Wt, "__esModule", { value: true });
    Wt.getDefaultOptions = Wt.defaultOptions = void 0;
    Wt.defaultOptions = {
      name: void 0,
      $refStrategy: "root",
      basePath: ["#"],
      effectStrategy: "input",
      pipeStrategy: "all",
      definitionPath: "definitions",
      target: "jsonSchema7",
      strictUnions: false,
      definitions: {},
      errorMessages: false
    };
    var I_ = (r) => typeof r === "string" ? Object.assign(Object.assign({}, Wt.defaultOptions), { name: r }) : Object.assign(Object.assign({}, Wt.defaultOptions), r);
    Wt.getDefaultOptions = I_;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/Refs.js
  var Nh = N((qs) => {
    "use strict";
    Object.defineProperty(qs, "__esModule", { value: true });
    qs.getRefs = void 0;
    var C_ = Rh();
    var S_ = (r) => {
      const e = (0, C_.getDefaultOptions)(r);
      const t = e.name !== void 0 ? [...e.basePath, e.definitionPath, e.name] : e.basePath;
      return Object.assign(Object.assign({}, e), { currentPath: t, propertyPath: void 0, seen: new Map(Object.entries(e.definitions).map(([n, i]) => [
        i._def,
        {
          def: i._def,
          path: [...e.basePath, e.definitionPath, n],
          // Resolution of references will be forced even though seen, so it's ok that the schema is undefined here for now.
          jsonSchema: void 0
        }
      ])) });
    };
    qs.getRefs = S_;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/src/zodToJsonSchema.js
  var Lh = N((Us) => {
    "use strict";
    Object.defineProperty(Us, "__esModule", { value: true });
    Us.zodToJsonSchema = void 0;
    var Mh = xe();
    var j_ = Nh();
    var k_ = (r, e) => {
      var t;
      const n = (0, j_.getRefs)(e);
      const i = typeof e === "object" && e.definitions ? Object.entries(e.definitions).reduce((u, [l, c]) => {
        var b;
        return Object.assign(Object.assign({}, u), { [l]: (b = (0, Mh.parseDef)(c._def, Object.assign(Object.assign({}, n), { currentPath: [...n.basePath, n.definitionPath, l] }), true)) !== null && b !== void 0 ? b : {} });
      }, {}) : void 0;
      const s = typeof e === "string" ? e : e === null || e === void 0 ? void 0 : e.name;
      const a = (t = (0, Mh.parseDef)(r._def, s === void 0 ? n : Object.assign(Object.assign({}, n), { currentPath: [...n.basePath, n.definitionPath, s] }), false)) !== null && t !== void 0 ? t : {};
      const o = s === void 0 ? i ? Object.assign(Object.assign({}, a), { [n.definitionPath]: i }) : a : {
        $ref: [
          ...n.$refStrategy === "relative" ? [] : n.basePath,
          n.definitionPath,
          s
        ].join("/"),
        [n.definitionPath]: Object.assign(Object.assign({}, i), { [s]: a })
      };
      if (n.target === "jsonSchema7") {
        o.$schema = "http://json-schema.org/draft-07/schema#";
      } else if (n.target === "jsonSchema2019-09") {
        o.$schema = "https://json-schema.org/draft/2019-09/schema#";
      }
      return o;
    };
    Us.zodToJsonSchema = k_;
  });

  // node_modules/.pnpm/zod-to-json-schema@3.21.1_zod@3.21.4/node_modules/zod-to-json-schema/index.js
  var lu = N((Kn) => {
    "use strict";
    Object.defineProperty(Kn, "__esModule", { value: true });
    Kn.zodToJsonSchema = void 0;
    var Dh = Lh();
    Object.defineProperty(Kn, "zodToJsonSchema", { enumerable: true, get: function() {
      return Dh.zodToJsonSchema;
    } });
    Kn.default = Dh.zodToJsonSchema;
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/tools/convert_to_openai.js
  function Uh(r) {
    return {
      name: r.name,
      description: r.description,
      parameters: (0, qh.zodToJsonSchema)(r.schema)
    };
  }
  var qh;
  var Vh = j(() => {
    qh = be(lu(), 1);
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chat_models/openai.js
  var zh = {};
  tt(zh, {
    ChatOpenAI: () => Vs,
    PromptLayerChatOpenAI: () => du
  });
  function cu(r) {
    switch (r) {
      case "system":
        return "system";
      case "ai":
        return "assistant";
      case "human":
        return "user";
      case "function":
        return "function";
      default:
        throw new Error(`Unknown message type: ${r}`);
    }
  }
  function R_(r) {
    switch (r.role) {
      case "user":
        return new lt(r.content || "");
      case "assistant":
        return new Ot(r.content || "", {
          function_call: r.function_call
        });
      case "system":
        return new Lr(r.content || "");
      default:
        return new Rn(r.content || "", r.role ?? "unknown");
    }
  }
  var zs, Vs, du;
  var Fh = j(() => {
    zs = be(Tr(), 1);
    _t();
    Nr();
    kp();
    ct();
    zr();
    ns();
    Vh();
    Vs = class extends rs {
      get callKeys() {
        return ["stop", "signal", "timeout", "options", "functions", "tools"];
      }
      get lc_secrets() {
        return {
          openAIApiKey: "OPENAI_API_KEY",
          azureOpenAIApiKey: "AZURE_OPENAI_API_KEY"
        };
      }
      get lc_aliases() {
        return {
          modelName: "model",
          openAIApiKey: "openai_api_key",
          azureOpenAIApiVersion: "azure_openai_api_version",
          azureOpenAIApiKey: "azure_openai_api_key",
          azureOpenAIApiInstanceName: "azure_openai_api_instance_name",
          azureOpenAIApiDeploymentName: "azure_openai_api_deployment_name"
        };
      }
      constructor(e, t) {
        super(e ?? {});
        Object.defineProperty(this, "lc_serializable", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: true
        });
        Object.defineProperty(this, "temperature", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 1
        });
        Object.defineProperty(this, "topP", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 1
        });
        Object.defineProperty(this, "frequencyPenalty", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 0
        });
        Object.defineProperty(this, "presencePenalty", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 0
        });
        Object.defineProperty(this, "n", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 1
        });
        Object.defineProperty(this, "logitBias", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "modelName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "gpt-3.5-turbo"
        });
        Object.defineProperty(this, "modelKwargs", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "stop", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "timeout", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "streaming", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        Object.defineProperty(this, "maxTokens", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "azureOpenAIApiVersion", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "azureOpenAIApiKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "azureOpenAIApiInstanceName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "azureOpenAIApiDeploymentName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "client", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "clientConfig", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        const n = e?.openAIApiKey ?? G("OPENAI_API_KEY");
        const i = e?.azureOpenAIApiKey ?? G("AZURE_OPENAI_API_KEY");
        if (!i && !n) {
          throw new Error("(Azure) OpenAI API key not found");
        }
        const s = e?.azureOpenAIApiInstanceName ?? G("AZURE_OPENAI_API_INSTANCE_NAME");
        const a = e?.azureOpenAIApiDeploymentName ?? G("AZURE_OPENAI_API_DEPLOYMENT_NAME");
        const o = e?.azureOpenAIApiVersion ?? G("AZURE_OPENAI_API_VERSION");
        this.modelName = e?.modelName ?? this.modelName;
        this.modelKwargs = e?.modelKwargs ?? {};
        this.timeout = e?.timeout;
        this.temperature = e?.temperature ?? this.temperature;
        this.topP = e?.topP ?? this.topP;
        this.frequencyPenalty = e?.frequencyPenalty ?? this.frequencyPenalty;
        this.presencePenalty = e?.presencePenalty ?? this.presencePenalty;
        this.maxTokens = e?.maxTokens;
        this.n = e?.n ?? this.n;
        this.logitBias = e?.logitBias;
        this.stop = e?.stop;
        this.streaming = e?.streaming ?? false;
        this.azureOpenAIApiVersion = o;
        this.azureOpenAIApiKey = i;
        this.azureOpenAIApiInstanceName = s;
        this.azureOpenAIApiDeploymentName = a;
        if (this.streaming && this.n > 1) {
          throw new Error("Cannot stream results when n > 1");
        }
        if (this.azureOpenAIApiKey) {
          if (!this.azureOpenAIApiInstanceName) {
            throw new Error("Azure OpenAI API instance name not found");
          }
          if (!this.azureOpenAIApiDeploymentName) {
            throw new Error("Azure OpenAI API deployment name not found");
          }
          if (!this.azureOpenAIApiVersion) {
            throw new Error("Azure OpenAI API version not found");
          }
        }
        this.clientConfig = {
          apiKey: n,
          ...t,
          ...e?.configuration
        };
      }
      /**
       * Get the parameters used to invoke the model
       */
      invocationParams() {
        return {
          model: this.modelName,
          temperature: this.temperature,
          top_p: this.topP,
          frequency_penalty: this.frequencyPenalty,
          presence_penalty: this.presencePenalty,
          max_tokens: this.maxTokens === -1 ? void 0 : this.maxTokens,
          n: this.n,
          logit_bias: this.logitBias,
          stop: this.stop,
          stream: this.streaming,
          ...this.modelKwargs
        };
      }
      /** @ignore */
      _identifyingParams() {
        return {
          model_name: this.modelName,
          ...this.invocationParams(),
          ...this.clientConfig
        };
      }
      /**
       * Get the identifying parameters for the model
       */
      identifyingParams() {
        return this._identifyingParams();
      }
      /** @ignore */
      async _generate(e, t, n) {
        const i = {};
        if (this.stop && t?.stop) {
          throw new Error("Stop found in input and default params");
        }
        const s = this.invocationParams();
        s.stop = t?.stop ?? s.stop;
        s.functions = t?.functions ?? (t?.tools ? t?.tools.map(Uh) : void 0);
        s.function_call = t?.function_call;
        const a = e.map((_) => ({
          role: cu(_._getType()),
          content: _.text,
          name: _.name
        }));
        const o = s.stream ? await new Promise((_, x) => {
          let f;
          let P = false;
          let S = false;
          this.completionWithRetry({
            ...s,
            messages: a
          }, {
            signal: t?.signal,
            ...t?.options,
            adapter: Fe,
            responseType: "stream",
            onmessage: (k) => {
              if (k.data?.trim?.() === "[DONE]") {
                if (S) {
                  return;
                }
                S = true;
                _(f);
              } else {
                const R = JSON.parse(k.data);
                if (!f) {
                  f = {
                    id: R.id,
                    object: R.object,
                    created: R.created,
                    model: R.model,
                    choices: []
                  };
                }
                for (const U of R.choices) {
                  if (U != null) {
                    let g = f.choices.find((C) => C.index === U.index);
                    if (!g) {
                      g = {
                        index: U.index,
                        finish_reason: U.finish_reason ?? void 0
                      };
                      f.choices[U.index] = g;
                    }
                    if (!g.message) {
                      g.message = {
                        role: U.delta?.role,
                        content: ""
                      };
                    }
                    if (U.delta.function_call && !g.message.function_call) {
                      g.message.function_call = {
                        name: "",
                        arguments: ""
                      };
                    }
                    g.message.content += U.delta?.content ?? "";
                    if (g.message.function_call) {
                      g.message.function_call.name += U.delta?.function_call?.name ?? "";
                      g.message.function_call.arguments += U.delta?.function_call?.arguments ?? "";
                    }
                    void n?.handleLLMNewToken(U.delta?.content ?? "");
                  }
                }
                if (!S && R.choices.every((U) => U.finish_reason != null)) {
                  S = true;
                  _(f);
                }
              }
            }
          }).catch((k) => {
            if (!P) {
              P = true;
              x(k);
            }
          });
        }) : await this.completionWithRetry({
          ...s,
          messages: a
        }, {
          signal: t?.signal,
          ...t?.options
        });
        const { completion_tokens: u, prompt_tokens: l, total_tokens: c } = o.usage ?? {};
        if (u) {
          i.completionTokens = (i.completionTokens ?? 0) + u;
        }
        if (l) {
          i.promptTokens = (i.promptTokens ?? 0) + l;
        }
        if (c) {
          i.totalTokens = (i.totalTokens ?? 0) + c;
        }
        const b = [];
        for (const _ of o.choices) {
          const x = _.message?.content ?? "";
          b.push({
            text: x,
            message: R_(_.message ?? { role: "assistant" })
          });
        }
        return {
          generations: b,
          llmOutput: { tokenUsage: i }
        };
      }
      async getNumTokensFromMessages(e) {
        let t = 0;
        let n = 0;
        let i = 0;
        if (Vr(this.modelName) === "gpt-3.5-turbo") {
          n = 4;
          i = -1;
        } else if (Vr(this.modelName).startsWith("gpt-4")) {
          n = 3;
          i = 1;
        }
        const s = await Promise.all(e.map(async (a) => {
          const o = await this.getNumTokens(a.text);
          const u = await this.getNumTokens(cu(a._getType()));
          const l = a.name !== void 0 ? i + await this.getNumTokens(a.name) : 0;
          const c = o + n + u + l;
          t += c;
          return c;
        }));
        t += 3;
        return { totalCount: t, countPerMessage: s };
      }
      /** @ignore */
      async completionWithRetry(e, t) {
        if (!this.client) {
          const i = this.azureOpenAIApiKey ? `https://${this.azureOpenAIApiInstanceName}.openai.azure.com/openai/deployments/${this.azureOpenAIApiDeploymentName}` : this.clientConfig.basePath;
          const s = new zs.Configuration({
            ...this.clientConfig,
            basePath: i,
            baseOptions: {
              timeout: this.timeout,
              ...this.clientConfig.baseOptions
            }
          });
          this.client = new zs.OpenAIApi(s);
        }
        const n = {
          adapter: wt() ? void 0 : Fe,
          ...this.clientConfig.baseOptions,
          ...t
        };
        if (this.azureOpenAIApiKey) {
          n.headers = {
            "api-key": this.azureOpenAIApiKey,
            ...n.headers
          };
          n.params = {
            "api-version": this.azureOpenAIApiVersion,
            ...n.params
          };
        }
        return this.caller.call(this.client.createChatCompletion.bind(this.client), e, n).then((i) => i.data);
      }
      _llmType() {
        return "openai";
      }
      /** @ignore */
      _combineLLMOutput(...e) {
        return e.reduce((t, n) => {
          if (n && n.tokenUsage) {
            t.tokenUsage.completionTokens += n.tokenUsage.completionTokens ?? 0;
            t.tokenUsage.promptTokens += n.tokenUsage.promptTokens ?? 0;
            t.tokenUsage.totalTokens += n.tokenUsage.totalTokens ?? 0;
          }
          return t;
        }, {
          tokenUsage: {
            completionTokens: 0,
            promptTokens: 0,
            totalTokens: 0
          }
        });
      }
    };
    du = class extends Vs {
      constructor(e) {
        super(e);
        Object.defineProperty(this, "promptLayerApiKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "plTags", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "returnPromptLayerId", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.promptLayerApiKey = e?.promptLayerApiKey ?? (typeof process !== "undefined" ? (
          // eslint-disable-next-line no-process-env
          process.env?.PROMPTLAYER_API_KEY
        ) : void 0);
        this.plTags = e?.plTags ?? [];
        this.returnPromptLayerId = e?.returnPromptLayerId ?? false;
      }
      async _generate(e, t, n) {
        const i = Date.now();
        let s;
        if (Array.isArray(t)) {
          s = { stop: t };
        } else if (t?.timeout && !t.signal) {
          s = {
            ...t,
            signal: AbortSignal.timeout(t.timeout)
          };
        } else {
          s = t ?? {};
        }
        const a = await super._generate(e, s, n);
        const o = Date.now();
        const u = (c) => {
          let b;
          if (c._getType() === "human") {
            b = { role: "user", content: c.text };
          } else if (c._getType() === "ai") {
            b = { role: "assistant", content: c.text };
          } else if (c._getType() === "system") {
            b = { role: "system", content: c.text };
          } else if (c._getType() === "generic") {
            b = {
              role: c.role,
              content: c.text
            };
          } else {
            throw new Error(`Got unknown type ${c}`);
          }
          return b;
        };
        const l = (c, b) => {
          const _ = {
            ...this.invocationParams(),
            model: this.modelName
          };
          if (b?.stop) {
            if (Object.keys(_).includes("stop")) {
              throw new Error("`stop` found in both the input and default params.");
            }
          }
          const x = c.map((f) => u(f));
          return x;
        };
        for (let c = 0; c < a.generations.length; c += 1) {
          const b = a.generations[c];
          const _ = l(e, s);
          let x;
          const f = [
            {
              content: b.text,
              role: cu(b.message._getType())
            }
          ];
          const P = await $r(this.caller, "langchain.PromptLayerChatOpenAI", _, this._identifyingParams(), this.plTags, f, i, o, this.promptLayerApiKey);
          if (this.returnPromptLayerId === true) {
            if (P.success === true) {
              x = P.request_id;
            }
            if (!b.generationInfo || typeof b.generationInfo !== "object") {
              b.generationInfo = {};
            }
            b.generationInfo.promptLayerRequestId = x;
          }
        }
        return a;
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/base_language/index.js
  var N_, Bn, Et;
  var Br = j(() => {
    Mn();
    zr();
    Bi();
    rr();
    zr();
    N_ = () => false;
    Bn = class extends Te {
      get lc_attributes() {
        return {
          callbacks: void 0,
          verbose: void 0
        };
      }
      constructor(e) {
        super(e);
        Object.defineProperty(this, "verbose", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "callbacks", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "tags", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.verbose = e.verbose ?? N_();
        this.callbacks = e.callbacks;
        this.tags = e.tags ?? [];
      }
    };
    Et = class extends Bn {
      /**
       * Keys that the language model accepts as call options.
       */
      get callKeys() {
        return ["stop", "timeout", "signal"];
      }
      constructor({ callbacks: e, callbackManager: t, ...n }) {
        super({
          callbacks: e ?? t,
          ...n
        });
        Object.defineProperty(this, "caller", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "_encoding", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.caller = new Pt(n ?? {});
      }
      async getNumTokens(e) {
        let t = Math.ceil(e.length / 4);
        if (!this._encoding) {
          try {
            this._encoding = await Ki("modelName" in this ? Vr(this.modelName) : "gpt2");
          } catch (n) {
            console.warn("Failed to calculate number of tokens, falling back to approximate count", n);
          }
        }
        if (this._encoding) {
          t = this._encoding.encode(e).length;
        }
        return t;
      }
      /**
       * Get the identifying parameters of the LLM.
       */
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      _identifyingParams() {
        return {};
      }
      /**
       * @deprecated
       * Return a json-like object representing this LLM.
       */
      serialize() {
        return {
          ...this._identifyingParams(),
          _type: this._llmType(),
          _model: this._modelType()
        };
      }
      /**
       * @deprecated
       * Load an LLM from a json-like object describing it.
       */
      static async deserialize(e) {
        const { _type: t, _model: n, ...i } = e;
        if (n && n !== "base_chat_model") {
          throw new Error(`Cannot load LLM with model ${n}`);
        }
        const s = {
          openai: (await Promise.resolve().then(() => (Fh(), zh))).ChatOpenAI
        }[t];
        if (s === void 0) {
          throw new Error(`Cannot load  LLM with type ${t}`);
        }
        return new s(i);
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/llms/base.js
  var $n, Fs;
  var pu = j(() => {
    Dd();
    ct();
    Br();
    ts();
    Kr();
    $n = class extends Et {
      constructor({ cache: e, concurrency: t, ...n }) {
        super(t ? { maxConcurrency: t, ...n } : n);
        Object.defineProperty(this, "lc_namespace", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: ["langchain", "llms", this._llmType()]
        });
        Object.defineProperty(this, "cache", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        if (typeof e === "object") {
          this.cache = e;
        } else if (e) {
          this.cache = Ur.global();
        } else {
          this.cache = void 0;
        }
      }
      async generatePrompt(e, t, n) {
        const i = e.map((s) => s.toString());
        return this.generate(i, t, n);
      }
      /**
       * Get the parameters used to invoke the model
       */
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      invocationParams() {
        return {};
      }
      /** @ignore */
      async _generateUncached(e, t, n) {
        const i = await qe.configure(n, this.callbacks, t.tags, this.tags, { verbose: this.verbose });
        const s = { options: t, invocation_params: this?.invocationParams() };
        const a = await i?.handleLLMStart(this.toJSON(), e, void 0, void 0, s);
        let o;
        try {
          o = await this._generate(e, t, a);
        } catch (u) {
          await a?.handleLLMError(u);
          throw u;
        }
        await a?.handleLLMEnd(o);
        Object.defineProperty(o, qr, {
          value: a ? { runId: a?.runId } : void 0,
          configurable: true
        });
        return o;
      }
      /**
       * Run the LLM on the given propmts an input, handling caching.
       */
      async generate(e, t, n) {
        if (!Array.isArray(e)) {
          throw new Error("Argument 'prompts' is expected to be a string[]");
        }
        let i;
        if (Array.isArray(t)) {
          i = { stop: t };
        } else if (t?.timeout && !t.signal) {
          i = {
            ...t,
            signal: AbortSignal.timeout(t.timeout)
          };
        } else {
          i = t ?? {};
        }
        if (!this.cache) {
          return this._generateUncached(e, i, n);
        }
        const { cache: s } = this;
        const a = this.serialize();
        a.stop = i.stop ?? a.stop;
        const o = `${Object.entries(a).sort()}`;
        const u = [];
        const l = await Promise.all(e.map(async (b, _) => {
          const x = await s.lookup(b, o);
          if (!x) {
            u.push(_);
          }
          return x;
        }));
        let c = {};
        if (u.length > 0) {
          const b = await this._generateUncached(u.map((_) => e[_]), i, n);
          await Promise.all(b.generations.map(async (_, x) => {
            const f = u[x];
            l[f] = _;
            return s.update(e[f], o, _);
          }));
          c = b.llmOutput ?? {};
        }
        return { generations: l, llmOutput: c };
      }
      /**
       * Convenience wrapper for {@link generate} that takes in a single string prompt and returns a single string output.
       */
      async call(e, t, n) {
        const { generations: i } = await this.generate([e], t ?? {}, n);
        return i[0][0].text;
      }
      async predict(e, t, n) {
        return this.call(e, t, n);
      }
      async predictMessages(e, t, n) {
        const i = sr(e);
        const s = await this.call(i, t, n);
        return new Ot(s);
      }
      /**
       * Get the identifying parameters of the LLM.
       */
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      _identifyingParams() {
        return {};
      }
      /**
       * Return a json-like object representing this LLM.
       */
      serialize() {
        return {
          ...this._identifyingParams(),
          _type: this._llmType(),
          _model: this._modelType()
        };
      }
      _modelType() {
        return "base_llm";
      }
      /**
       * Load an LLM from a json-like object describing it.
       */
      static async deserialize(e) {
        const { _type: t, _model: n, ...i } = e;
        if (n && n !== "base_llm") {
          throw new Error(`Cannot load LLM with model ${n}`);
        }
        const s = {
          openai: (await Promise.resolve().then(() => (hu(), Kh))).OpenAI
        }[t];
        if (s === void 0) {
          throw new Error(`Cannot load  LLM with type ${t}`);
        }
        return new s(i);
      }
    };
    Fs = class extends $n {
      async _generate(e, t, n) {
        const i = await Promise.all(e.map((s) => this._call(s, t, n).then((a) => [{ text: a }])));
        return { generations: i };
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/llms/openai-chat.js
  var Bs, wr, Ks;
  var fu = j(() => {
    Bs = be(Tr(), 1);
    _t();
    Nr();
    pu();
    ns();
    wr = class extends Fs {
      get callKeys() {
        return ["stop", "signal", "timeout", "options"];
      }
      get lc_secrets() {
        return {
          openAIApiKey: "OPENAI_API_KEY",
          azureOpenAIApiKey: "AZURE_OPENAI_API_KEY"
        };
      }
      get lc_aliases() {
        return {
          modelName: "model",
          openAIApiKey: "openai_api_key",
          azureOpenAIApiVersion: "azure_openai_api_version",
          azureOpenAIApiKey: "azure_openai_api_key",
          azureOpenAIApiInstanceName: "azure_openai_api_instance_name",
          azureOpenAIApiDeploymentName: "azure_openai_api_deployment_name"
        };
      }
      constructor(e, t) {
        super(e ?? {});
        Object.defineProperty(this, "lc_serializable", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: true
        });
        Object.defineProperty(this, "temperature", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 1
        });
        Object.defineProperty(this, "topP", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 1
        });
        Object.defineProperty(this, "frequencyPenalty", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 0
        });
        Object.defineProperty(this, "presencePenalty", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 0
        });
        Object.defineProperty(this, "n", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 1
        });
        Object.defineProperty(this, "logitBias", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "maxTokens", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "modelName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "gpt-3.5-turbo"
        });
        Object.defineProperty(this, "prefixMessages", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "modelKwargs", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "timeout", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "stop", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "streaming", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        Object.defineProperty(this, "azureOpenAIApiVersion", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "azureOpenAIApiKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "azureOpenAIApiInstanceName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "azureOpenAIApiDeploymentName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "client", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "clientConfig", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        const n = e?.openAIApiKey ?? G("OPENAI_API_KEY");
        const i = e?.azureOpenAIApiKey ?? G("AZURE_OPENAI_API_KEY");
        if (!i && !n) {
          throw new Error("(Azure) OpenAI API key not found");
        }
        const s = e?.azureOpenAIApiInstanceName ?? G("AZURE_OPENAI_API_INSTANCE_NAME");
        const a = e?.azureOpenAIApiDeploymentName ?? G("AZURE_OPENAI_API_DEPLOYMENT_NAME");
        const o = e?.azureOpenAIApiVersion ?? G("AZURE_OPENAI_API_VERSION");
        this.modelName = e?.modelName ?? this.modelName;
        this.prefixMessages = e?.prefixMessages ?? this.prefixMessages;
        this.modelKwargs = e?.modelKwargs ?? {};
        this.timeout = e?.timeout;
        this.temperature = e?.temperature ?? this.temperature;
        this.topP = e?.topP ?? this.topP;
        this.frequencyPenalty = e?.frequencyPenalty ?? this.frequencyPenalty;
        this.presencePenalty = e?.presencePenalty ?? this.presencePenalty;
        this.n = e?.n ?? this.n;
        this.logitBias = e?.logitBias;
        this.maxTokens = e?.maxTokens;
        this.stop = e?.stop;
        this.streaming = e?.streaming ?? false;
        this.azureOpenAIApiVersion = o;
        this.azureOpenAIApiKey = i;
        this.azureOpenAIApiInstanceName = s;
        this.azureOpenAIApiDeploymentName = a;
        if (this.streaming && this.n > 1) {
          throw new Error("Cannot stream results when n > 1");
        }
        if (this.azureOpenAIApiKey) {
          if (!this.azureOpenAIApiInstanceName) {
            throw new Error("Azure OpenAI API instance name not found");
          }
          if (!this.azureOpenAIApiDeploymentName) {
            throw new Error("Azure OpenAI API deployment name not found");
          }
          if (!this.azureOpenAIApiVersion) {
            throw new Error("Azure OpenAI API version not found");
          }
        }
        this.clientConfig = {
          apiKey: n,
          ...t,
          ...e?.configuration
        };
      }
      /**
       * Get the parameters used to invoke the model
       */
      invocationParams() {
        return {
          model: this.modelName,
          temperature: this.temperature,
          top_p: this.topP,
          frequency_penalty: this.frequencyPenalty,
          presence_penalty: this.presencePenalty,
          n: this.n,
          logit_bias: this.logitBias,
          max_tokens: this.maxTokens === -1 ? void 0 : this.maxTokens,
          stop: this.stop,
          stream: this.streaming,
          ...this.modelKwargs
        };
      }
      /** @ignore */
      _identifyingParams() {
        return {
          model_name: this.modelName,
          ...this.invocationParams(),
          ...this.clientConfig
        };
      }
      /**
       * Get the identifying parameters for the model
       */
      identifyingParams() {
        return {
          model_name: this.modelName,
          ...this.invocationParams(),
          ...this.clientConfig
        };
      }
      formatMessages(e) {
        const t = {
          role: "user",
          content: e
        };
        return this.prefixMessages ? [...this.prefixMessages, t] : [t];
      }
      /** @ignore */
      async _call(e, t, n) {
        const { stop: i } = t;
        const s = this.invocationParams();
        s.stop = i ?? s.stop;
        const a = s.stream ? await new Promise((o, u) => {
          let l;
          let c = false;
          let b = false;
          this.completionWithRetry({
            ...s,
            messages: this.formatMessages(e)
          }, {
            signal: t.signal,
            ...t.options,
            adapter: Fe,
            responseType: "stream",
            onmessage: (_) => {
              if (_.data?.trim?.() === "[DONE]") {
                if (b) {
                  return;
                }
                b = true;
                o(l);
              } else {
                const x = JSON.parse(_.data);
                if (!l) {
                  l = {
                    id: x.id,
                    object: x.object,
                    created: x.created,
                    model: x.model,
                    choices: []
                  };
                }
                for (const f of x.choices) {
                  if (f != null) {
                    let P = l.choices.find((S) => S.index === f.index);
                    if (!P) {
                      P = {
                        index: f.index,
                        finish_reason: f.finish_reason ?? void 0
                      };
                      l.choices.push(P);
                    }
                    if (!P.message) {
                      P.message = {
                        role: f.delta?.role,
                        content: f.delta?.content ?? ""
                      };
                    }
                    P.message.content += f.delta?.content ?? "";
                    void n?.handleLLMNewToken(f.delta?.content ?? "");
                  }
                }
                if (!b && x.choices.every((f) => f.finish_reason != null)) {
                  b = true;
                  o(l);
                }
              }
            }
          }).catch((_) => {
            if (!c) {
              c = true;
              u(_);
            }
          });
        }) : await this.completionWithRetry({
          ...s,
          messages: this.formatMessages(e)
        }, {
          signal: t.signal,
          ...t.options
        });
        return a.choices[0].message?.content ?? "";
      }
      /** @ignore */
      async completionWithRetry(e, t) {
        if (!this.client) {
          const i = this.azureOpenAIApiKey ? `https://${this.azureOpenAIApiInstanceName}.openai.azure.com/openai/deployments/${this.azureOpenAIApiDeploymentName}` : this.clientConfig.basePath;
          const s = new Bs.Configuration({
            ...this.clientConfig,
            basePath: i,
            baseOptions: {
              timeout: this.timeout,
              ...this.clientConfig.baseOptions
            }
          });
          this.client = new Bs.OpenAIApi(s);
        }
        const n = {
          adapter: wt() ? void 0 : Fe,
          ...this.clientConfig.baseOptions,
          ...t
        };
        if (this.azureOpenAIApiKey) {
          n.headers = {
            "api-key": this.azureOpenAIApiKey,
            ...n.headers
          };
          n.params = {
            "api-version": this.azureOpenAIApiVersion,
            ...n.params
          };
        }
        return this.caller.call(this.client.createChatCompletion.bind(this.client), e, n).then((i) => i.data);
      }
      _llmType() {
        return "openai";
      }
    };
    Ks = class extends wr {
      get lc_secrets() {
        return {
          promptLayerApiKey: "PROMPTLAYER_API_KEY"
        };
      }
      constructor(e) {
        super(e);
        Object.defineProperty(this, "lc_serializable", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        Object.defineProperty(this, "promptLayerApiKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "plTags", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "returnPromptLayerId", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.plTags = e?.plTags ?? [];
        this.returnPromptLayerId = e?.returnPromptLayerId ?? false;
        this.promptLayerApiKey = e?.promptLayerApiKey ?? G("PROMPTLAYER_API_KEY");
        if (!this.promptLayerApiKey) {
          throw new Error("Missing PromptLayer API key");
        }
      }
      async completionWithRetry(e, t) {
        if (e.stream) {
          return super.completionWithRetry(e, t);
        }
        const n = await super.completionWithRetry(e);
        return n;
      }
      async _generate(e, t, n) {
        let i;
        const s = await Promise.all(e.map(async (a) => {
          const o = Date.now();
          const u = await this._call(a, t, n);
          const l = Date.now();
          i = [{ text: u }];
          const c = {
            text: u
          };
          const b = await $r(this.caller, "langchain.PromptLayerOpenAIChat", [a], this._identifyingParams(), this.plTags, c, o, l, this.promptLayerApiKey);
          if (this.returnPromptLayerId === true && b.success === true) {
            i[0].generationInfo = {
              promptLayerRequestId: b.request_id
            };
          }
          return i;
        }));
        return { generations: s };
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/llms/openai.js
  var Kh = {};
  tt(Kh, {
    OpenAI: () => an,
    OpenAIChat: () => wr,
    PromptLayerOpenAI: () => mu,
    PromptLayerOpenAIChat: () => Ks
  });
  var $s, an, mu;
  var hu = j(() => {
    $s = be(Tr(), 1);
    _t();
    Nr();
    xo();
    pu();
    zr();
    fu();
    ns();
    fu();
    an = class extends $n {
      get callKeys() {
        return ["stop", "signal", "timeout", "options"];
      }
      get lc_secrets() {
        return {
          openAIApiKey: "OPENAI_API_KEY",
          azureOpenAIApiKey: "AZURE_OPENAI_API_KEY"
        };
      }
      get lc_aliases() {
        return {
          modelName: "model",
          openAIApiKey: "openai_api_key",
          azureOpenAIApiVersion: "azure_openai_api_version",
          azureOpenAIApiKey: "azure_openai_api_key",
          azureOpenAIApiInstanceName: "azure_openai_api_instance_name",
          azureOpenAIApiDeploymentName: "azure_openai_api_deployment_name"
        };
      }
      constructor(e, t) {
        if (e?.modelName?.startsWith("gpt-3.5-turbo") || e?.modelName?.startsWith("gpt-4") || e?.modelName?.startsWith("gpt-4-32k")) {
          return new wr(e, t);
        }
        super(e ?? {});
        Object.defineProperty(this, "lc_serializable", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: true
        });
        Object.defineProperty(this, "temperature", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 0.7
        });
        Object.defineProperty(this, "maxTokens", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 256
        });
        Object.defineProperty(this, "topP", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 1
        });
        Object.defineProperty(this, "frequencyPenalty", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 0
        });
        Object.defineProperty(this, "presencePenalty", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 0
        });
        Object.defineProperty(this, "n", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 1
        });
        Object.defineProperty(this, "bestOf", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 1
        });
        Object.defineProperty(this, "logitBias", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "modelName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "text-davinci-003"
        });
        Object.defineProperty(this, "modelKwargs", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "batchSize", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 20
        });
        Object.defineProperty(this, "timeout", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "stop", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "streaming", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        Object.defineProperty(this, "azureOpenAIApiVersion", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "azureOpenAIApiKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "azureOpenAIApiInstanceName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "azureOpenAIApiDeploymentName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "client", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "clientConfig", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        const n = e?.openAIApiKey ?? G("OPENAI_API_KEY");
        const i = e?.azureOpenAIApiKey ?? G("AZURE_OPENAI_API_KEY");
        if (!i && !n) {
          throw new Error("(Azure) OpenAI API key not found");
        }
        const s = e?.azureOpenAIApiInstanceName ?? G("AZURE_OPENAI_API_INSTANCE_NAME");
        const a = (e?.azureOpenAIApiCompletionsDeploymentName || e?.azureOpenAIApiDeploymentName) ?? (G("AZURE_OPENAI_API_COMPLETIONS_DEPLOYMENT_NAME") || G("AZURE_OPENAI_API_DEPLOYMENT_NAME"));
        const o = e?.azureOpenAIApiVersion ?? G("AZURE_OPENAI_API_VERSION");
        this.modelName = e?.modelName ?? this.modelName;
        this.modelKwargs = e?.modelKwargs ?? {};
        this.batchSize = e?.batchSize ?? this.batchSize;
        this.timeout = e?.timeout;
        this.temperature = e?.temperature ?? this.temperature;
        this.maxTokens = e?.maxTokens ?? this.maxTokens;
        this.topP = e?.topP ?? this.topP;
        this.frequencyPenalty = e?.frequencyPenalty ?? this.frequencyPenalty;
        this.presencePenalty = e?.presencePenalty ?? this.presencePenalty;
        this.n = e?.n ?? this.n;
        this.bestOf = e?.bestOf ?? this.bestOf;
        this.logitBias = e?.logitBias;
        this.stop = e?.stop;
        this.streaming = e?.streaming ?? false;
        this.azureOpenAIApiVersion = o;
        this.azureOpenAIApiKey = i;
        this.azureOpenAIApiInstanceName = s;
        this.azureOpenAIApiDeploymentName = a;
        if (this.streaming && this.n > 1) {
          throw new Error("Cannot stream results when n > 1");
        }
        if (this.streaming && this.bestOf > 1) {
          throw new Error("Cannot stream results when bestOf > 1");
        }
        if (this.azureOpenAIApiKey) {
          if (!this.azureOpenAIApiInstanceName) {
            throw new Error("Azure OpenAI API instance name not found");
          }
          if (!this.azureOpenAIApiDeploymentName) {
            throw new Error("Azure OpenAI API deployment name not found");
          }
          if (!this.azureOpenAIApiVersion) {
            throw new Error("Azure OpenAI API version not found");
          }
        }
        this.clientConfig = {
          apiKey: n,
          ...t,
          ...e?.configuration
        };
      }
      /**
       * Get the parameters used to invoke the model
       */
      invocationParams() {
        return {
          model: this.modelName,
          temperature: this.temperature,
          max_tokens: this.maxTokens,
          top_p: this.topP,
          frequency_penalty: this.frequencyPenalty,
          presence_penalty: this.presencePenalty,
          n: this.n,
          best_of: this.bestOf,
          logit_bias: this.logitBias,
          stop: this.stop,
          stream: this.streaming,
          ...this.modelKwargs
        };
      }
      _identifyingParams() {
        return {
          model_name: this.modelName,
          ...this.invocationParams(),
          ...this.clientConfig
        };
      }
      /**
       * Get the identifying parameters for the model
       */
      identifyingParams() {
        return this._identifyingParams();
      }
      /**
       * Call out to OpenAI's endpoint with k unique prompts
       *
       * @param [prompts] - The prompts to pass into the model.
       * @param [options] - Optional list of stop words to use when generating.
       * @param [runManager] - Optional callback manager to use when generating.
       *
       * @returns The full LLM output.
       *
       * @example
       * ```ts
       * import { OpenAI } from "langchain/llms/openai";
       * const openai = new OpenAI();
       * const response = await openai.generate(["Tell me a joke."]);
       * ```
       */
      async _generate(e, t, n) {
        const { stop: i } = t;
        const s = kn(e, this.batchSize);
        const a = [];
        const o = {};
        if (this.stop && i) {
          throw new Error("Stop found in input and default params");
        }
        const u = this.invocationParams();
        u.stop = i ?? u.stop;
        if (u.max_tokens === -1) {
          if (e.length !== 1) {
            throw new Error("max_tokens set to -1 not supported for multiple inputs");
          }
          u.max_tokens = await $i({
            prompt: e[0],
            // Cast here to allow for other models that may not fit the union
            modelName: this.modelName
          });
        }
        for (let c = 0; c < s.length; c += 1) {
          const b = u.stream ? await new Promise((P, S) => {
            const k = [];
            let R;
            let U = false;
            let g = false;
            this.completionWithRetry({
              ...u,
              prompt: s[c]
            }, {
              signal: t.signal,
              ...t.options,
              adapter: Fe,
              responseType: "stream",
              onmessage: (C) => {
                if (C.data?.trim?.() === "[DONE]") {
                  if (g) {
                    return;
                  }
                  g = true;
                  P({
                    ...R,
                    choices: k
                  });
                } else {
                  const h = JSON.parse(C.data);
                  if (!R) {
                    R = {
                      id: h.id,
                      object: h.object,
                      created: h.created,
                      model: h.model
                    };
                  }
                  for (const y of h.choices) {
                    if (y != null && y.index != null) {
                      if (!k[y.index])
                        k[y.index] = {};
                      const p = k[y.index];
                      p.text = (p.text ?? "") + (y.text ?? "");
                      p.finish_reason = y.finish_reason;
                      p.logprobs = y.logprobs;
                      void n?.handleLLMNewToken(y.text ?? "");
                    }
                  }
                  if (!g && k.every((y) => y.finish_reason != null)) {
                    g = true;
                    P({
                      ...R,
                      choices: k
                    });
                  }
                }
              }
            }).catch((C) => {
              if (!U) {
                U = true;
                S(C);
              }
            });
          }) : await this.completionWithRetry({
            ...u,
            prompt: s[c]
          }, {
            signal: t.signal,
            ...t.options
          });
          a.push(...b.choices);
          const { completion_tokens: _, prompt_tokens: x, total_tokens: f } = b.usage ?? {};
          if (_) {
            o.completionTokens = (o.completionTokens ?? 0) + _;
          }
          if (x) {
            o.promptTokens = (o.promptTokens ?? 0) + x;
          }
          if (f) {
            o.totalTokens = (o.totalTokens ?? 0) + f;
          }
        }
        const l = kn(a, this.n).map((c) => c.map((b) => ({
          text: b.text ?? "",
          generationInfo: {
            finishReason: b.finish_reason,
            logprobs: b.logprobs
          }
        })));
        return {
          generations: l,
          llmOutput: { tokenUsage: o }
        };
      }
      /** @ignore */
      async completionWithRetry(e, t) {
        if (!this.client) {
          const i = this.azureOpenAIApiKey ? `https://${this.azureOpenAIApiInstanceName}.openai.azure.com/openai/deployments/${this.azureOpenAIApiDeploymentName}` : this.clientConfig.basePath;
          const s = new $s.Configuration({
            ...this.clientConfig,
            basePath: i,
            baseOptions: {
              timeout: this.timeout,
              ...this.clientConfig.baseOptions
            }
          });
          this.client = new $s.OpenAIApi(s);
        }
        const n = {
          adapter: wt() ? void 0 : Fe,
          ...this.clientConfig.baseOptions,
          ...t
        };
        if (this.azureOpenAIApiKey) {
          n.headers = {
            "api-key": this.azureOpenAIApiKey,
            ...n.headers
          };
          n.params = {
            "api-version": this.azureOpenAIApiVersion,
            ...n.params
          };
        }
        return this.caller.call(this.client.createCompletion.bind(this.client), e, n).then((i) => i.data);
      }
      _llmType() {
        return "openai";
      }
    };
    mu = class extends an {
      get lc_secrets() {
        return {
          promptLayerApiKey: "PROMPTLAYER_API_KEY"
        };
      }
      constructor(e) {
        super(e);
        Object.defineProperty(this, "lc_serializable", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        Object.defineProperty(this, "promptLayerApiKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "plTags", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "returnPromptLayerId", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.plTags = e?.plTags ?? [];
        this.promptLayerApiKey = e?.promptLayerApiKey ?? G("PROMPTLAYER_API_KEY");
        this.returnPromptLayerId = e?.returnPromptLayerId;
        if (!this.promptLayerApiKey) {
          throw new Error("Missing PromptLayer API key");
        }
      }
      async completionWithRetry(e, t) {
        if (e.stream) {
          return super.completionWithRetry(e, t);
        }
        const n = await super.completionWithRetry(e);
        return n;
      }
      async _generate(e, t, n) {
        const i = Date.now();
        const s = await super._generate(e, t, n);
        for (let a = 0; a < s.generations.length; a += 1) {
          const o = Date.now();
          const u = {
            text: s.generations[a][0].text,
            llm_output: s.llmOutput
          };
          const l = await $r(this.caller, "langchain.PromptLayerOpenAI", [e[a]], this._identifyingParams(), this.plTags, u, i, o, this.promptLayerApiKey);
          let c;
          if (this.returnPromptLayerId === true) {
            if (l && l.success === true) {
              c = l.request_id;
            }
            s.generations[a][0].generationInfo = {
              ...s.generations[a][0].generationInfo,
              promptLayerRequestId: c
            };
          }
        }
        return s;
      }
    };
  });

  // node_modules/.pnpm/binary-search@1.3.6/node_modules/binary-search/index.js
  var $h = N((gC, Bh) => {
    Bh.exports = function(r, e, t, n, i) {
      var s, a;
      if (n === void 0)
        n = 0;
      else {
        n = n | 0;
        if (n < 0 || n >= r.length)
          throw new RangeError("invalid lower bound");
      }
      if (i === void 0)
        i = r.length - 1;
      else {
        i = i | 0;
        if (i < n || i >= r.length)
          throw new RangeError("invalid upper bound");
      }
      while (n <= i) {
        s = n + (i - n >>> 1);
        a = +t(r[s], e, s, r);
        if (a < 0)
          n = s + 1;
        else if (a > 0)
          i = s - 1;
        else
          return s;
      }
      return ~n;
    };
  });

  // node_modules/.pnpm/num-sort@2.1.0/node_modules/num-sort/index.js
  var Zh = N((yu) => {
    "use strict";
    function ea(r) {
      if (typeof r !== "number") {
        throw new TypeError("Expected a number");
      }
    }
    yu.ascending = (r, e) => {
      ea(r);
      ea(e);
      if (Number.isNaN(r)) {
        return -1;
      }
      if (Number.isNaN(e)) {
        return 1;
      }
      return r - e;
    };
    yu.descending = (r, e) => {
      ea(r);
      ea(e);
      if (Number.isNaN(r)) {
        return 1;
      }
      if (Number.isNaN(e)) {
        return -1;
      }
      return e - r;
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/document.js
  var jt;
  var na = j(() => {
    jt = class {
      constructor(e) {
        Object.defineProperty(this, "pageContent", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "metadata", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.pageContent = e.pageContent ? e.pageContent.toString() : this.pageContent;
        this.metadata = e.metadata ?? {};
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/prompts/template.js
  var Wh, Cu, Iu, U_, un, Su, Yn;
  var ln = j(() => {
    Wh = (r) => {
      const e = r.split("");
      const t = [];
      const n = (s, a) => {
        for (let o = a; o < e.length; o += 1) {
          if (s.includes(e[o])) {
            return o;
          }
        }
        return -1;
      };
      let i = 0;
      while (i < e.length) {
        if (e[i] === "{" && i + 1 < e.length && e[i + 1] === "{") {
          t.push({ type: "literal", text: "{" });
          i += 2;
        } else if (e[i] === "}" && i + 1 < e.length && e[i + 1] === "}") {
          t.push({ type: "literal", text: "}" });
          i += 2;
        } else if (e[i] === "{") {
          const s = n("}", i);
          if (s < 0) {
            throw new Error("Unclosed '{' in template.");
          }
          t.push({
            type: "variable",
            name: e.slice(i + 1, s).join("")
          });
          i = s + 1;
        } else if (e[i] === "}") {
          throw new Error("Single '}' in template.");
        } else {
          const s = n("{}", i);
          const a = (s < 0 ? e.slice(i) : e.slice(i, s)).join("");
          t.push({ type: "literal", text: a });
          i = s < 0 ? e.length : s;
        }
      }
      return t;
    };
    Cu = (r, e) => Wh(r).reduce((t, n) => {
      if (n.type === "variable") {
        if (n.name in e) {
          return t + e[n.name];
        }
        throw new Error(`Missing value for input ${n.name}`);
      }
      return t + n.text;
    }, "");
    Iu = {
      "f-string": Cu,
      jinja2: (r, e) => ""
    };
    U_ = {
      "f-string": Wh,
      jinja2: (r) => []
    };
    un = (r, e, t) => Iu[e](r, t);
    Su = (r, e) => U_[e](r);
    Yn = (r, e, t) => {
      if (!(e in Iu)) {
        const n = Object.keys(Iu);
        throw new Error(`Invalid template format. Got \`${e}\`;
                         should be one of ${n}`);
      }
      try {
        const n = t.reduce((i, s) => {
          i[s] = "foo";
          return i;
        }, {});
        un(r, e, n);
      } catch {
        throw new Error("Invalid prompt schema.");
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/prompts/prompt.js
  var ju = {};
  tt(ju, {
    PromptTemplate: () => X
  });
  var X;
  var we = j(() => {
    kt();
    ln();
    X = class extends _r {
      constructor(e) {
        super(e);
        Object.defineProperty(this, "template", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "templateFormat", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "f-string"
        });
        Object.defineProperty(this, "validateTemplate", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: true
        });
        Object.assign(this, e);
        if (this.validateTemplate) {
          let t = this.inputVariables;
          if (this.partialVariables) {
            t = t.concat(Object.keys(this.partialVariables));
          }
          Yn(this.template, this.templateFormat, t);
        }
      }
      _getPromptType() {
        return "prompt";
      }
      async format(e) {
        const t = await this.mergePartialAndUserVariables(e);
        return un(this.template, this.templateFormat, t);
      }
      /**
       * Take examples in list format with prefix and suffix to create a prompt.
       *
       * Intendend to be used a a way to dynamically create a prompt from examples.
       *
       * @param examples - List of examples to use in the prompt.
       * @param suffix - String to go after the list of examples. Should generally set up the user's input.
       * @param inputVariables - A list of variable names the final prompt template will expect
       * @param exampleSeparator - The separator to use in between examples
       * @param prefix - String that should go before any examples. Generally includes examples.
       *
       * @returns The final prompt template generated.
       */
      static fromExamples(e, t, n, i = "\n\n", s = "") {
        const a = [s, ...e, t].join(i);
        return new X({
          inputVariables: n,
          template: a
        });
      }
      /**
       * Load prompt template from a template f-string
       */
      static fromTemplate(e, { templateFormat: t = "f-string", ...n } = {}) {
        const i = /* @__PURE__ */ new Set();
        Su(e, t).forEach((s) => {
          if (s.type === "variable") {
            i.add(s.name);
          }
        });
        return new X({
          inputVariables: [...i],
          templateFormat: t,
          template: e,
          ...n
        });
      }
      async partial(e) {
        const t = { ...this };
        t.inputVariables = this.inputVariables.filter((n) => !(n in e));
        t.partialVariables = {
          ...this.partialVariables ?? {},
          ...e
        };
        return new X(t);
      }
      serialize() {
        if (this.outputParser !== void 0) {
          throw new Error("Cannot serialize a prompt template with an output parser");
        }
        return {
          _type: this._getPromptType(),
          input_variables: this.inputVariables,
          template: this.template,
          template_format: this.templateFormat
        };
      }
      static async deserialize(e) {
        if (!e.template) {
          throw new Error("Prompt template must have a template");
        }
        const t = new X({
          inputVariables: e.input_variables,
          template: e.template,
          templateFormat: e.template_format
        });
        return t;
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/prompts/few_shot.js
  var Gh = {};
  tt(Gh, {
    FewShotPromptTemplate: () => Gt
  });
  var Gt;
  var ua = j(() => {
    kt();
    ln();
    we();
    Gt = class extends _r {
      constructor(e) {
        super(e);
        Object.defineProperty(this, "lc_serializable", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        Object.defineProperty(this, "examples", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "exampleSelector", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "examplePrompt", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "suffix", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: ""
        });
        Object.defineProperty(this, "exampleSeparator", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "\n\n"
        });
        Object.defineProperty(this, "prefix", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: ""
        });
        Object.defineProperty(this, "templateFormat", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "f-string"
        });
        Object.defineProperty(this, "validateTemplate", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: true
        });
        Object.assign(this, e);
        if (this.examples !== void 0 && this.exampleSelector !== void 0) {
          throw new Error("Only one of 'examples' and 'example_selector' should be provided");
        }
        if (this.examples === void 0 && this.exampleSelector === void 0) {
          throw new Error("One of 'examples' and 'example_selector' should be provided");
        }
        if (this.validateTemplate) {
          let t = this.inputVariables;
          if (this.partialVariables) {
            t = t.concat(Object.keys(this.partialVariables));
          }
          Yn(this.prefix + this.suffix, this.templateFormat, t);
        }
      }
      _getPromptType() {
        return "few_shot";
      }
      async getExamples(e) {
        if (this.examples !== void 0) {
          return this.examples;
        }
        if (this.exampleSelector !== void 0) {
          return this.exampleSelector.selectExamples(e);
        }
        throw new Error("One of 'examples' and 'example_selector' should be provided");
      }
      async partial(e) {
        const t = { ...this };
        t.inputVariables = this.inputVariables.filter((n) => !(n in e));
        t.partialVariables = {
          ...this.partialVariables ?? {},
          ...e
        };
        return new Gt(t);
      }
      async format(e) {
        const t = await this.mergePartialAndUserVariables(e);
        const n = await this.getExamples(t);
        const i = await Promise.all(n.map((a) => this.examplePrompt.format(a)));
        const s = [this.prefix, ...i, this.suffix].join(this.exampleSeparator);
        return un(s, this.templateFormat, t);
      }
      serialize() {
        if (this.exampleSelector || !this.examples) {
          throw new Error("Serializing an example selector is not currently supported");
        }
        if (this.outputParser !== void 0) {
          throw new Error("Serializing an output parser is not currently supported");
        }
        return {
          _type: this._getPromptType(),
          input_variables: this.inputVariables,
          example_prompt: this.examplePrompt.serialize(),
          example_separator: this.exampleSeparator,
          suffix: this.suffix,
          prefix: this.prefix,
          template_format: this.templateFormat,
          examples: this.examples
        };
      }
      static async deserialize(e) {
        const { example_prompt: t } = e;
        if (!t) {
          throw new Error("Missing example prompt");
        }
        const n = await X.deserialize(t);
        let i;
        if (Array.isArray(e.examples)) {
          i = e.examples;
        } else {
          throw new Error("Invalid examples format. Only list or string are supported.");
        }
        return new Gt({
          inputVariables: e.input_variables,
          examplePrompt: n,
          examples: i,
          exampleSeparator: e.example_separator,
          prefix: e.prefix,
          suffix: e.suffix,
          templateFormat: e.template_format
        });
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/prompts/base.js
  var la, Rt, _r;
  var kt = j(() => {
    ct();
    rr();
    la = class extends Dr {
      constructor(e) {
        super(...arguments);
        Object.defineProperty(this, "lc_namespace", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: ["langchain", "prompts", "base"]
        });
        Object.defineProperty(this, "value", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.value = e;
      }
      toString() {
        return this.value;
      }
      toChatMessages() {
        return [new lt(this.value)];
      }
    };
    Rt = class extends Te {
      get lc_attributes() {
        return {
          partialVariables: void 0
          // python doesn't support this yet
        };
      }
      constructor(e) {
        super(e);
        Object.defineProperty(this, "lc_serializable", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: true
        });
        Object.defineProperty(this, "lc_namespace", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: ["langchain", "prompts", this._getPromptType()]
        });
        Object.defineProperty(this, "inputVariables", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "outputParser", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "partialVariables", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: {}
        });
        const { inputVariables: t } = e;
        if (t.includes("stop")) {
          throw new Error("Cannot have an input variable named 'stop', as it is used internally, please rename.");
        }
        Object.assign(this, e);
      }
      async mergePartialAndUserVariables(e) {
        const t = this.partialVariables ?? {};
        const n = {};
        for (const [s, a] of Object.entries(t)) {
          if (typeof a === "string") {
            n[s] = a;
          } else {
            n[s] = await a();
          }
        }
        const i = { ...n, ...e };
        return i;
      }
      /**
       * Return a json-like object representing this prompt template.
       * @deprecated
       */
      serialize() {
        throw new Error("Use .toJSON() instead");
      }
      /**
       * @deprecated
       * Load a prompt template from a json-like object describing it.
       *
       * @remarks
       * Deserializing needs to be async because templates (e.g. {@link FewShotPromptTemplate}) can
       * reference remote resources that we read asynchronously with a web
       * request.
       */
      static async deserialize(e) {
        switch (e._type) {
          case "prompt": {
            const { PromptTemplate: t } = await Promise.resolve().then(() => (we(), ju));
            return t.deserialize(e);
          }
          case void 0: {
            const { PromptTemplate: t } = await Promise.resolve().then(() => (we(), ju));
            return t.deserialize({ ...e, _type: "prompt" });
          }
          case "few_shot": {
            const { FewShotPromptTemplate: t } = await Promise.resolve().then(() => (ua(), Gh));
            return t.deserialize(e);
          }
          default:
            throw new Error(`Invalid prompt type in config: ${e._type}`);
        }
      }
    };
    _r = class extends Rt {
      async formatPromptValue(e) {
        const t = await this.format(e);
        return new la(t);
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/llm_chain.js
  var Xh = {};
  tt(Xh, {
    LLMChain: () => ne
  });
  var ne;
  var Ve = j(() => {
    Ne();
    kt();
    Br();
    ne = class extends ue {
      get inputKeys() {
        return this.prompt.inputVariables;
      }
      get outputKeys() {
        return [this.outputKey];
      }
      constructor(e) {
        super(e);
        Object.defineProperty(this, "lc_serializable", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: true
        });
        Object.defineProperty(this, "prompt", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "llm", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "outputKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "text"
        });
        Object.defineProperty(this, "outputParser", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.prompt = e.prompt;
        this.llm = e.llm;
        this.outputKey = e.outputKey ?? this.outputKey;
        this.outputParser = e.outputParser ?? this.outputParser;
        if (this.prompt.outputParser) {
          if (this.outputParser) {
            throw new Error("Cannot set both outputParser and prompt.outputParser");
          }
          this.outputParser = this.prompt.outputParser;
        }
      }
      /** @ignore */
      async _getFinalOutput(e, t, n) {
        const i = e[0].text;
        let s;
        if (this.outputParser) {
          s = await this.outputParser.parseWithPrompt(i, t, n?.getChild());
        } else {
          s = i;
        }
        return s;
      }
      /**
       * Run the core logic of this chain and add to output if desired.
       *
       * Wraps _call and handles memory.
       */
      call(e, t) {
        return super.call(e, t);
      }
      /** @ignore */
      async _call(e, t) {
        const n = { ...e };
        const i = {};
        for (const o of this.llm.callKeys) {
          if (o in e) {
            i[o] = e[o];
            delete n[o];
          }
        }
        const s = await this.prompt.formatPromptValue(n);
        const { generations: a } = await this.llm.generatePrompt([s], i, t?.getChild());
        return {
          [this.outputKey]: await this._getFinalOutput(a[0], s, t)
        };
      }
      /**
       * Format prompt with values and pass to LLM
       *
       * @param values - keys to pass to prompt template
       * @param callbackManager - CallbackManager to use
       * @returns Completion from LLM.
       *
       * @example
       * ```ts
       * llm.predict({ adjective: "funny" })
       * ```
       */
      async predict(e, t) {
        const n = await this.call(e, t);
        return n[this.outputKey];
      }
      _chainType() {
        return "llm";
      }
      static async deserialize(e) {
        const { llm: t, prompt: n } = e;
        if (!t) {
          throw new Error("LLMChain must have llm");
        }
        if (!n) {
          throw new Error("LLMChain must have prompt");
        }
        return new ne({
          llm: await Et.deserialize(t),
          prompt: await Rt.deserialize(n)
        });
      }
      /** @deprecated */
      serialize() {
        return {
          _type: `${this._chainType()}_chain`,
          llm: this.llm.serialize(),
          prompt: this.prompt.serialize()
        };
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/util/set.js
  function ku(r, e) {
    const t = /* @__PURE__ */ new Set();
    for (const n of e) {
      if (r.has(n)) {
        t.add(n);
      }
    }
    return t;
  }
  function ef(r, e) {
    const t = new Set(r);
    for (const n of e) {
      t.add(n);
    }
    return t;
  }
  function ca(r, e) {
    const t = new Set(r);
    for (const n of e) {
      t.delete(n);
    }
    return t;
  }
  var tf = j(() => {
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/sequential_chain.js
  var Ru = {};
  tt(Ru, {
    SequentialChain: () => cn,
    SimpleSequentialChain: () => dn
  });
  function Wn(r) {
    return Array.from(r).map((e) => `"${e}"`).join(", ");
  }
  var cn, dn;
  var da = j(() => {
    Ne();
    tf();
    cn = class extends ue {
      get inputKeys() {
        return this.inputVariables;
      }
      get outputKeys() {
        return this.outputVariables;
      }
      constructor(e) {
        super(e);
        Object.defineProperty(this, "chains", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "inputVariables", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "outputVariables", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "returnAll", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.chains = e.chains;
        this.inputVariables = e.inputVariables;
        this.outputVariables = e.outputVariables ?? [];
        if (this.outputVariables.length > 0 && e.returnAll) {
          throw new Error("Either specify variables to return using `outputVariables` or use `returnAll` param. Cannot apply both conditions at the same time.");
        }
        this.returnAll = e.returnAll ?? false;
        this._validateChains();
      }
      /** @ignore */
      _validateChains() {
        if (this.chains.length === 0) {
          throw new Error("Sequential chain must have at least one chain.");
        }
        const e = this.memory?.memoryKeys ?? [];
        const t = new Set(this.inputKeys);
        const n = new Set(e);
        const i = ku(t, n);
        if (i.size > 0) {
          throw new Error(`The following keys: ${Wn(i)} are overlapping between memory and input keys of the chain variables. This can lead to unexpected behaviour. Please use input and memory keys that don't overlap.`);
        }
        const s = ef(t, n);
        for (const a of this.chains) {
          const o = ca(new Set(a.inputKeys), s);
          if (o.size > 0) {
            throw new Error(`Missing variables for chain "${a._chainType()}": ${Wn(o)}. Only got the following variables: ${Wn(s)}.`);
          }
          const u = new Set(a.outputKeys);
          const l = ku(s, u);
          if (l.size > 0) {
            throw new Error(`The following output variables for chain "${a._chainType()}" are overlapping: ${Wn(l)}. This can lead to unexpected behaviour.`);
          }
          for (const c of u) {
            s.add(c);
          }
        }
        if (this.outputVariables.length === 0) {
          if (this.returnAll) {
            const a = ca(s, t);
            this.outputVariables = Array.from(a);
          } else {
            this.outputVariables = this.chains[this.chains.length - 1].outputKeys;
          }
        } else {
          const a = ca(new Set(this.outputVariables), new Set(s));
          if (a.size > 0) {
            throw new Error(`The following output variables were expected to be in the final chain output but were not found: ${Wn(a)}.`);
          }
        }
      }
      /** @ignore */
      async _call(e, t) {
        let n = {};
        const i = e;
        let s = 0;
        for (const o of this.chains) {
          s += 1;
          n = await o.call(i, t?.getChild(`step_${s}`));
          for (const u of Object.keys(n)) {
            i[u] = n[u];
          }
        }
        const a = {};
        for (const o of this.outputVariables) {
          a[o] = i[o];
        }
        return a;
      }
      _chainType() {
        return "sequential_chain";
      }
      static async deserialize(e) {
        const t = [];
        const n = e.input_variables;
        const i = e.output_variables;
        const s = e.chains;
        for (const a of s) {
          const o = await ue.deserialize(a);
          t.push(o);
        }
        return new cn({ chains: t, inputVariables: n, outputVariables: i });
      }
      serialize() {
        const e = [];
        for (const t of this.chains) {
          e.push(t.serialize());
        }
        return {
          _type: this._chainType(),
          input_variables: this.inputVariables,
          output_variables: this.outputVariables,
          chains: e
        };
      }
    };
    dn = class extends ue {
      get inputKeys() {
        return [this.inputKey];
      }
      get outputKeys() {
        return [this.outputKey];
      }
      constructor(e) {
        super(e);
        Object.defineProperty(this, "chains", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "inputKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "input"
        });
        Object.defineProperty(this, "outputKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "output"
        });
        Object.defineProperty(this, "trimOutputs", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.chains = e.chains;
        this.trimOutputs = e.trimOutputs ?? false;
        this._validateChains();
      }
      /** @ignore */
      _validateChains() {
        for (const e of this.chains) {
          if (e.inputKeys.length !== 1) {
            throw new Error(`Chains used in SimpleSequentialChain should all have one input, got ${e.inputKeys.length} for ${e._chainType()}.`);
          }
          if (e.outputKeys.length !== 1) {
            throw new Error(`Chains used in SimpleSequentialChain should all have one output, got ${e.outputKeys.length} for ${e._chainType()}.`);
          }
        }
      }
      /** @ignore */
      async _call(e, t) {
        let n = e[this.inputKey];
        let i = 0;
        for (const s of this.chains) {
          i += 1;
          n = await s.run(n, t?.getChild(`step_${i}`));
          if (this.trimOutputs) {
            n = n.trim();
          }
          await t?.handleText(n);
        }
        return { [this.outputKey]: n };
      }
      _chainType() {
        return "simple_sequential_chain";
      }
      static async deserialize(e) {
        const t = [];
        const n = e.chains;
        for (const i of n) {
          const s = await ue.deserialize(i);
          t.push(s);
        }
        return new dn({ chains: t });
      }
      serialize() {
        const e = [];
        for (const t of this.chains) {
          e.push(t.serialize());
        }
        return {
          _type: this._chainType(),
          chains: e
        };
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/combine_docs_chain.js
  var pa = {};
  tt(pa, {
    MapReduceDocumentsChain: () => Nt,
    RefineDocumentsChain: () => yt,
    StuffDocumentsChain: () => Xe
  });
  var Xe, Nt, yt;
  var vr = j(() => {
    Ne();
    Ve();
    we();
    Xe = class extends ue {
      get inputKeys() {
        return [this.inputKey, ...this.llmChain.inputKeys].filter((e) => e !== this.documentVariableName);
      }
      get outputKeys() {
        return this.llmChain.outputKeys;
      }
      constructor(e) {
        super(e);
        Object.defineProperty(this, "llmChain", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "inputKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "input_documents"
        });
        Object.defineProperty(this, "documentVariableName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "context"
        });
        this.llmChain = e.llmChain;
        this.documentVariableName = e.documentVariableName ?? this.documentVariableName;
        this.inputKey = e.inputKey ?? this.inputKey;
      }
      /** @ignore */
      _prepInputs(e) {
        if (!(this.inputKey in e)) {
          throw new Error(`Document key ${this.inputKey} not found.`);
        }
        const { [this.inputKey]: t, ...n } = e;
        const i = t.map(({ pageContent: a }) => a);
        const s = i.join("\n\n");
        return {
          ...n,
          [this.documentVariableName]: s
        };
      }
      /** @ignore */
      async _call(e, t) {
        const n = await this.llmChain.call(this._prepInputs(e), t?.getChild("combine_documents"));
        return n;
      }
      _chainType() {
        return "stuff_documents_chain";
      }
      static async deserialize(e) {
        if (!e.llm_chain) {
          throw new Error("Missing llm_chain");
        }
        return new Xe({
          llmChain: await ne.deserialize(e.llm_chain)
        });
      }
      serialize() {
        return {
          _type: this._chainType(),
          llm_chain: this.llmChain.serialize()
        };
      }
    };
    Nt = class extends ue {
      get inputKeys() {
        return [this.inputKey, ...this.combineDocumentChain.inputKeys];
      }
      get outputKeys() {
        return this.combineDocumentChain.outputKeys;
      }
      constructor(e) {
        super(e);
        Object.defineProperty(this, "llmChain", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "inputKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "input_documents"
        });
        Object.defineProperty(this, "documentVariableName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "context"
        });
        Object.defineProperty(this, "returnIntermediateSteps", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        Object.defineProperty(this, "maxTokens", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 3e3
        });
        Object.defineProperty(this, "maxIterations", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 10
        });
        Object.defineProperty(this, "ensureMapStep", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        Object.defineProperty(this, "combineDocumentChain", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.llmChain = e.llmChain;
        this.combineDocumentChain = e.combineDocumentChain;
        this.documentVariableName = e.documentVariableName ?? this.documentVariableName;
        this.ensureMapStep = e.ensureMapStep ?? this.ensureMapStep;
        this.inputKey = e.inputKey ?? this.inputKey;
        this.maxTokens = e.maxTokens ?? this.maxTokens;
        this.maxIterations = e.maxIterations ?? this.maxIterations;
        this.returnIntermediateSteps = e.returnIntermediateSteps ?? false;
      }
      /** @ignore */
      async _call(e, t) {
        if (!(this.inputKey in e)) {
          throw new Error(`Document key ${this.inputKey} not found.`);
        }
        const { [this.inputKey]: n, ...i } = e;
        let s = n;
        let a = [];
        for (let l = 0; l < this.maxIterations; l += 1) {
          const c = s.map((f) => ({
            [this.documentVariableName]: f.pageContent,
            ...i
          }));
          const b = l !== 0 || !this.ensureMapStep;
          if (b) {
            const f = await this.combineDocumentChain.llmChain.prompt.format(this.combineDocumentChain._prepInputs({
              [this.combineDocumentChain.inputKey]: s,
              ...i
            }));
            const P = await this.combineDocumentChain.llmChain.llm.getNumTokens(f);
            const S = P < this.maxTokens;
            if (S) {
              break;
            }
          }
          const _ = await this.llmChain.apply(
            c,
            // If we have a runManager, then we need to create a child for each input
            // so that we can track the progress of each input.
            t ? Array.from({ length: c.length }, (f, P) => t.getChild(`map_${P + 1}`)) : void 0
          );
          const { outputKey: x } = this.llmChain;
          if (this.returnIntermediateSteps) {
            a = a.concat(_.map((f) => f[x]));
          }
          s = _.map((f) => ({
            pageContent: f[x],
            metadata: {}
          }));
        }
        const o = {
          [this.combineDocumentChain.inputKey]: s,
          ...i
        };
        const u = await this.combineDocumentChain.call(o, t?.getChild("combine_documents"));
        if (this.returnIntermediateSteps) {
          return { ...u, intermediateSteps: a };
        }
        return u;
      }
      _chainType() {
        return "map_reduce_documents_chain";
      }
      static async deserialize(e) {
        if (!e.llm_chain) {
          throw new Error("Missing llm_chain");
        }
        if (!e.combine_document_chain) {
          throw new Error("Missing combine_document_chain");
        }
        return new Nt({
          llmChain: await ne.deserialize(e.llm_chain),
          combineDocumentChain: await Xe.deserialize(e.combine_document_chain)
        });
      }
      serialize() {
        return {
          _type: this._chainType(),
          llm_chain: this.llmChain.serialize(),
          combine_document_chain: this.combineDocumentChain.serialize()
        };
      }
    };
    yt = class extends ue {
      get defaultDocumentPrompt() {
        return new X({
          inputVariables: ["page_content"],
          template: "{page_content}"
        });
      }
      get inputKeys() {
        return [
          .../* @__PURE__ */ new Set([
            this.inputKey,
            ...this.llmChain.inputKeys,
            ...this.refineLLMChain.inputKeys
          ])
        ].filter((e) => e !== this.documentVariableName && e !== this.initialResponseName);
      }
      get outputKeys() {
        return [this.outputKey];
      }
      constructor(e) {
        super(e);
        Object.defineProperty(this, "llmChain", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "inputKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "input_documents"
        });
        Object.defineProperty(this, "outputKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "output_text"
        });
        Object.defineProperty(this, "documentVariableName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "context"
        });
        Object.defineProperty(this, "initialResponseName", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "existing_answer"
        });
        Object.defineProperty(this, "refineLLMChain", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "documentPrompt", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: this.defaultDocumentPrompt
        });
        this.llmChain = e.llmChain;
        this.refineLLMChain = e.refineLLMChain;
        this.documentVariableName = e.documentVariableName ?? this.documentVariableName;
        this.inputKey = e.inputKey ?? this.inputKey;
        this.outputKey = e.outputKey ?? this.outputKey;
        this.documentPrompt = e.documentPrompt ?? this.documentPrompt;
        this.initialResponseName = e.initialResponseName ?? this.initialResponseName;
      }
      /** @ignore */
      async _constructInitialInputs(e, t) {
        const n = {
          page_content: e.pageContent,
          ...e.metadata
        };
        const i = {};
        this.documentPrompt.inputVariables.forEach((o) => {
          i[o] = n[o];
        });
        const s = {
          [this.documentVariableName]: await this.documentPrompt.format({
            ...i
          })
        };
        const a = { ...s, ...t };
        return a;
      }
      /** @ignore */
      async _constructRefineInputs(e, t) {
        const n = {
          page_content: e.pageContent,
          ...e.metadata
        };
        const i = {};
        this.documentPrompt.inputVariables.forEach((o) => {
          i[o] = n[o];
        });
        const s = {
          [this.documentVariableName]: await this.documentPrompt.format({
            ...i
          })
        };
        const a = { [this.initialResponseName]: t, ...s };
        return a;
      }
      /** @ignore */
      async _call(e, t) {
        if (!(this.inputKey in e)) {
          throw new Error(`Document key ${this.inputKey} not found.`);
        }
        const { [this.inputKey]: n, ...i } = e;
        const s = n;
        const a = await this._constructInitialInputs(s[0], i);
        let o = await this.llmChain.predict({ ...a }, t?.getChild("answer"));
        const u = [o];
        for (let l = 1; l < s.length; l += 1) {
          const c = await this._constructRefineInputs(s[l], o);
          const b = { ...c, ...i };
          o = await this.refineLLMChain.predict({ ...b }, t?.getChild("refine"));
          u.push(o);
        }
        return { [this.outputKey]: o };
      }
      _chainType() {
        return "refine_documents_chain";
      }
      static async deserialize(e) {
        const t = e.llm_chain;
        if (!t) {
          throw new Error("Missing llm_chain");
        }
        const n = e.refine_llm_chain;
        if (!n) {
          throw new Error("Missing refine_llm_chain");
        }
        return new yt({
          llmChain: await ne.deserialize(t),
          refineLLMChain: await ne.deserialize(n)
        });
      }
      serialize() {
        return {
          _type: this._chainType(),
          llm_chain: this.llmChain.serialize(),
          refine_llm_chain: this.refineLLMChain.serialize()
        };
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/prompts/chat.js
  var Nu, Mu, Gn, ha, bt, Xn, Xt, Me;
  var ei = j(() => {
    ct();
    rr();
    kt();
    we();
    Nu = class extends Te {
      constructor() {
        super(...arguments);
        Object.defineProperty(this, "lc_namespace", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: ["langchain", "prompts", "chat"]
        });
        Object.defineProperty(this, "lc_serializable", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: true
        });
      }
    };
    Mu = class extends Dr {
      constructor(e) {
        if (Array.isArray(e)) {
          e = { messages: e };
        }
        super(...arguments);
        Object.defineProperty(this, "lc_namespace", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: ["langchain", "prompts", "chat"]
        });
        Object.defineProperty(this, "lc_serializable", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: true
        });
        Object.defineProperty(this, "messages", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.messages = e.messages;
      }
      toString() {
        return JSON.stringify(this.messages);
      }
      toChatMessages() {
        return this.messages;
      }
    };
    Gn = class extends Nu {
      constructor(e) {
        if (!("prompt" in e)) {
          e = { prompt: e };
        }
        super(e);
        Object.defineProperty(this, "prompt", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.prompt = e.prompt;
      }
      get inputVariables() {
        return this.prompt.inputVariables;
      }
      async formatMessages(e) {
        return [await this.format(e)];
      }
    };
    ha = class extends Rt {
      constructor(e) {
        super(e);
      }
      async format(e) {
        return (await this.formatPromptValue(e)).toString();
      }
      async formatPromptValue(e) {
        const t = await this.formatMessages(e);
        return new Mu(t);
      }
    };
    bt = class extends Gn {
      async format(e) {
        return new lt(await this.prompt.format(e));
      }
      static fromTemplate(e) {
        return new this(X.fromTemplate(e));
      }
    };
    Xn = class extends Gn {
      async format(e) {
        return new Ot(await this.prompt.format(e));
      }
      static fromTemplate(e) {
        return new this(X.fromTemplate(e));
      }
    };
    Xt = class extends Gn {
      async format(e) {
        return new Lr(await this.prompt.format(e));
      }
      static fromTemplate(e) {
        return new this(X.fromTemplate(e));
      }
    };
    Me = class extends ha {
      get lc_aliases() {
        return {
          promptMessages: "messages"
        };
      }
      constructor(e) {
        super(e);
        Object.defineProperty(this, "promptMessages", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "validateTemplate", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: true
        });
        Object.assign(this, e);
        if (this.validateTemplate) {
          const t = /* @__PURE__ */ new Set();
          for (const a of this.promptMessages) {
            for (const o of a.inputVariables) {
              t.add(o);
            }
          }
          const n = new Set(this.partialVariables ? this.inputVariables.concat(Object.keys(this.partialVariables)) : this.inputVariables);
          const i = new Set([...n].filter((a) => !t.has(a)));
          if (i.size > 0) {
            throw new Error(`Input variables \`${[
              ...i
            ]}\` are not used in any of the prompt messages.`);
          }
          const s = new Set([...t].filter((a) => !n.has(a)));
          if (s.size > 0) {
            throw new Error(`Input variables \`${[
              ...s
            ]}\` are used in prompt messages but not in the prompt template.`);
          }
        }
      }
      _getPromptType() {
        return "chat";
      }
      async formatMessages(e) {
        const t = await this.mergePartialAndUserVariables(e);
        let n = [];
        for (const i of this.promptMessages) {
          const s = i.inputVariables.reduce((o, u) => {
            if (!(u in t)) {
              throw new Error(`Missing value for input variable \`${u}\``);
            }
            o[u] = t[u];
            return o;
          }, {});
          const a = await i.formatMessages(s);
          n = n.concat(a);
        }
        return n;
      }
      async partial(e) {
        const t = { ...this };
        t.inputVariables = this.inputVariables.filter((n) => !(n in e));
        t.partialVariables = {
          ...this.partialVariables ?? {},
          ...e
        };
        return new Me(t);
      }
      static fromPromptMessages(e) {
        const t = e.reduce((s, a) => s.concat(
          // eslint-disable-next-line no-instanceof/no-instanceof
          a instanceof Me ? a.promptMessages : [a]
        ), []);
        const n = e.reduce((s, a) => (
          // eslint-disable-next-line no-instanceof/no-instanceof
          a instanceof Me ? Object.assign(s, a.partialVariables) : s
        ), /* @__PURE__ */ Object.create(null));
        const i = /* @__PURE__ */ new Set();
        for (const s of t) {
          for (const a of s.inputVariables) {
            if (a in n) {
              continue;
            }
            i.add(a);
          }
        }
        return new Me({
          inputVariables: [...i],
          promptMessages: t,
          partialVariables: n
        });
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/prompts/selectors/conditional.js
  function xr(r) {
    return r._modelType() === "base_chat_model";
  }
  var fa, Mt;
  var ti = j(() => {
    fa = class {
      async getPromptAsync(e, t) {
        const n = this.getPrompt(e);
        return n.partial(t?.partialVariables ?? {});
      }
    };
    Mt = class extends fa {
      constructor(e, t = []) {
        super();
        Object.defineProperty(this, "defaultPrompt", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "conditionals", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        this.defaultPrompt = e;
        this.conditionals = t;
      }
      getPrompt(e) {
        for (const [t, n] of this.conditionals) {
          if (t(e)) {
            return n;
          }
        }
        return this.defaultPrompt;
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/question_answering/stuff_prompts.js
  var V_, z_, F_, K_, rf;
  var nf = j(() => {
    we();
    ei();
    ti();
    V_ = /* @__PURE__ */ new X({
      template: "Use the following pieces of context to answer the question at the end. If you don't know the answer, just say that you don't know, don't try to make up an answer.\n\n{context}\n\nQuestion: {question}\nHelpful Answer:",
      inputVariables: ["context", "question"]
    });
    z_ = `Use the following pieces of context to answer the users question. 
If you don't know the answer, just say that you don't know, don't try to make up an answer.
----------------
{context}`;
    F_ = [
      /* @__PURE__ */ Xt.fromTemplate(z_),
      /* @__PURE__ */ bt.fromTemplate("{question}")
    ];
    K_ = /* @__PURE__ */ Me.fromPromptMessages(F_);
    rf = /* @__PURE__ */ new Mt(V_, [[xr, K_]]);
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/question_answering/map_reduce_prompts.js
  var sf = j(() => {
    we();
    ei();
    ti();
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/prompts/selectors/LengthBasedExampleSelector.js
  var of = j(() => {
    kt();
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/prompts/selectors/SemanticSimilarityExampleSelector.js
  var uf = j(() => {
    na();
    kt();
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/prompts/pipeline.js
  var lf = j(() => {
    kt();
    ei();
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/prompts/index.js
  var cf = j(() => {
    kt();
    we();
    ti();
    of();
    uf();
    ua();
    ei();
    ln();
    lf();
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/question_answering/refine_prompts.js
  var B_, $_, Z_, H_, Q_, df, J_, Y_, W_, G_, X_, pf;
  var hf = j(() => {
    cf();
    ti();
    B_ = `The original question is as follows: {question}
We have provided an existing answer: {existing_answer}
We have the opportunity to refine the existing answer
(only if needed) with some more context below.
------------
{context}
------------
Given the new context, refine the original answer to better answer the question. 
If the context isn't useful, return the original answer.`;
    $_ = /* @__PURE__ */ new X({
      inputVariables: ["question", "existing_answer", "context"],
      template: B_
    });
    Z_ = `The original question is as follows: {question}
We have provided an existing answer: {existing_answer}
We have the opportunity to refine the existing answer
(only if needed) with some more context below.
------------
{context}
------------
Given the new context, refine the original answer to better answer the question. 
If the context isn't useful, return the original answer.`;
    H_ = [
      /* @__PURE__ */ bt.fromTemplate("{question}"),
      /* @__PURE__ */ Xn.fromTemplate("{existing_answer}"),
      /* @__PURE__ */ bt.fromTemplate(Z_)
    ];
    Q_ = /* @__PURE__ */ Me.fromPromptMessages(H_);
    df = /* @__PURE__ */ new Mt($_, [
      [xr, Q_]
    ]);
    J_ = `Context information is below. 
---------------------
{context}
---------------------
Given the context information and not prior knowledge, answer the question: {question}`;
    Y_ = /* @__PURE__ */ new X({
      inputVariables: ["context", "question"],
      template: J_
    });
    W_ = `Context information is below. 
---------------------
{context}
---------------------
Given the context information and not prior knowledge, answer any questions`;
    G_ = [
      /* @__PURE__ */ Xt.fromTemplate(W_),
      /* @__PURE__ */ bt.fromTemplate("{question}")
    ];
    X_ = /* @__PURE__ */ Me.fromPromptMessages(G_);
    pf = /* @__PURE__ */ new Mt(Y_, [
      [xr, X_]
    ]);
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/question_answering/load.js
  function pn(r, e = {}) {
    const { prompt: t = rf.getPrompt(r), verbose: n } = e;
    const i = new ne({ prompt: t, llm: r, verbose: n });
    const s = new Xe({ llmChain: i, verbose: n });
    return s;
  }
  function Lu(r, e = {}) {
    const { questionPrompt: t = pf.getPrompt(r), refinePrompt: n = df.getPrompt(r), verbose: i } = e;
    const s = new ne({ prompt: t, llm: r, verbose: i });
    const a = new ne({ prompt: n, llm: r, verbose: i });
    const o = new yt({
      llmChain: s,
      refineLLMChain: a,
      verbose: i
    });
    return o;
  }
  var hn = j(() => {
    Ve();
    vr();
    nf();
    sf();
    hf();
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/vector_db_qa.js
  var ff = {};
  tt(ff, {
    VectorDBQAChain: () => fn
  });
  var fn;
  var Du = j(() => {
    Ne();
    hn();
    fn = class extends ue {
      get inputKeys() {
        return [this.inputKey];
      }
      get outputKeys() {
        return this.combineDocumentsChain.outputKeys.concat(this.returnSourceDocuments ? ["sourceDocuments"] : []);
      }
      constructor(e) {
        super(e);
        Object.defineProperty(this, "k", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: 4
        });
        Object.defineProperty(this, "inputKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "query"
        });
        Object.defineProperty(this, "vectorstore", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "combineDocumentsChain", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "returnSourceDocuments", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: false
        });
        this.vectorstore = e.vectorstore;
        this.combineDocumentsChain = e.combineDocumentsChain;
        this.inputKey = e.inputKey ?? this.inputKey;
        this.k = e.k ?? this.k;
        this.returnSourceDocuments = e.returnSourceDocuments ?? this.returnSourceDocuments;
      }
      /** @ignore */
      async _call(e, t) {
        if (!(this.inputKey in e)) {
          throw new Error(`Question key ${this.inputKey} not found.`);
        }
        const n = e[this.inputKey];
        const i = await this.vectorstore.similaritySearch(n, this.k, e.filter);
        const s = { question: n, input_documents: i };
        const a = await this.combineDocumentsChain.call(s, t?.getChild("combine_documents"));
        if (this.returnSourceDocuments) {
          return {
            ...a,
            sourceDocuments: i
          };
        }
        return a;
      }
      _chainType() {
        return "vector_db_qa";
      }
      static async deserialize(e, t) {
        if (!("vectorstore" in t)) {
          throw new Error(`Need to pass in a vectorstore to deserialize VectorDBQAChain`);
        }
        const { vectorstore: n } = t;
        if (!e.combine_documents_chain) {
          throw new Error(`VectorDBQAChain must have combine_documents_chain in serialized data`);
        }
        return new fn({
          combineDocumentsChain: await ue.deserialize(e.combine_documents_chain),
          k: e.k,
          vectorstore: n
        });
      }
      serialize() {
        return {
          _type: this._chainType(),
          combine_documents_chain: this.combineDocumentsChain.serialize(),
          k: this.k
        };
      }
      static fromLLM(e, t, n) {
        const i = pn(e);
        return new this({
          vectorstore: t,
          combineDocumentsChain: i,
          ...n
        });
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/api/prompts.js
  var mf, yf, ev, bf;
  var gf = j(() => {
    we();
    mf = `You are given the below API Documentation:
{api_docs}
Using this documentation, generate the full API url to call for answering the user question.
You should build the API url in order to get a response that is as short as possible, while still getting the necessary information to answer the question. Pay attention to deliberately exclude any unnecessary pieces of data in the API call.

Question:{question}
API url:`;
    yf = /* @__PURE__ */ new X({
      inputVariables: ["api_docs", "question"],
      template: mf
    });
    ev = `${mf} {api_url}

Here is the response from the API:

{api_response}

Summarize this response to answer the original question.

Summary:`;
    bf = /* @__PURE__ */ new X({
      inputVariables: ["api_docs", "question", "api_url", "api_response"],
      template: ev
    });
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/api/api_chain.js
  var wf = {};
  tt(wf, {
    APIChain: () => mn
  });
  var mn;
  var qu = j(() => {
    Ne();
    Ve();
    gf();
    mn = class extends ue {
      get inputKeys() {
        return [this.inputKey];
      }
      get outputKeys() {
        return [this.outputKey];
      }
      constructor(e) {
        super(e);
        Object.defineProperty(this, "apiAnswerChain", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "apiRequestChain", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "apiDocs", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: void 0
        });
        Object.defineProperty(this, "headers", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: {}
        });
        Object.defineProperty(this, "inputKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "question"
        });
        Object.defineProperty(this, "outputKey", {
          enumerable: true,
          configurable: true,
          writable: true,
          value: "output"
        });
        this.apiRequestChain = e.apiRequestChain;
        this.apiAnswerChain = e.apiAnswerChain;
        this.apiDocs = e.apiDocs;
        this.inputKey = e.inputKey ?? this.inputKey;
        this.outputKey = e.outputKey ?? this.outputKey;
        this.headers = e.headers ?? this.headers;
      }
      /** @ignore */
      async _call(e, t) {
        const n = e[this.inputKey];
        const i = await this.apiRequestChain.predict({ question: n, api_docs: this.apiDocs }, t?.getChild("request"));
        const s = await fetch(i, { headers: this.headers });
        const a = await s.text();
        const o = await this.apiAnswerChain.predict({ question: n, api_docs: this.apiDocs, api_url: i, api_response: a }, t?.getChild("response"));
        return { [this.outputKey]: o };
      }
      _chainType() {
        return "api_chain";
      }
      static async deserialize(e) {
        const { api_request_chain: t, api_answer_chain: n, api_docs: i } = e;
        if (!t) {
          throw new Error("LLMChain must have api_request_chain");
        }
        if (!n) {
          throw new Error("LLMChain must have api_answer_chain");
        }
        if (!i) {
          throw new Error("LLMChain must have api_docs");
        }
        return new mn({
          apiAnswerChain: await ne.deserialize(n),
          apiRequestChain: await ne.deserialize(t),
          apiDocs: i
        });
      }
      serialize() {
        return {
          _type: this._chainType(),
          api_answer_chain: this.apiAnswerChain.serialize(),
          api_request_chain: this.apiRequestChain.serialize(),
          api_docs: this.apiDocs
        };
      }
      static fromLLMAndAPIDocs(e, t, n = {}) {
        const { apiUrlPrompt: i = yf, apiResponsePrompt: s = bf } = n;
        const a = new ne({ prompt: i, llm: e });
        const o = new ne({ prompt: s, llm: e });
        return new this({
          apiAnswerChain: o,
          apiRequestChain: a,
          apiDocs: t,
          ...n
        });
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/base.js
  var ue;
  var Ne = j(() => {
    ct();
    ts();
    Br();
    ue = class extends Bn {
      get lc_namespace() {
        return ["langchain", "chains", this._chainType()];
      }
      constructor(e, t, n) {
        if (arguments.length === 1 && typeof e === "object" && !("saveContext" in e)) {
          const { memory: i, callbackManager: s, ...a } = e;
          super({ ...a, callbacks: s ?? a.callbacks });
          this.memory = i;
        } else {
          super({ verbose: t, callbacks: n });
          this.memory = e;
        }
      }
      /**
       * Return a json-like object representing this chain.
       */
      serialize() {
        throw new Error("Method not implemented.");
      }
      async run(e, t) {
        const n = this.inputKeys.filter((u) => !this.memory?.memoryKeys.includes(u));
        const i = n.length <= 1;
        if (!i) {
          throw new Error(`Chain ${this._chainType()} expects multiple inputs, cannot use 'run' `);
        }
        const s = n.length ? { [n[0]]: e } : {};
        const a = await this.call(s, t);
        const o = Object.keys(a);
        if (o.length === 1) {
          return a[o[0]];
        }
        throw new Error("return values have multiple keys, `run` only supported when one key currently");
      }
      /**
       * Run the core logic of this chain and add to output if desired.
       *
       * Wraps _call and handles memory.
       */
      async call(e, t, n) {
        const i = { ...e };
        if (!(this.memory == null)) {
          const u = await this.memory.loadMemoryVariables(e);
          for (const [l, c] of Object.entries(u)) {
            i[l] = c;
          }
        }
        const s = await qe.configure(t, this.callbacks, n, this.tags, { verbose: this.verbose });
        const a = await s?.handleChainStart(this.toJSON(), i);
        let o;
        try {
          o = await this._call(i, a);
        } catch (u) {
          await a?.handleChainError(u);
          throw u;
        }
        if (!(this.memory == null)) {
          await this.memory.saveContext(e, o);
        }
        await a?.handleChainEnd(o);
        Object.defineProperty(o, qr, {
          value: a ? { runId: a?.runId } : void 0,
          configurable: true
        });
        return o;
      }
      /**
       * Call the chain on all inputs in the list
       */
      async apply(e, t) {
        return Promise.all(e.map(async (n, i) => this.call(n, t?.[i])));
      }
      /**
       * Load a chain from a json-like object describing it.
       */
      static async deserialize(e, t = {}) {
        switch (e._type) {
          case "llm_chain": {
            const { LLMChain: n } = await Promise.resolve().then(() => (Ve(), Xh));
            return n.deserialize(e);
          }
          case "sequential_chain": {
            const { SequentialChain: n } = await Promise.resolve().then(() => (da(), Ru));
            return n.deserialize(e);
          }
          case "simple_sequential_chain": {
            const { SimpleSequentialChain: n } = await Promise.resolve().then(() => (da(), Ru));
            return n.deserialize(e);
          }
          case "stuff_documents_chain": {
            const { StuffDocumentsChain: n } = await Promise.resolve().then(() => (vr(), pa));
            return n.deserialize(e);
          }
          case "map_reduce_documents_chain": {
            const { MapReduceDocumentsChain: n } = await Promise.resolve().then(() => (vr(), pa));
            return n.deserialize(e);
          }
          case "refine_documents_chain": {
            const { RefineDocumentsChain: n } = await Promise.resolve().then(() => (vr(), pa));
            return n.deserialize(e);
          }
          case "vector_db_qa": {
            const { VectorDBQAChain: n } = await Promise.resolve().then(() => (Du(), ff));
            return n.deserialize(e, t);
          }
          case "api_chain": {
            const { APIChain: n } = await Promise.resolve().then(() => (qu(), wf));
            return n.deserialize(e);
          }
          default:
            throw new Error(`Invalid prompt type in config: ${e._type}`);
        }
      }
    };
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/llms/openai.js
  hu();

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/similarities/czekanowski.js
  function Zs(r, e) {
    let t = 0;
    let n = 0;
    for (let i = 0; i < r.length; i++) {
      t += Math.min(r[i], e[i]);
      n += r[i] + e[i];
    }
    return 2 * t / n;
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/distances/dice.js
  function Hs(r, e) {
    let t = 0;
    let n = 0;
    let i = 0;
    for (let s = 0; s < r.length; s++) {
      t += r[s] * r[s];
      n += e[s] * e[s];
      i += (r[s] - e[s]) * (r[s] - e[s]);
    }
    return i / (t + n);
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/distances/intersection.js
  function Qs(r, e) {
    let t = 0;
    for (let n = 0; n < r.length; n++) {
      t += Math.min(r[n], e[n]);
    }
    return 1 - t;
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/similarities/kumarHassebrook.js
  function Js(r, e) {
    let t = 0;
    let n = 0;
    let i = 0;
    for (let s = 0; s < r.length; s++) {
      t += r[s] * e[s];
      n += r[s] * r[s];
      i += e[s] * e[s];
    }
    return t / (n + i - t);
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/distances/kulczynski.js
  function Ys(r, e) {
    let t = 0;
    let n = 0;
    for (let i = 0; i < r.length; i++) {
      t += Math.abs(r[i] - e[i]);
      n += Math.min(r[i], e[i]);
    }
    return t / n;
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/distances/motyka.js
  function Ws(r, e) {
    let t = 0;
    let n = 0;
    for (let i = 0; i < r.length; i++) {
      t += Math.min(r[i], e[i]);
      n += r[i] + e[i];
    }
    return 1 - t / n;
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/distances/squaredChord.js
  function Gs(r, e) {
    let t = 0;
    for (let n = 0; n < r.length; n++) {
      t += (Math.sqrt(r[n]) - Math.sqrt(e[n])) ** 2;
    }
    return t;
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/similarities/tanimoto.js
  function Xs(r, e, t) {
    if (t) {
      let n = 0;
      let i = 0;
      for (let s = 0; s < r.length; s++) {
        n += r[s] && e[s];
        i += r[s] || e[s];
      }
      if (i === 0) {
        return 1;
      }
      return n / i;
    } else {
      let n = 0;
      let i = 0;
      let s = 0;
      for (let a = 0; a < r.length; a++) {
        n += r[a];
        i += e[a];
        s += Math.min(r[a], e[a]);
      }
      return 1 - (n + i - 2 * s) / (n + i - s);
    }
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/similarities.js
  var ta = {};
  tt(ta, {
    cosine: () => Jn,
    czekanowski: () => Zs,
    dice: () => wu,
    intersection: () => _u,
    kulczynski: () => vu,
    kumarHassebrook: () => Js,
    motyka: () => xu,
    pearson: () => Pu,
    squaredChord: () => Au,
    tanimoto: () => Xs,
    tree: () => gu
  });

  // node_modules/.pnpm/ml-tree-similarity@1.0.0/node_modules/ml-tree-similarity/src/index.js
  var gu = {};
  tt(gu, {
    createTree: () => Hn,
    getFunction: () => D_,
    treeSimilarity: () => L_
  });

  // node_modules/.pnpm/ml-tree-similarity@1.0.0/node_modules/ml-tree-similarity/src/createTree.js
  var Hh = be($h());
  var Qh = be(Zh());
  function Hn(r, e = {}) {
    var t = r[0];
    const {
      minWindow: n = 0.16,
      threshold: i = 0.01,
      from: s = t[0],
      to: a = t[t.length - 1]
    } = e;
    return Zn(
      r[0],
      r[1],
      s,
      a,
      n,
      i
    );
  }
  function Zn(r, e, t, n, i, s) {
    if (n - t < i) {
      return null;
    }
    var a = (0, Hh.default)(r, t, Qh.ascending);
    if (a < 0) {
      a = ~a;
    }
    var o = 0;
    var u = 0;
    for (var l = a; l < r.length; l++) {
      if (r[l] >= n) {
        break;
      }
      o += e[l];
      u += r[l] * e[l];
    }
    if (o < s) {
      return null;
    }
    u /= o;
    if (u - t < 1e-6 || n - u < 1e-6) {
      return null;
    }
    if (u - t < i / 4) {
      return Zn(r, e, u, n, i, s);
    } else {
      if (n - u < i / 4) {
        return Zn(r, e, t, u, i, s);
      } else {
        return new bu(
          o,
          u,
          Zn(r, e, t, u, i, s),
          Zn(r, e, u, n, i, s)
        );
      }
    }
  }
  var bu = class {
    constructor(e, t, n, i) {
      this.sum = e;
      this.center = t;
      this.left = n;
      this.right = i;
    }
  };

  // node_modules/.pnpm/ml-tree-similarity@1.0.0/node_modules/ml-tree-similarity/src/getSimilarity.js
  function Qn(r, e, t = {}) {
    const { alpha: n = 0.1, beta: i = 0.33, gamma: s = 1e-3 } = t;
    if (r === null || e === null) {
      return 0;
    }
    if (Array.isArray(r)) {
      r = Hn(r);
    }
    if (Array.isArray(e)) {
      e = Hn(e);
    }
    var a = n * Math.min(r.sum, e.sum) / Math.max(r.sum, e.sum) + (1 - n) * Math.exp(-s * Math.abs(r.center - e.center));
    return i * a + (1 - i) * (Qn(r.left, e.left, t) + Qn(r.right, e.right, t)) / 2;
  }

  // node_modules/.pnpm/ml-tree-similarity@1.0.0/node_modules/ml-tree-similarity/src/index.js
  function L_(r, e, t = {}) {
    return Qn(r, e, t);
  }
  function D_(r = {}) {
    return (e, t) => Qn(e, t, r);
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/similarities/cosine.js
  function Jn(r, e) {
    let t = 0;
    let n = 0;
    let i = 0;
    for (let s = 0; s < r.length; s++) {
      t += r[s] * e[s];
      n += r[s] * r[s];
      i += e[s] * e[s];
    }
    return t / (Math.sqrt(n) * Math.sqrt(i));
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/similarities/dice.js
  function wu(r, e) {
    return 1 - Hs(r, e);
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/similarities/intersection.js
  function _u(r, e) {
    return 1 - Qs(r, e);
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/similarities/kulczynski.js
  function vu(r, e) {
    return 1 / Ys(r, e);
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/similarities/motyka.js
  function xu(r, e) {
    return 1 - Ws(r, e);
  }

  // node_modules/.pnpm/is-any-array@2.0.1/node_modules/is-any-array/lib-esm/index.js
  var q_ = Object.prototype.toString;
  function Jh(r) {
    const e = q_.call(r);
    return e.endsWith("Array]") && !e.includes("Big");
  }

  // node_modules/.pnpm/ml-array-sum@1.1.6/node_modules/ml-array-sum/lib-es6/index.js
  function Yh(r) {
    if (!Jh(r)) {
      throw new TypeError("input must be an array");
    }
    if (r.length === 0) {
      throw new TypeError("input must not be empty");
    }
    var e = 0;
    for (var t = 0; t < r.length; t++) {
      e += r[t];
    }
    return e;
  }

  // node_modules/.pnpm/ml-array-mean@1.1.6/node_modules/ml-array-mean/lib-es6/index.js
  function Ou(r) {
    return Yh(r) / r.length;
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/similarities/pearson.js
  function Pu(r, e) {
    let t = Ou(r);
    let n = Ou(e);
    let i = new Array(r.length);
    let s = new Array(e.length);
    for (let a = 0; a < i.length; a++) {
      i[a] = r[a] - t;
      s[a] = e[a] - n;
    }
    return Jn(i, s);
  }

  // node_modules/.pnpm/ml-distance@4.0.0/node_modules/ml-distance/lib-esm/similarities/squaredChord.js
  function Au(r, e) {
    return 1 - Gs(r, e);
  }

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/vectorstores/base.js
  ct();
  var Eu = class extends Si {
    constructor(e) {
      super();
      Object.defineProperty(this, "vectorStore", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, "k", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: 4
      });
      Object.defineProperty(this, "filter", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      this.vectorStore = e.vectorStore;
      this.k = e.k ?? this.k;
      this.filter = e.filter;
    }
    async getRelevantDocuments(e) {
      const t = await this.vectorStore.similaritySearch(e, this.k, this.filter);
      return t;
    }
    async addDocuments(e) {
      await this.vectorStore.addDocuments(e);
    }
  };
  var ra = class {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    constructor(e, t) {
      Object.defineProperty(this, "embeddings", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      this.embeddings = e;
    }
    async similaritySearch(e, t = 4, n = void 0) {
      const i = await this.similaritySearchVectorWithScore(await this.embeddings.embedQuery(e), t, n);
      return i.map((s) => s[0]);
    }
    async similaritySearchWithScore(e, t = 4, n = void 0) {
      return this.similaritySearchVectorWithScore(await this.embeddings.embedQuery(e), t, n);
    }
    static fromTexts(e, t, n, i) {
      throw new Error("the Langchain vectorstore implementation you are using forgot to override this, please report a bug");
    }
    static fromDocuments(e, t, n) {
      throw new Error("the Langchain vectorstore implementation you are using forgot to override this, please report a bug");
    }
    asRetriever(e, t) {
      return new Eu({ vectorStore: this, k: e, filter: t });
    }
  };

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/vectorstores/memory.js
  na();
  var on = class extends ra {
    constructor(e, { similarity: t, ...n } = {}) {
      super(e, n);
      Object.defineProperty(this, "memoryVectors", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: []
      });
      Object.defineProperty(this, "similarity", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      this.similarity = t ?? ta.cosine;
    }
    async addDocuments(e) {
      const t = e.map(({ pageContent: n }) => n);
      return this.addVectors(await this.embeddings.embedDocuments(t), e);
    }
    async addVectors(e, t) {
      const n = e.map((i, s) => ({
        content: t[s].pageContent,
        embedding: i,
        metadata: t[s].metadata
      }));
      this.memoryVectors = this.memoryVectors.concat(n);
    }
    async similaritySearchVectorWithScore(e, t, n) {
      const i = (u) => {
        if (!n) {
          return true;
        }
        const l = new jt({
          metadata: u.metadata,
          pageContent: u.content
        });
        return n(l);
      };
      const s = this.memoryVectors.filter(i);
      const a = s.map((u, l) => ({
        similarity: this.similarity(e, u.embedding),
        index: l
      })).sort((u, l) => u.similarity > l.similarity ? -1 : 0).slice(0, t);
      const o = a.map((u) => [
        new jt({
          metadata: s[u.index].metadata,
          pageContent: s[u.index].content
        }),
        u.similarity
      ]);
      return o;
    }
    static async fromTexts(e, t, n, i) {
      const s = [];
      for (let a = 0; a < e.length; a += 1) {
        const o = Array.isArray(t) ? t[a] : t;
        const u = new jt({
          pageContent: e[a],
          metadata: o
        });
        s.push(u);
      }
      return on.fromDocuments(s, n, i);
    }
    static async fromDocuments(e, t, n) {
      const i = new this(t, n);
      await i.addDocuments(e);
      return i;
    }
    static async fromExistingIndex(e, t) {
      const n = new this(e, t);
      return n;
    }
  };

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/embeddings/openai.js
  var aa = be(Tr(), 1);
  _t();
  Nr();
  xo();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/embeddings/base.js
  Mn();
  var ia = class {
    constructor(e) {
      Object.defineProperty(this, "caller", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      this.caller = new Pt(e ?? {});
    }
  };

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/embeddings/openai.js
  var sa = class extends ia {
    constructor(e, t) {
      super(e ?? {});
      Object.defineProperty(this, "modelName", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: "text-embedding-ada-002"
      });
      Object.defineProperty(this, "batchSize", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: this.azureOpenAIApiKey ? 1 : 512
      });
      Object.defineProperty(this, "stripNewLines", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: true
      });
      Object.defineProperty(this, "timeout", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, "azureOpenAIApiVersion", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, "azureOpenAIApiKey", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, "azureOpenAIApiInstanceName", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, "azureOpenAIApiDeploymentName", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, "client", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, "clientConfig", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      const n = e?.openAIApiKey ?? G("OPENAI_API_KEY");
      const i = e?.azureOpenAIApiKey ?? G("AZURE_OPENAI_API_KEY");
      if (!i && !n) {
        throw new Error("(Azure) OpenAI API key not found");
      }
      const s = e?.azureOpenAIApiInstanceName ?? G("AZURE_OPENAI_API_INSTANCE_NAME");
      const a = (e?.azureOpenAIApiEmbeddingsDeploymentName || e?.azureOpenAIApiDeploymentName) ?? (G("AZURE_OPENAI_API_EMBEDDINGS_DEPLOYMENT_NAME") || G("AZURE_OPENAI_API_DEPLOYMENT_NAME"));
      const o = e?.azureOpenAIApiVersion ?? G("AZURE_OPENAI_API_VERSION");
      this.modelName = e?.modelName ?? this.modelName;
      this.batchSize = e?.batchSize ?? this.batchSize;
      this.stripNewLines = e?.stripNewLines ?? this.stripNewLines;
      this.timeout = e?.timeout;
      this.azureOpenAIApiVersion = o;
      this.azureOpenAIApiKey = i;
      this.azureOpenAIApiInstanceName = s;
      this.azureOpenAIApiDeploymentName = a;
      if (this.azureOpenAIApiKey) {
        if (!this.azureOpenAIApiInstanceName) {
          throw new Error("Azure OpenAI API instance name not found");
        }
        if (!this.azureOpenAIApiDeploymentName) {
          throw new Error("Azure OpenAI API deployment name not found");
        }
        if (!this.azureOpenAIApiVersion) {
          throw new Error("Azure OpenAI API version not found");
        }
      }
      this.clientConfig = {
        apiKey: n,
        ...t
      };
    }
    async embedDocuments(e) {
      const t = kn(this.stripNewLines ? e.map((i) => i.replaceAll("\n", " ")) : e, this.batchSize);
      const n = [];
      for (let i = 0; i < t.length; i += 1) {
        const s = t[i];
        const { data: a } = await this.embeddingWithRetry({
          model: this.modelName,
          input: s
        });
        for (let o = 0; o < s.length; o += 1) {
          n.push(a.data[o].embedding);
        }
      }
      return n;
    }
    async embedQuery(e) {
      const { data: t } = await this.embeddingWithRetry({
        model: this.modelName,
        input: this.stripNewLines ? e.replaceAll("\n", " ") : e
      });
      return t.data[0].embedding;
    }
    async embeddingWithRetry(e) {
      if (!this.client) {
        const n = this.azureOpenAIApiKey ? `https://${this.azureOpenAIApiInstanceName}.openai.azure.com/openai/deployments/${this.azureOpenAIApiDeploymentName}` : this.clientConfig.basePath;
        const i = new aa.Configuration({
          ...this.clientConfig,
          basePath: n,
          baseOptions: {
            timeout: this.timeout,
            adapter: wt() ? void 0 : Fe,
            ...this.clientConfig.baseOptions
          }
        });
        this.client = new aa.OpenAIApi(i);
      }
      const t = {};
      if (this.azureOpenAIApiKey) {
        t.headers = {
          "api-key": this.azureOpenAIApiKey,
          ...t.headers
        };
        t.params = {
          "api-version": this.azureOpenAIApiVersion,
          ...t.params
        };
      }
      return this.caller.call(this.client.createEmbedding.bind(this.client), e, t);
    }
  };

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/text_splitter.js
  na();
  Bi();
  var Tu = class {
    constructor(e) {
      Object.defineProperty(this, "chunkSize", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: 1e3
      });
      Object.defineProperty(this, "chunkOverlap", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: 200
      });
      Object.defineProperty(this, "keepSeparator", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: false
      });
      this.chunkSize = e?.chunkSize ?? this.chunkSize;
      this.chunkOverlap = e?.chunkOverlap ?? this.chunkOverlap;
      this.keepSeparator = e?.keepSeparator ?? this.keepSeparator;
      if (this.chunkOverlap >= this.chunkSize) {
        throw new Error("Cannot have chunkOverlap >= chunkSize");
      }
    }
    splitOnSeparator(e, t) {
      let n;
      if (t) {
        if (this.keepSeparator) {
          const i = t.replace(/[/\-\\^$*+?.()|[\]{}]/g, "\\$&");
          n = e.split(new RegExp(`(?=${i})`));
        } else {
          n = e.split(t);
        }
      } else {
        n = e.split("");
      }
      return n.filter((i) => i !== "");
    }
    async createDocuments(e, t = [], n = {}) {
      const i = t.length > 0 ? t : new Array(e.length).fill({});
      const { chunkHeader: s = "", chunkOverlapHeader: a = "(cont'd) ", appendChunkOverlapHeader: o = false } = n;
      const u = new Array();
      for (let l = 0; l < e.length; l += 1) {
        const c = e[l];
        let b = 1;
        let _ = null;
        for (const x of await this.splitText(c)) {
          let f = s;
          let P = 0;
          if (_) {
            const U = c.indexOf(x);
            const g = c.indexOf(_) + _.length;
            const C = c.slice(g, U);
            P = (C.match(/\n/g) || []).length;
            if (o) {
              f += a;
            }
          }
          b += P;
          const S = (x.match(/\n/g) || []).length;
          const k = i[l].loc && typeof i[l].loc === "object" ? { ...i[l].loc } : {};
          k.lines = {
            from: b,
            to: b + S
          };
          const R = {
            ...i[l],
            loc: k
          };
          f += x;
          u.push(new jt({
            pageContent: f,
            metadata: R
          }));
          b += S;
          _ = x;
        }
      }
      return u;
    }
    async splitDocuments(e, t = {}) {
      const n = e.filter((a) => a.pageContent !== void 0);
      const i = n.map((a) => a.pageContent);
      const s = n.map((a) => a.metadata);
      return this.createDocuments(i, s, t);
    }
    joinDocs(e, t) {
      const n = e.join(t).trim();
      return n === "" ? null : n;
    }
    mergeSplits(e, t) {
      const n = [];
      const i = [];
      let s = 0;
      for (const o of e) {
        const u = o.length;
        if (s + u + (i.length > 0 ? t.length : 0) > this.chunkSize) {
          if (s > this.chunkSize) {
            console.warn(`Created a chunk of size ${s}, +
which is longer than the specified ${this.chunkSize}`);
          }
          if (i.length > 0) {
            const l = this.joinDocs(i, t);
            if (l !== null) {
              n.push(l);
            }
            while (s > this.chunkOverlap || s + u > this.chunkSize && s > 0) {
              s -= i[0].length;
              i.shift();
            }
          }
        }
        i.push(o);
        s += u;
      }
      const a = this.joinDocs(i, t);
      if (a !== null) {
        n.push(a);
      }
      return n;
    }
  };
  var oa = class extends Tu {
    constructor(e) {
      super(e);
      Object.defineProperty(this, "encodingName", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, "allowedSpecial", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, "disallowedSpecial", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, "tokenizer", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      this.encodingName = e?.encodingName ?? "gpt2";
      this.allowedSpecial = e?.allowedSpecial ?? [];
      this.disallowedSpecial = e?.disallowedSpecial ?? "all";
    }
    async splitText(e) {
      if (!this.tokenizer) {
        this.tokenizer = await Lo(this.encodingName);
      }
      const t = [];
      const n = this.tokenizer.encode(e, this.allowedSpecial, this.disallowedSpecial);
      let i = 0;
      let s = Math.min(i + this.chunkSize, n.length);
      let a = n.slice(i, s);
      while (i < n.length) {
        t.push(this.tokenizer.decode(a));
        i += this.chunkSize - this.chunkOverlap;
        s = Math.min(i + this.chunkSize, n.length);
        a = n.slice(i, s);
      }
      return t;
    }
  };

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/index.js
  Ne();
  Ve();
  qu();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/conversation.js
  Ve();
  we();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/memory/buffer_memory.js
  Kr();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/memory/chat_memory.js
  Kr();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/stores/message/in_memory.js
  ct();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/index.js
  da();
  vr();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/chat_vector_db_chain.js
  we();
  Ne();
  Ve();
  hn();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/analyze_documents_chain.js
  Ne();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/index.js
  Du();
  hn();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/summarization/load.js
  Ve();
  vr();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/summarization/stuff_prompts.js
  we();
  var tv = `Write a concise summary of the following:


"{text}"


CONCISE SUMMARY:`;
  var ri = /* @__PURE__ */ new X({
    template: tv,
    inputVariables: ["text"]
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/summarization/refine_prompts.js
  we();
  var rv = `Your job is to produce a final summary
We have provided an existing summary up to a certain point: "{existing_answer}"
We have the opportunity to refine the existing summary
(only if needed) with some more context below.
------------
"{text}"
------------

Given the new context, refine the original summary
If the context isn't useful, return the original summary.

REFINED SUMMARY:`;
  var _f = /* @__PURE__ */ new X({
    template: rv,
    inputVariables: ["existing_answer", "text"]
  });

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/summarization/load.js
  var Uu = (r, e = { type: "map_reduce" }) => {
    const { verbose: t } = e;
    if (e.type === "stuff") {
      const { prompt: n = ri } = e;
      const i = new ne({ prompt: n, llm: r, verbose: t });
      const s = new Xe({
        llmChain: i,
        documentVariableName: "text",
        verbose: t
      });
      return s;
    }
    if (e.type === "map_reduce") {
      const { combineMapPrompt: n = ri, combinePrompt: i = ri, returnIntermediateSteps: s } = e;
      const a = new ne({ prompt: n, llm: r, verbose: t });
      const o = new ne({
        prompt: i,
        llm: r,
        verbose: t
      });
      const u = new Xe({
        llmChain: o,
        documentVariableName: "text",
        verbose: t
      });
      const l = new Nt({
        llmChain: a,
        combineDocumentChain: u,
        documentVariableName: "text",
        returnIntermediateSteps: s,
        verbose: t
      });
      return l;
    }
    if (e.type === "refine") {
      const { refinePrompt: n = _f, questionPrompt: i = ri } = e;
      const s = new ne({ prompt: i, llm: r, verbose: t });
      const a = new ne({ prompt: n, llm: r, verbose: t });
      const o = new yt({
        llmChain: s,
        refineLLMChain: a,
        documentVariableName: "text",
        verbose: t
      });
      return o;
    }
    throw new Error(`Invalid _type: ${e.type}`);
  };

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/sql_db/sql_db_prompt.js
  we();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/sql_db/sql_db_chain.js
  Ne();
  Ve();
  Br();
  zr();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/conversational_retrieval_chain.js
  we();
  Ne();
  Ve();
  hn();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/retrieval_qa.js
  Ne();
  hn();
  var yn = class extends ue {
    get inputKeys() {
      return [this.inputKey];
    }
    get outputKeys() {
      return this.combineDocumentsChain.outputKeys.concat(this.returnSourceDocuments ? ["sourceDocuments"] : []);
    }
    constructor(e) {
      super(e);
      Object.defineProperty(this, "inputKey", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: "query"
      });
      Object.defineProperty(this, "retriever", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, "combineDocumentsChain", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, "returnSourceDocuments", {
        enumerable: true,
        configurable: true,
        writable: true,
        value: false
      });
      this.retriever = e.retriever;
      this.combineDocumentsChain = e.combineDocumentsChain;
      this.inputKey = e.inputKey ?? this.inputKey;
      this.returnSourceDocuments = e.returnSourceDocuments ?? this.returnSourceDocuments;
    }
    /** @ignore */
    async _call(e, t) {
      if (!(this.inputKey in e)) {
        throw new Error(`Question key ${this.inputKey} not found.`);
      }
      const n = e[this.inputKey];
      const i = await this.retriever.getRelevantDocuments(n);
      const s = { question: n, input_documents: i };
      const a = await this.combineDocumentsChain.call(s, t?.getChild("combine_documents"));
      if (this.returnSourceDocuments) {
        return {
          ...a,
          sourceDocuments: i
        };
      }
      return a;
    }
    _chainType() {
      return "retrieval_qa";
    }
    static async deserialize(e, t) {
      throw new Error("Not implemented");
    }
    serialize() {
      throw new Error("Not implemented");
    }
    static fromLLM(e, t, n) {
      const i = pn(e, {
        prompt: n?.prompt
      });
      return new this({
        ...n,
        retriever: t,
        combineDocumentsChain: i
      });
    }
  };

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/constitutional_ai/constitutional_chain.js
  Ne();
  Ve();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/constitutional_ai/constitutional_prompts.js
  ua();
  we();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/openai_moderation.js
  var vf = be(Tr(), 1);
  Ne();
  Nr();
  Mn();
  _t();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/router/multi_route.js
  Ne();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/router/llm_router.js
  Ve();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/router/multi_prompt.js
  ln();
  Ve();
  we();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/output_parsers/structured.js
  var uv = be(lu(), 1);

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/schema/output_parser.js
  rr();

  // node_modules/.pnpm/langchain@0.0.95_axios@1.4.0/node_modules/langchain/dist/chains/router/multi_retrieval_qa.js
  ln();
  we();

  // src/langchainModules/index.ts
  globalThis.langchain = {
    OpenAI: an,
    MemoryVectorStore: on,
    OpenAIEmbeddings: sa,
    // RecursiveCharacterTextSplitter,
    RetrievalQAChain: yn,
    loadSummarizationChain: Uu,
    loadQARefineChain: Lu,
    TokenTextSplitter: oa
  };
})();
